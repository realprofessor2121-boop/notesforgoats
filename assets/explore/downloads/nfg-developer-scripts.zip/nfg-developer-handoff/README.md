# Notes For Goats developer handoff

This archive contains the editable NFG site, the Gatekeepers arcade source, the Basement Bout, the house tour and Room Planner, the browser-local music and cover libraries, and the builders for several NFG assets.

## Run the website and arcade

Use Node 22.13 or later. Extract the archive and run these commands from its top folder.

```sh
npm ci
npm run build
npm run verify
python3 -m http.server 8000 --directory web
```

Open `http://localhost:8000/` for the site. Open `http://localhost:8000/arcade/` for the standalone Gatekeepers arcade. The arcade’s nine room images, three-frame Notes running sprite, nine pose rewards, opponents, coins, and soundtrack are included.

The complete site uses the original NFG media and runtime libraries at the relative paths recorded in `asset-manifest.json`. To bring those delivered assets into the editable copy, point the sync command to the existing site’s complete static export.

```sh
npm run sync-media -- /path/to/site/dist
npm run verify -- --full
```

Each manifest row records the relative path, file size, SHA-256, and where the file comes from. The sync command imports rows marked `site-export` and preserves included files and generated arcade code.

## Source map

| Area | Route | Source |
|---|---|---|
| Syllabus and day lessons | `#syllabus`, `#day-0` through `#day-8` | `web/index.html`, `lessons.js`, `photos.js` |
| Models and lesson photos | `#explore` | `explore.js`, `explore.css`, `models.js`, `photos.js` |
| Bills | `#explore/collection/bills` | `bills.js`, `bills.css` |
| House tour and avatars | `#tour` | `tour.js`, `tour.css`, `assets/explore/avatars/` |
| Room Planner | `#planner` | `planner.js`, `planner.css` |
| Gatekeepers | `#arcade` and `/arcade/` | `source/arcade/`, built by `scripts/build-arcade.mjs` |
| Basement Bout | `#fight` | `fight.js`, `fight.css`, `assets/explore/arcade/` |
| Game Center | `#games` | `games.js`, `games.css`, `artwork.js` |
| Music library | `#enjoy-music` | `music.js`, `music.css`, `artwork.js`, `jukebox.js` |
| NFG profile | `#profile` | `profile.js`, `profile.css` |
| Signup and order worksheets | `#signup/<organization>`, `#order/<item>` | `forms.js`, `forms.css`, `profile.js` |
| Duo video and project | `#duo` | `web/index.html`, `projects/iphone-duo/` |

The site modules in this table live in `web/assets/explore/`. Page navigation is in the main HTML, and `features.js` mounts pages that load their own modules. Media URLs are relative to the site. Preserve the directory layout when publishing under a path such as GitHub Pages.

## Gatekeepers

The editable React game is `source/arcade/play.tsx`. `runner.ts` handles visual interpolation between grid cells, the three-frame Notes loop, and rendering across both tunnel edges. `pose-rewards.ts` grants one authentic Notes pose after every room in a day has been learned in a single run. Day 0 has eight rooms. Days 1 through 8 have seven each. The gallery tracks these nine achievements across runs.

Arrow keys or WASD move in solo play. In local 1V1, arrows control player 1 and WASD controls player 2. Space or P pauses. The course keeps its original 64 rooms, game modes, maze, difficulty, opponents, scoring, and controls.

After editing the TSX, run `npm run build` and serve `web/` again. The build bundles pinned React and React DOM dependencies into `web/arcade/arcade.js`. Its room art, soundtrack, and pose images remain independent media files.

The running sprite uses `Notes__2.png`, `Notes__3_T.png`, and `Notes__3.png` from the original NFG archive. Reward source filenames are recorded in `source/arcade/pose-sources.json`.

## Browser data and production integration

- Game high scores, arcade pose unlocks, and saved Room Planner layouts use browser storage. The Room Planner can export its layout JSON.
- The NFG profile and explicitly saved signup and order drafts use browser storage. Signup drafts open official resources for manual registration. Order requests preview the exact item, quantity and included contact details before opening an email draft. The order code uses a seller checkout only when an actual HTTPS checkout is supplied by the catalog.
- Game and music covers use the `nfg-artwork` IndexedDB database. Preset choices and uploaded images persist for that browser and site origin.
- Song counts are stored in the `streams` store of the `nfg-soundtrack-library` IndexedDB database. A continuous 30 seconds of audible playback earns one count for a playback, or audible natural completion for a shorter song. Seeking, pausing, buffering, changing playback speed, and muting interrupt the count window.

Use the existing checkout and hosting target for production. Copy media into the editable project, rebuild Gatekeepers, run the full file check, and deploy the contents of `web/` under the current site's path and access settings. Deploy the script ZIP at `assets/explore/downloads/nfg-developer-scripts.zip` so the gallery can link to it.

For signed-in progress or cross-device cover uploads, connect the browser interfaces to the existing authenticated application and store records by account and item ID. For aggregate song counts, validate eligible playback on the production service and deduplicate retried events by playback ID. The browser counts are scoped to this device and site origin.

## Editable asset builders

`source/explore/` includes the NFG scene modules for original teaching geometry and the GLB geometry utility. Keep the delivered GLBs and their posters together under the paths in the manifest.

`projects/distribution-calendar/` includes the Blender calendar builder, editable weather symbols, room day tokens, and validation script. Use Blender 4.3 or later with DejaVu Sans fonts on Linux. The builder writes the .blend into the site’s downloads folder.

```sh
blender -b -Y -t 2 --python projects/distribution-calendar/build_calendar.py
blender -b web/assets/explore/downloads/nfg-distribution-calendar.blend -Y -t 2 --python projects/distribution-calendar/add_room_tokens.py
```

`projects/iphone-duo/` contains the supplied compositing source and timeline. Place `duo_concept.png`, `syllabus.jpg`, and `syllabus_video.mp4` in `projects/iphone-duo/assets/` from the original project download. The project README records its FFmpeg, Pillow, NumPy, SciPy and font requirements. The same directory includes the separate Blender builder and its packed screen texture for the interactive Duo concept.

`projects/food-models/` includes the GLB builder for fruit and the GOAT Water scene and label scripts. Run `node projects/food-models/build-fruit.mjs` for fruit GLBs. The water builder can use the supplied label texture or regenerate it from the NFG logo with Pillow and the DejaVu font. Run `blender -b -Y -t 2 --python projects/food-models/build-goat-water.py` to build the editable bottle and GLB.
