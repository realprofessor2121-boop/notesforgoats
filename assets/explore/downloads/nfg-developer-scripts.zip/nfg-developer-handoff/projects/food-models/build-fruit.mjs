import { mkdirSync, writeFileSync } from 'node:fs';
import { buildGlb, buildPoster } from '../../source/explore/geometry.js';
import { collectibleModels } from '../../source/explore/collectibles.js';

const tau = Math.PI * 2;
const leafGreen = '#4e853a';
const safeBrown = '#775035';

function lathe(scene, profile, color, origin = [0, 0, 0], depth = 1, lobes = 0) {
    const faces = 24;
    const batch = scene.material(color);
    const first = batch.positions.length / 3;
    for (const [ring, [y, radius]] of profile.entries()) {
        const [lower, upper] = [profile[Math.max(0, ring - 1)], profile[Math.min(profile.length - 1, ring + 1)]];
        const slope = (upper[1] - lower[1]) / (upper[0] - lower[0]);
        for (let side = 0; side < faces; side++) {
            const angle = side * tau / faces;
            const x = Math.cos(angle);
            const z = Math.sin(angle);
            const swell = 1 + lobes * Math.cos(5 * angle);
            const out = [x, -slope, z / depth];
            const length = Math.hypot(...out);
            batch.positions.push(origin[0] + x * radius * swell, origin[1] + y, origin[2] + z * radius * swell * depth);
            batch.normals.push(...out.map(value => value / length));
            if (ring === profile.length - 1) continue;
            const a = first + ring * faces + side;
            const b = first + ring * faces + (side + 1) % faces;
            batch.indices.push(a, a + faces, b + faces, a, b + faces, b);
        }
    }
}

function leaf(scene, x, y, z, length, angle, color = leafGreen) {
    scene.ellipsoid([x, y, z], [length, length * .15, length * .38], color, [0, -.2, angle]);
}

function stem(scene, x, y, z, slant = .14) {
    scene.tube([[x, y, z], [x + slant * .4, y + .11, z], [x + slant, y + .27, z - .03]], [.049, .044, .032], safeBrown);
}

function flecks(scene, center, radii, count, colors, size = .022) {
    for (let i = 0; i < count; i++) {
        const y = (i + .5) * 2 / count - 1;
        const angle = i * 2.39996323;
        const ring = Math.sqrt(1 - y * y);
        const at = [center[0] + radii[0] * Math.cos(angle) * ring, center[1] + radii[1] * y,
            center[2] + radii[2] * Math.sin(angle) * ring];
        scene.ellipsoid(at, [size, size * .74, size], colors[i % colors.length]);
    }
}

function citrus(scene, skin, pulp, pale, scale = 1, stretch = 1) {
    const center = [-.41, .05, -.17];
    const radii = [.75 * scale, .73 * scale * stretch, .71 * scale];
    scene.ellipsoid(center, radii, skin, [0, 0, -.24]);
    flecks(scene, center, radii.map(n => n * .996), 42, [skin, pale], .018);
    leaf(scene, -.07, .66 * stretch + .06, -.14, .24, .4);
    const x = .66;
    const y = -.21;
    const radius = .53 * scale;
    scene.ellipsoid([x, y, .36], [radius, radius, .17], skin);
    scene.ellipsoid([x, y, .469], [radius * .955, radius * .955, .079], pale);
    scene.ellipsoid([x, y, .505], [radius * .878, radius * .878, .061], pulp);
    for (let i = 0; i < 8; i++) {
        const t = i * tau / 8;
        scene.tube([[x, y, .569], [x + radius * .52 * Math.cos(t), y + radius * .52 * Math.sin(t), .56],
            [x + radius * .85 * Math.cos(t), y + radius * .85 * Math.sin(t), .54]], .012, pale);
    }
    scene.sphere([x, y, .567], .042, pale);
}

function strawberry(scene) {
    const profile = [[-.73, 0], [-.64, .22], [-.42, .38], [-.14, .53], [.2, .68], [.44, .68], [.62, .52], [.70, .20], [.72, 0]];
    lathe(scene, profile, '#c73b31', [0, 0, 0], .94, .04);
    for (const [row, [y, radius]] of profile.slice(2, 7).entries()) {
        for (let step = 0; step < 11; step++) {
            const a = (step + row * .48) * tau / 11;
            scene.ellipsoid([radius * .99 * Math.cos(a), y, radius * .934 * Math.sin(a)], [.022, .033, .019],
                row % 2 ? '#e8b371' : '#f5c977', [0, a, .18]);
        }
    }
    for (let l = 0; l < 6; l++) {
        const a = l * tau / 6;
        scene.ellipsoid([.24 * Math.cos(a), .65, .24 * Math.sin(a)], [.34, .042, .124], l % 2 ? '#49743c' : '#69954b', [0, -a, 0]);
    }
    stem(scene, 0, .66, 0, -.1);
}

function grape(scene) {
    const colors = ['#54325f', '#734667', '#63406c', '#806080', '#48345f'];
    for (const [tier, count] of [2, 3, 5, 6, 5].entries()) {
        for (let i = 0; i < count; i++) {
            const a = i * tau / count + tier * .68;
            const r = [.16, .23, .37, .44, .39][tier];
            const point = [r * Math.cos(a), -.79 + tier * .29 + .07 * Math.sin(i + 2 * tier), r * .94 * Math.sin(a)];
            scene.ellipsoid(point, [.244, .28, .23], colors[(i + 2 * tier) % colors.length]);
        }
    }
    stem(scene, .04, .5, 0, .21);
    leaf(scene, -.24, .68, -.09, .34, -.27, '#638e4c');
}

function clusterBerry(scene, colors, crown = false) {
    for (let group = 0; group < 3; group++) {
        const p = [(group - 1) * .62, group === 1 ? .32 : -.15, group === 2 ? .15 : -.10];
        if (crown) {
            scene.ellipsoid(p, [.36, .33, .35], colors[group]);
            for (let l = 0; l < 5; l++) {
                const a = l * tau / 5;
                scene.ellipsoid([p[0] + .09 * Math.cos(a), p[1] + .31, p[2] + .09 * Math.sin(a)], [.074, .036, .055], '#405276', [0, -a, 0]);
            }
            scene.sphere([p[0], p[1] + .301, p[2]], .049, '#2b3554');
        } else {
            for (let i = 0; i < 31; i++) {
                const y = (i + .5) * 2 / 31 - 1;
                const around = Math.sqrt(1 - y * y);
                const radius = .315 - .1 * Math.max(-y, 0);
                const a = i * 2.399963;
                const center = [p[0] + radius * around * Math.cos(a), p[1] + .37 * y, p[2] + radius * around * Math.sin(a)];
                scene.sphere(center, .113, colors[(i + group) % colors.length]);
            }
        }
    }
}

function banana(scene) {
    for (let n = 0; n < 3; n++) {
        const p = [[-.97, .64, -.27 + n * .29], [-.90, .35, -.29 + n * .31], [-.67, .04 - n * .11, -.31 + n * .33],
            [-.37, -.17 - n * .11, -.29 + n * .33], [0, -.25 - n * .09, -.27 + n * .34], [.4, -.21 - n * .04, -.26 + n * .32],
            [.73, -.035, -.25 + n * .26], [.91, .14, -.25 + n * .17], [1.02, .30, -.25 + n * .13]];
        scene.tube(p, [.059, .11, .161, .174, .153, .133, .091, .052, .029], ['#ecc03c', '#f4cb52', '#ebad38'][n]);
        scene.ellipsoid(p[0], [.059, .072, .055], '#655235');
    }
    scene.tube([[.97, .27, -.13], [1.12, .37, -.14], [1.26, .36, -.14]], [.106, .091, .048], '#778549');
}

function kiwi(scene) {
    scene.ellipsoid([-.54, .03, -.08], [.63, .49, .49], '#8c6140', [0, .3, -.25]);
    flecks(scene, [-.54, .03, -.08], [.61, .485, .485], 44, ['#785836', '#b18652'], .028);
    scene.ellipsoid([.52, -.16, .26], [.55, .53, .25], '#866044');
    scene.ellipsoid([.52, -.16, .43], [.524, .503, .117], '#83a641');
    scene.ellipsoid([.52, -.16, .523], [.138, .17, .029], '#e4d894');
    for (let i = 0; i < 22; i++) {
        const a = i * tau / 22;
        const r = .273 + .033 * Math.cos(i * 2);
        scene.ellipsoid([.52 + r * Math.cos(a), -.16 + r * Math.sin(a), .531], [.025, .013, .008], '#463e2b', [0, 0, a]);
    }
}

function mango(scene) {
    scene.ellipsoid([-.43, .07, -.1], [.54, .78, .45], '#eba131', [0, .21, -.53]);
    scene.ellipsoid([-.66, .28, -.127], [.36, .501, .429], '#d87839', [0, .02, -.36]);
    leaf(scene, -.23, .7, -.07, .33, -.12);
    scene.ellipsoid([.54, -.15, .35], [.45, .58, .26], '#d78027', [0, 0, -.44]);
    scene.ellipsoid([.54, -.15, .52], [.407, .53, .12], '#f8b83d', [0, 0, -.44]);
    for (let i = -2; i < 3; i++) {
        scene.tube([[.51 + i * .11, -.53, .566], [.53 + i * .14, -.15, .641], [.48 + i * .105, .17, .585]], .013, '#cc8527');
        scene.tube([[.22, -.15 + i * .145, .580], [.56, -.12 + i * .15, .644], [.83, -.09 + i * .12, .589]], .013, '#cc8527');
    }
}

function pineapple(scene) {
    scene.ellipsoid([0, -.25, 0], [.57, .79, .56], '#bd893c');
    for (let row = 0; row < 7; row++) {
        const y = -.94 + row * .21;
        const r = .577 * Math.sqrt(1 - ((y + .25) / .81) ** 2);
        for (let i = 0; i < 12; i++) {
            const a = (i + row * .50) * tau / 12;
            scene.box([r * Math.cos(a), y, r * Math.sin(a)], [.153, .145, .078], ['#a16f34', '#d59d3c', '#e1aa48'][(row + i) % 3],
                [0, Math.PI / 2 - a, .75]);
        }
    }
    for (let ring = 0; ring < 2; ring++) {
        for (let n = 0; n < 8; n++) {
            const a = n * tau / 8 + ring * .3;
            const reach = ring ? .20 : .38;
            scene.tube([[0, .39, 0], [.14 * Math.cos(a), .77, .14 * Math.sin(a)],
                [reach * Math.cos(a), ring ? 1.35 : 1.06, reach * Math.sin(a)]], [.095, .071, .005], ring ? '#6d9c47' : '#457e49');
        }
    }
}

function watermelon(scene) {
    const center = [-.38, .06, -.28];
    const [x, y, z] = center;
    scene.ellipsoid(center, [.88, .64, .61], '#4d7e48');
    for (let i = 0; i < 9; i++) {
        const points = Array.from({ length: 24 }, (_, step) => {
            const t = step * tau / 24;
            const a = (i + .16 * Math.sin(4 * t)) * tau / 9;
            return [x + .876 * Math.cos(t), y + .64 * Math.sin(t) * Math.cos(a), z + .61 * Math.sin(t) * Math.sin(a)];
        });
        scene.tube([...points, points[0]], .04, i % 2 ? '#7b9e57' : '#3b693d');
    }
    const slice = [.50, -.12, .35];
    scene.ellipsoid(slice, [.76, .55, .24], '#427342');
    scene.ellipsoid([.5, -.12, .493], [.718, .51, .121], '#d9ddab');
    scene.ellipsoid([.5, -.12, .55], [.675, .47, .086], '#dd6056');
    for (let i = 0; i < 12; i++) {
        const angle = i * 2.4;
        const radius = .18 + .011 * i;
        const u = Math.cos(angle) * radius;
        const v = Math.sin(angle) * radius;
        scene.ellipsoid([.5 + u, -.12 + v, .634 - v * v * .25 - u * u * .13], [.031, .052, .012], '#4b302e', [0, 0, angle]);
    }
}

function plums(scene) {
    scene.ellipsoid([-.51, .08, -.12], [.61, .69, .58], '#64416b', [0, 0, -.25]);
    scene.tube([[-.55, .72, .02], [-.64, .54, .38], [-.68, .16, .43], [-.68, -.21, .383]], .022, '#563955');
    stem(scene, -.54, .69, -.12, -.09);
    leaf(scene, -.29, .85, -.15, .28, -.23);
    scene.ellipsoid([.55, -.17, .24], [.50, .52, .28], '#773e71');
    scene.ellipsoid([.55, -.17, .44], [.461, .48, .091], '#e1ac58');
    scene.ellipsoid([.54, -.19, .52], [.14, .21, .043], '#93634c', [0, 0, .32]);
}

function cherries(scene) {
    for (const [x, y, z, color] of [[-.44, -.30, -.01, '#b82d47'], [.37, -.23, .07, '#aa2540']]) {
        scene.ellipsoid([x, y, z], [.43, .419, .41], color);
        scene.tube([[x, y + .34, z], [x * .82, .36, z], [x * .51, .68, z * .5], [.025, .89, 0]], [.035, .035, .028, .02], '#648346');
    }
    leaf(scene, .23, .78, -.04, .27, -.49, '#6d9b4a');
}

function melon(scene) {
    const center = [-.5, -.02, -.18];
    const radii = [.70, .6, .6];
    scene.ellipsoid(center, radii, '#a69770');
    for (let meridian = 0; meridian < 12; meridian++) {
        for (const shift of [-1, 1]) {
            const points = Array.from({ length: 12 }, (_, i) => {
                const t = Math.PI * (i + .3) / 12;
                const a = meridian * tau / 12 + shift * (t * .42 + Math.sin(i * 3) * .12);
                return [center[0] + .701 * Math.sin(t) * Math.cos(a), center[1] + .603 * Math.cos(t), center[2] + .601 * Math.sin(t) * Math.sin(a)];
            });
            scene.tube(points, .012, shift < 0 ? '#c0a97b' : '#bba882');
        }
    }
    scene.ellipsoid([.62, -.15, .26], [.64, .53, .25], '#9a9862');
    scene.ellipsoid([.62, -.15, .42], [.602, .489, .12], '#dba368');
    scene.ellipsoid([.62, -.15, .52], [.26, .213, .03], '#e4ba82');
    for (let n = 0; n < 18; n++) {
        const a = n * 2.4;
        const r = Math.sqrt(n / 18);
        scene.ellipsoid([.62 + .215 * r * Math.cos(a), -.15 + .17 * r * Math.sin(a), .549 - .018 * r], [.017, .039, .012], '#f3d8a3', [0, 0, a]);
    }
}

function greenApple(scene) {
    lathe(scene, [[-.63, .03], [-.58, .32], [-.4, .56], [-.13, .67], [.18, .73], [.41, .67], [.56, .52], [.61, .29], [.62, .03]],
        '#91aa45', [0, 0, 0], .97, .052);
    stem(scene, 0, .57, 0, .09);
    leaf(scene, .23, .74, -.06, .26, -.26, '#628748');
    flecks(scene, [0, -.032, 0], [.679, .607, .658], 31, ['#a9bb54', '#8aa144'], .021);
}

function figs(scene) {
    const shape = [[-.62, .01], [-.54, .29], [-.39, .47], [-.1, .52], [.14, .46], [.34, .32], [.55, .18], [.65, .105], [.68, .003]];
    lathe(scene, shape, '#675066', [-.46, .04, -.13], .95, .041);
    stem(scene, -.46, .64, -.13, -.03);
    scene.ellipsoid([.54, -.21, .31], [.49, .53, .24], '#6b4d64', [0, 0, .25]);
    scene.ellipsoid([.54, -.21, .467], [.451, .493, .105], '#e7bf9f', [0, 0, .25]);
    scene.ellipsoid([.54, -.25, .536], [.35, .38, .045], '#c16f75', [0, 0, .25]);
    for (let i = 0; i < 42; i++) {
        const a = i * 2.399963;
        const r = Math.sqrt(i / 42);
        scene.sphere([.54 + Math.cos(a) * .325 * r, -.25 + Math.sin(a) * .348 * r, .57 - .025 * r],
            .023, ['#df9a7e', '#b15b69', '#efb790'][i % 3]);
    }
}

function pomegranate(scene) {
    scene.ellipsoid([-.41, -.01, -.15], [.56, .62, .56], '#b0444a');
    const crown = [[.5, .06], [.57, .10], [.65, .13], [.72, .16], [.78, .08], [.80, .02]];
    lathe(scene, crown, '#934141', [-.41, 0, -.15]);
    for (let tooth = 0; tooth < 5; tooth++) {
        const a = tooth * tau / 5;
        scene.tube([[-.41 + .14 * Math.cos(a), .68, -.15 + .14 * Math.sin(a)],
            [-.41 + .18 * Math.cos(a), .82, -.15 + .18 * Math.sin(a)]], [.07, .011], '#8e4145');
    }
    scene.ellipsoid([.54, -.145, .27], [.55, .54, .25], '#a74446');
    scene.ellipsoid([.54, -.14, .45], [.515, .494, .091], '#e8bb9b');
    for (let i = 0; i < 54; i++) {
        const a = i * 2.399963;
        const r = Math.sqrt(i / 54);
        scene.ellipsoid([.54 + Math.cos(a) * .457 * r, -.14 + Math.sin(a) * .445 * r, .535 - r * r * .029],
            [.047, .049, .032], ['#bd4353', '#992f47', '#d76c6f', '#c14150'][i % 4]);
    }
}

function dragonFruit(scene) {
    scene.ellipsoid([-.43, 0, -.086], [.49, .77, .52], '#ca4c76');
    for (let n = 0; n < 12; n++) {
        const a = n * 2.399963;
        const y = -.49 + n * .087;
        const rr = .44 * Math.sqrt(1 - (y / .8) ** 2);
        scene.tube([[-.43 + rr * Math.cos(a), y, -.086 + rr * Math.sin(a)],
            [-.43 + (rr + .16) * Math.cos(a), y + .14, -.086 + (rr + .16) * Math.sin(a)],
            [-.43 + (rr + .24) * Math.cos(a), y + .27, -.086 + (rr + .24) * Math.sin(a)]], [.092, .063, .008], '#7d9d55');
    }
    scene.ellipsoid([.61, -.10, .31], [.46, .61, .24], '#c54772');
    scene.ellipsoid([.61, -.10, .45], [.414, .557, .12], '#f2e6df');
    for (let i = 0; i < 38; i++) {
        const a = i * 2.39;
        const r = Math.sqrt((i + .2) / 39);
        scene.ellipsoid([.61 + Math.cos(a) * r * .387, -.10 + Math.sin(a) * r * .519, .568 - r * r * .07],
            [.018, .012, .009], '#41383e', [0, 0, a]);
    }
}

const fruits = [
    ['apple', 'Apple', collectibleModels.apple, 'See the skin, leaf, stem and cut surface.'],
    ['blueberries', 'Blueberries', scene => clusterBerry(scene, ['#536d97', '#5e76a0', '#465580'], true), 'Rotate the berries to see the crown at the top of each one.'],
    ['orange', 'Orange', scene => citrus(scene, '#dd8129', '#f09d35', '#f2cc86'), 'See the whole rind and eight sections of the cut fruit.'],
    ['strawberry', 'Strawberry', strawberry, 'Look for the seeds on the surface and the leafy cap.'],
    ['plums', 'Plums', plums, 'Compare the skin and seam of a whole plum with a cut half.'],
    ['pineapple', 'Pineapple', pineapple, 'Rotate the rough rind and pointed crown.'],
    ['melon', 'Melon', melon, 'See the textured rind and the seed pocket inside the cut melon.'],
    ['pomegranate', 'Pomegranate', pomegranate, 'Explore the crown and the ruby-colored arils inside.'],
    ['banana', 'Banana', banana, 'Turn a three-banana bunch around its curved stems.'],
    ['kiwi', 'Kiwi', kiwi, 'Compare the brown skin with the green center and ring of seeds.'],
    ['grapefruit', 'Grapefruit', scene => citrus(scene, '#eeb364', '#e8837c', '#f9d5a3', 1.04), 'Compare the golden rind with the pink sections inside.'],
    ['watermelon', 'Watermelon', watermelon, 'Compare the striped rind with a slice of seeded flesh.'],
    ['blackberries', 'Blackberries', scene => clusterBerry(scene, ['#3f3552', '#534260', '#362b48']), 'See the small drupelets that form each blackberry.'],
    ['purple-grapes', 'Purple Grapes', grape, 'Examine the shape of the grape bunch and its leaf.'],
    ['avocado', 'Avocado', collectibleModels.avocado, 'Compare a whole avocado with a cut half and its pit.'],
    ['cherries', 'Cherries', cherries, 'Turn the pair around their joined stems.'],
    ['lemon', 'Lemon', scene => citrus(scene, '#e8ba35', '#eee063', '#fff0a5', .94, 1.16), 'Rotate a whole lemon beside its pale yellow sections.'],
    ['green-apple', 'Green Apple', greenApple, 'Turn the green skin, stem and leaf to view them from every side.'],
    ['figs', 'Figs', figs, 'Compare the dark skin with the pink center of a cut fig.'],
    ['dragon-fruit', 'Dragon Fruit', dragonFruit, 'Turn the pink, green-tipped skin and the speckled white flesh.'],
    ['raspberries', 'Raspberries', scene => clusterBerry(scene, ['#d55264', '#c2384f', '#aa364f']), 'See the small drupelets that form each raspberry.'],
    ['mango', 'Mango', mango, 'Explore a whole mango beside its scored cut surface.'],
];

const work = new URL('./fruit-posters/', import.meta.url);
const models = new URL('../../web/assets/explore/models/', import.meta.url);
mkdirSync(work, { recursive: true });
mkdirSync(models, { recursive: true });
for (const [slug, , build] of fruits) {
    const id = `fruit-${slug}`;
    writeFileSync(new URL(`${id}.glb`, models), buildGlb(build));
    writeFileSync(new URL(`${id}.png`, work), buildPoster(build, { width: 360, height: 264, azimuth: 18, elevation: 23 }));
}

const catalog = fruits.map(([slug, title, , description]) => ({ id: `fruit-${slug}`, title, description, original: false }));
writeFileSync(new URL('./fruit-catalog.json', import.meta.url), `${JSON.stringify(catalog, null, 2)}\n`);
