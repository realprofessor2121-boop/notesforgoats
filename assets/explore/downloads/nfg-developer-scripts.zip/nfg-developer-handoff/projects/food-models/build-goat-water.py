import json
import math
from pathlib import Path

import bpy
from mathutils import Vector


work = Path(__file__).resolve().parent
site = work.parents[1] / 'web/assets/explore'
(site / 'models').mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)


def material(name, rgb, roughness, alpha=1):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.diffuse_color = (*rgb, alpha)
    shader = material.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (*rgb, 1)
    shader.inputs['Roughness'].default_value = roughness
    shader.inputs['Alpha'].default_value = alpha
    if alpha < 1:
        material.surface_render_method = 'BLENDED'
    return material


def revolve(name, profile, surface, sides=96):
    verts = []
    faces = []
    for height, radius in profile:
        for side in range(sides):
            angle = (side / sides - .5) * math.tau
            verts.append((radius * math.sin(angle), -radius * math.cos(angle), height))
    for row in range(len(profile) - 1):
        for side in range(sides):
            a, b = row * sides + side, row * sides + (side + 1) % sides
            faces.append((a, b, b+sides, a+sides))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    mesh.materials.append(surface)
    uvs = mesh.uv_layers.new()
    for poly in mesh.polygons:
        poly.use_smooth = True
        ring, side = divmod(poly.index, sides)
        coordinates = [(side/sides, ring/(len(profile)-1)), ((side+1)/sides, ring/(len(profile)-1)),
                       ((side+1)/sides, (ring+1)/(len(profile)-1)), (side/sides, (ring+1)/(len(profile)-1))]
        for loop, uv in zip(poly.loop_indices, coordinates):
            uvs.data[loop].uv = uv
    return obj


plastic = material('Tinted bottle shell', (.44, .71, .78), .22, .39)
water = material('Water', (.095, .425, .548), .18)
cap = material('NFG navy cap', (.021, .044, .078), .37)
rib = material('Cap grip', (.037, .072, .113), .31)
gold = material('Gold cap band', (.57, .34, .076), .33)
label = material('NFG GOAT Water label', (.9, .86, .74), .62)
texture = label.node_tree.nodes.new('ShaderNodeTexImage')
texture.image = bpy.data.images.load(str(work / 'water-label.png'))
texture.image.pack()
label.node_tree.links.new(texture.outputs['Color'], label.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])

revolve('Bottle shell', [(-1.28,.001),(-1.28,.354),(-1.23,.455),(-1.15,.482),(-1.04,.495),(-.94,.473),(-.85,.501),
                         (-.74,.477),(-.65,.499),(-.54,.490),(-.29,.475),(.28,.475),(.57,.495),(.67,.475),(.78,.490),
                         (.89,.455),(1.03,.365),(1.18,.218),(1.27,.186),(1.42,.188)], plastic)
revolve('Water inside', [(-1.22,.001),(-1.22,.346),(-1.16,.441),(-1.08,.458),(-.75,.455),(-.57,.473),
                         (.37,.459),(.55,.473),(.64,.449),(.73,.458),(.80,.445),(.80,.001)], water)
revolve('Wraparound label', [(-.61,.503),(.585,.503)], label)
revolve('Cap seal', [(1.279,.001),(1.279,.202),(1.329,.202),(1.329,.001)], gold)
revolve('Cap', [(1.33,.001),(1.33,.207),(1.36,.218),(1.568,.218),(1.605,.195),(1.615,.001)], cap)
revolve('Cap embossed edge', [(1.589,.135),(1.600,.154),(1.609,.145)], gold)

for side in range(36):
    angle = side * math.tau / 36
    bpy.ops.mesh.primitive_cube_add(size=1, location=(.215*math.cos(angle), .215*math.sin(angle), 1.456))
    grip = bpy.context.object
    grip.name = 'Cap grip'
    grip.scale = (.027, .015, .147)
    grip.rotation_euler.z = angle
    grip.data.materials.append(rib)

bpy.ops.export_scene.gltf(filepath=str(site / 'models' / 'goat-water.glb'), export_format='GLB', export_animations=False)

scene = bpy.context.scene
scene.world.color = (.21, .21, .21)
scene.render.engine = 'CYCLES'
scene.cycles.samples = 32
scene.cycles.use_denoising = True
scene.render.film_transparent = True
scene.render.resolution_x = 420
scene.render.resolution_y = 313
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGBA'
scene.render.filepath = str(work / 'goat-water.png')

for loc, energy, size in (((-3,-4,5),340,3.8),((3,-2,2),130,2.7),((1,4,5),255,3.5)):
    bpy.ops.object.light_add(type='AREA', location=loc)
    light = bpy.context.object
    light.data.energy = energy
    light.data.shape = 'DISK'
    light.data.size = size
    light.rotation_euler = (Vector((0,0,.2)) - light.location).to_track_quat('-Z', 'Y').to_euler()

bpy.ops.object.camera_add(location=(.72,-6.6,2.35))
camera = bpy.context.object
camera.rotation_euler = (Vector((0,0,.17)) - camera.location).to_track_quat('-Z', 'Y').to_euler()
camera.data.type = 'ORTHO'
camera.data.ortho_scale = 4.39
scene.camera = camera

bpy.ops.wm.save_as_mainfile(filepath=str(work / 'goat-water-reconstruction.blend'))
bpy.ops.render.render(write_still=True)

catalog = {
    'id': 'goat-water',
    'title': 'NFG GOAT Water',
    'description': 'Rotate the NFG GOAT Water bottle to see the cap, wraparound label and original Notes For Goats logo.',
    'original': False,
}
(work / 'goat-water-catalog.json').write_text(json.dumps(catalog, indent=2) + '\n')
