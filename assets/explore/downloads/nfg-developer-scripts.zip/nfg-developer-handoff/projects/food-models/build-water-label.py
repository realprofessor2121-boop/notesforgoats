from math import sin
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


folder = Path(__file__).resolve().parent
width, height = 1024, 512
base = Image.new('RGB', (width, height), '#172332')
draw = ImageDraw.Draw(base)
gold = '#dfb857'
ivory = '#f7ecd1'
font_path = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

for y, color in ((19, gold), (30, '#547b80'), (481, '#547b80'), (492, gold)):
    draw.line((0, y, width, y), fill=color, width=5)

for offset in (-110, 86, 128, 162):
    points = [(x, int(254 + offset + 13 * sin(x / 41))) for x in range(0, width + 1, 6)]
    draw.line(points, fill='#2a5264', width=3)

draw.rounded_rectangle((286, 41, 738, 477), radius=28, fill=ivory, outline=gold, width=9)
draw.rounded_rectangle((303, 58, 721, 459), radius=16, outline='#b69858', width=4)

logo = Image.open(folder.parents[1] / 'web/logo.png.png').convert('RGBA')
logo = logo.crop(logo.getbbox())
logo.thumbnail((276, 158), Image.Resampling.LANCZOS)
base.paste(logo, ((width - logo.width) // 2, 80), logo)

def centered(text, y, size, color):
    font = ImageFont.truetype(font_path, size)
    draw.text((width // 2, y), text, anchor='mt', font=font, fill=color)

centered('GOAT', 256, 102, '#172332')
centered('WATER', 363, 62, '#305e73')
for x in (111, 913):
    draw.rounded_rectangle((x-73, 200, x+73, 311), radius=15, outline=gold, width=3)
    font = ImageFont.truetype(font_path, 47)
    draw.text((x, 254), 'NFG', font=font, anchor='mm', fill=ivory)

base.save(folder / 'water-label.png')
