NFG iPhone Duo concept preview

48-second video-on-device mockup. This is a newly generated dual-screen concept;
it is not the verified original NFG iPhone 18 Duo design or a factual Apple product.
The original NFG syllabus animation plays at unchanged speed on the left.
The right display retains the complete syllabus with a synchronized active-day marker.
The Journey audio is stream-copied from the previous finished NFG video, unchanged.

Run: python3 render.py
Requires Pillow, numpy, scipy, ffmpeg, ffprobe, and DejaVu Sans fonts.
Assets and source-relative paths are included. Source video is the existing
NFG_Syllabus_Journey_Soundtrack.mp4. Hardware art was generated using the built-in
image-generation tool, then used as a compositing plate.

Image prompt: Photorealistic front-on unfolded dual-screen folding smartphone
concept; two blank chroma-green portrait displays, titanium silver frame,
narrow hinge, navy studio background; no logos, hands, or text.

Review: representative composited frames inspected and output fully decoded.
Full audiovisual playback was unavailable in the authoring runtime.
