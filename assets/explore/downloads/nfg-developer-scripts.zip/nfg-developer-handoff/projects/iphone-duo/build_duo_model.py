from math import tau, cos, sin
from pathlib import Path

import bpy
from mathutils import Vector


ROOT = Path(__file__).parent
SITE = ROOT.resolve().parents[1] / 'web/assets/explore'


def color(name, rgba, metallic=0, roughness=.45):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    material.diffuse_color = (*rgba, 1)
    shader = material.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (*rgba, 1)
    shader.inputs['Metallic'].default_value = metallic
    shader.inputs['Roughness'].default_value = roughness
    return material


def rounded_outline(width, height, radius):
    points = []
    for index, (dx, dz) in enumerate(((1, 1), (-1, 1), (-1, -1), (1, -1))):
        cx = (width / 2 - radius) * dx
        cz = (height / 2 - radius) * dz
        for step in range(9):
            a = (index + step / 8) * tau / 4
            points.append((cx + radius * cos(a), cz + radius * sin(a)))
    return points


def handset_panel(name, cx, cy, cz, size, radius, finish, bevel=0, uv_rect=None):
    width, depth, height = size
    outline = rounded_outline(width, height, radius)
    count = len(outline)
    vertices = [(cx + x, cy + layer * depth / 2, cz + z) for layer in (-1, 1) for x, z in outline]
    faces = [tuple(range(count)), tuple(reversed(range(count, count * 2)))]
    for i in range(count):
        j = (i + 1) % count
        faces.append((j, i, count + i, count + j))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    mesh.materials.append(finish)
    for polygon in mesh.polygons[2:]:
        polygon.use_smooth = True
    if uv_rect:
        left, bottom, right, top = uv_rect
        uv = mesh.uv_layers.new(name='Original screen crop')
        for polygon in mesh.polygons:
            for corner in polygon.loop_indices:
                x, _, z = mesh.vertices[mesh.loops[corner].vertex_index].co
                u, v = (x - cx) / width + .5, (z - cz) / height + .5
                uv.data[corner].uv = (left + (right - left) * u, bottom + (top - bottom) * v)
    if bevel:
        edges = obj.modifiers.new('Machined edge', 'BEVEL')
        edges.width = bevel
        edges.segments = 3
        obj.modifiers.new('Weighted panel normals', 'WEIGHTED_NORMAL')
    return obj


def material_for_display():
    surface = color('Original NFG Duo video frame', (.02, .04, .08), 0, .42)
    texture = surface.node_tree.nodes.new('ShaderNodeTexImage')
    texture.image = bpy.data.images.load(str(ROOT / 'duo-texture-map.png'))
    shader = surface.node_tree.nodes.get('Principled BSDF')
    surface.node_tree.links.new(texture.outputs['Color'], shader.inputs['Base Color'])
    surface.node_tree.links.new(texture.outputs['Color'], shader.inputs['Emission Color'])
    shader.inputs['Emission Strength'].default_value = .42
    return surface


def aim(obj, point):
    obj.rotation_euler = (Vector(point) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def studio_light(name, location, power, size, color):
    data = bpy.data.lights.new(name, 'AREA')
    data.energy = power
    data.shape = 'DISK'
    data.size = size
    data.color = color
    light = bpy.data.objects.new(name, data)
    bpy.context.scene.collection.objects.link(light)
    light.location = location
    aim(light, (0, 0, 0))


def build():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.name = 'NFG iPhone Duo · Source-based Concept'
    scene['Provenance'] = 'Screen image from NFG_iPhone_Duo_Soundtrack.mp4 at 11.45 seconds'
    scene['Hardware'] = 'Simplified reconstruction of the supplied frontal concept. Rear detail is illustrative.'
    metal = color('Titanium concept frame', (.48, .49, .51), .67, .27)
    graphite = color('Rear panel · neutral graphite', (.095, .11, .13), .43, .32)
    black = color('Space black display bezel', (.009, .012, .018), .35, .28)
    seam = color('Hinge insert', (.03, .036, .047), .58, .33)
    screens = material_for_display()

    for i, name in enumerate(('Journey audio', 'Class syllabus')):
        x = (-1 if i == 0 else 1) * 1.225
        handset_panel(f'{name} · metal frame', x, 0, 0, (2.42, .20, 4.57), .285, metal, .035)
        handset_panel(f'{name} · rear panel', x, .102, 0, (2.30, .033, 4.43), .254, graphite, .012)
        handset_panel(f'{name} · inner bezel', x, -.106, 0, (2.33, .040, 4.45), .272, black, .016)
        x0 = (294, 795)[i]
        x1 = (742, 1243)[i]
        uv_rect = ((x0 + 2) / 1536, 1 - 929 / 1024, (x1 - 2) / 1536, 1 - 63 / 1024)
        handset_panel(f'{name} · authentic screen still', x, -.135, 0, (2.185, .008, 4.235), .247, screens, uv_rect=uv_rect)

    handset_panel('Center hinge spine', 0, .032, 0, (.122, .215, 4.52), .048, seam, .018)
    for z in (-2.035, -.91, .915, 2.04):
        handset_panel('Hinge support', 0, -.016, z, (.144, .224, .392), .063, metal, .014)
    for index, (x, z, length) in enumerate(((-2.447, 1.42, .34), (-2.447, .92, .32), (-2.447, .47, .41), (2.447, .89, .58))):
        handset_panel(f'Side control {index + 1}', x, -.003, z, (.065, .10, length), .025, metal, .008)

    (SITE / 'models').mkdir(parents=True, exist_ok=True)
    bpy.ops.export_scene.gltf(filepath=str(SITE / 'models/nfg-iphone-duo.glb'), export_format='GLB',
                              export_apply=True, export_cameras=False, export_lights=False)

    stage = color('Phone studio · navy', (.014, .024, .048), 0, .53)
    bpy.ops.mesh.primitive_plane_add(size=100, location=(0, 0, -2.29))
    bpy.context.object.data.materials.append(stage)
    scene.world = bpy.data.worlds.new('Navy studio')
    scene.world.use_nodes = True
    bg = scene.world.node_tree.nodes.get('Background')
    bg.inputs['Color'].default_value = (.12, .19, .32, 1)
    bg.inputs['Strength'].default_value = .36
    camera = bpy.data.objects.new('Product view', bpy.data.cameras.new('Product view'))
    scene.collection.objects.link(camera)
    camera.location = (3.75, -11.75, 2.23)
    aim(camera, (0, 0, -.03))
    camera.data.type = 'ORTHO'
    camera.data.ortho_scale = 7.7
    scene.camera = camera
    studio_light('Cool softbox', (3, -5, 6), 750, 6, (.70, .85, 1))
    studio_light('Warm fill', (-5, -4, 2), 425, 4, (1, .91, .80))
    studio_light('Rim light', (2, 2, 5), 900, 5, (.52, .74, 1))
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 14
    scene.cycles.use_denoising = False
    scene.view_settings.view_transform = 'Standard'
    scene.render.resolution_x = 780
    scene.render.resolution_y = 560
    scene.render.resolution_percentage = 100
    scene.render.filepath = str(ROOT / 'duo-model-preview.png')
    bpy.ops.render.render(write_still=True)


if __name__ == '__main__':
    build()
