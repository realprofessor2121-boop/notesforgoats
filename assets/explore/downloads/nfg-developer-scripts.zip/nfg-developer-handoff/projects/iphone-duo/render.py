from pathlib import Path
import json, subprocess
from scipy.ndimage import label, find_objects
import numpy as np
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent
base=Image.open(P/'assets/duo_concept.png').convert('RGB')
a=np.asarray(base);green=((a[:,:,1]>140)&(a[:,:,0]<80)&(a[:,:,2]<80)).astype('uint8')
lab,n=label(green)
regions=[]
for sy,sx in find_objects(lab):
 x,y=sx.start,sy.start;w,h=sx.stop-x,sy.stop-y
 if w*h>100000:regions.append([x,y,w,h,w*h])
regions.sort(key=lambda s:s[0])
assert len(regions)==2
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font=lambda n,b=False:ImageFont.truetype(bold if b else fontpath,n)
colors=['#30343d','#ed242f','#f79818','#f5d82c','#16ac42','#1673de','#932fc9','#f42798','#f6fafc']
names=['NOW','NEW','GAME','BUSINESS','MUSIC','DISTRIB','COLLECT','TROPHY','FUTURE']
cues=json.loads((P/'assets/timeline.json').read_text())['scene_starts']
source=Image.open(P/'assets/syllabus.jpg').convert('RGB')
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(P/'assets/syllabus_video.mp4')]))
vs=next(x for x in meta['streams'] if x['codec_type']=='video')
fps=24;count=int(vs['nb_frames']);duration=count/fps
vw,vh=vs['width'],vs['height']
cap=subprocess.Popen(['ffmpeg','-v','error','-i',str(P/'assets/syllabus_video.mp4'),'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
masks=[Image.fromarray(green[y:y+h,x:x+w]*255) for x,y,w,h,_ in regions]
def fit(im,w,h):
 r=min(w/im.width,h/im.height);return im.resize((round(im.width*r),round(im.height*r)),Image.Resampling.LANCZOS)
def screen(w,h,video,t,right=False):
 im=Image.new('RGB',(w,h),'#0c1422');d=ImageDraw.Draw(im)
 d.text((24,23),'NFG',font=font(25,True),fill='white')
 d.text((w-24,31),'CLASS' if right else 'NOW PLAYING',font=font(13,True),fill='#98b9cc',anchor='ra')
 d.text((24,76),'Your journey' if right else 'Let’s go on a journey',font=font(21,True),fill='white')
 tile=fit(source if right else video,w,h-245)
 yy=119+(h-245-tile.height)//2
 im.paste(tile,((w-tile.width)//2,yy))
 d=ImageDraw.Draw(im)
 active=next((j for j in range(9) if cues[j]<=t<cues[j+1]),-1)
 y=h-126
 if right:
  label=f'DAY {active} / {names[active]}' if active>=0 else 'ALL NINE DAYS'
  d.text((24,y),label,font=font(19,True),fill='white')
  for j,c in enumerate(colors):
   cx=33+j*(w-66)/8
   d.ellipse((cx-10,y+45,cx+10,y+65),fill=c)
   if j==active:d.ellipse((cx-14,y+41,cx+14,y+69),outline='white',width=2)
  if active>=0:
   # Follow the active column without obscuring its artwork.
   xx=(w-tile.width)//2+(active+.5)*tile.width/9
   d.line((xx,yy+tile.height*.32,xx,yy+tile.height*.92),fill=colors[active],width=2)
 else:
  d.text((24,y),'Journey',font=font(20,True),fill='white')
  d.text((24,y+29),'NFG SOUNDTRACK',font=font(12),fill='#98b9cc')
  d.line((24,y+65,w-24,y+65),fill='#334056',width=3)
  xp=24+(w-48)*t/duration
  d.line((24,y+65,xp,y+65),fill='#69d4f7',width=3)
  d.ellipse((xp-4,y+61,xp+4,y+69),fill='white')
  d.text((24,y+79),f'0:{int(t):02d}',font=font(12),fill='#b8cbd9')
  d.text((w-24,y+79),'0:48',font=font(12),fill='#b8cbd9',anchor='ra')
  d.rectangle((w-42,y+5,w-37,y+22),fill='white');d.rectangle((w-31,y+5,w-26,y+22),fill='white')
 return im
out=P/'picture.mp4'
p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{base.width}x{base.height}','-r',str(fps),'-i','-','-an','-c:v','libx264','-crf','18','-preset','fast','-pix_fmt','yuv420p',str(out)],stdin=subprocess.PIPE)
for i in range(count):
 raw=cap.stdout.read(vw*vh*3);assert len(raw)==vw*vh*3
 video=Image.frombytes("RGB",(vw,vh),raw);im=base.copy()
 for j,(x,y,w,h,_) in enumerate(regions):im.paste(screen(w,h,video,i/fps,j==1),(int(x),int(y)),masks[j])
 if i in [0,240,600]:im.save(P/f'check_{i}.jpg')
 p.stdin.write(im.tobytes())
p.stdin.close();assert p.wait()==0;cap.stdout.close();cap.wait()
subprocess.run(['ffmpeg','-v','error','-y','-i',str(out),'-i',str(P/'assets/syllabus_video.mp4'),'-map','0:v:0','-map','1:a:0','-c','copy','-movflags','+faststart',str(P.parent/'NFG_iPhone_Duo_Soundtrack.mp4')],check=True)
print('Rendered',duration,'seconds')
