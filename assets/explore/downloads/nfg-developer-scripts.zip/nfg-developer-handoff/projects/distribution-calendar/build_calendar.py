from pathlib import Path
import sys

import bpy
from mathutils import Vector


WORK = Path(__file__).resolve().parent
DISTRIBUTION = WORK.parents[1] / 'web/assets/explore'
FONT_DIR = Path('/usr/share/fonts/truetype/dejavu')
WEATHER_MODULE = WORK / 'weather_assets.py'
WEATHER = (
    ('sunny', 'Sunny'), ('partly_cloudy', 'Partly cloudy'),
    ('overcast', 'Overcast'), ('rain', 'Rain'), ('thunderstorm', 'Thunderstorm'),
    ('snow', 'Snow'), ('fog', 'Fog'), ('wind', 'Wind'),
)


def channel(value):
    unit = int(value, 16) / 255
    return unit / 12.92 if unit < .04045 else ((unit + .055) / 1.055) ** 2.4


def color(hexcode):
    return tuple(channel(hexcode[index:index+2]) for index in (0, 2, 4)) + (1,)


def material(name, hexcode, emission=0, metallic=0):
    value = bpy.data.materials.new(name)
    value.diffuse_color = color(hexcode)
    value.use_nodes = True
    shader = value.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = value.diffuse_color
    shader.inputs['Metallic'].default_value = metallic
    shader.inputs['Roughness'].default_value = .52
    shader.inputs['Emission Color'].default_value = value.diffuse_color
    shader.inputs['Emission Strength'].default_value = emission
    return value


def collection(name):
    item = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(item)
    return item


def move_to(obj, target):
    for group in list(obj.users_collection):
        group.objects.unlink(obj)
    target.objects.link(obj)


def panel(target, name, center, dimensions, finish, bevel=.055):
    bpy.ops.mesh.primitive_cube_add(size=1, location=center)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = dimensions
    move_to(obj, target)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if bevel:
        edge = obj.modifiers.new('Rounded edges', 'BEVEL')
        edge.width = bevel
        edge.segments = 3
        obj.modifiers.new('Weighted normals', 'WEIGHTED_NORMAL')
    obj.data.materials.append(finish)
    return obj


def disc(target, name, center, radius, depth, finish):
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=radius, depth=depth, location=center)
    obj = bpy.context.object
    obj.name = name
    move_to(obj, target)
    obj.data.materials.append(finish)
    edge = obj.modifiers.new('Disc edge', 'BEVEL')
    edge.width = min(.03, depth * .28)
    edge.segments = 3
    obj.modifiers.new('Disc normals', 'WEIGHTED_NORMAL')
    return obj


def label(target, name, copy, x, y, z, size, finish, font, width=None, alignment='LEFT'):
    data = bpy.data.curves.new(name, 'FONT')
    data.body = copy
    data.font = font
    data.size = size
    data.align_x = alignment
    data.align_y = 'CENTER'
    data.space_line = 1.17
    data.extrude = .0018
    data.resolution_u = 6
    data.materials.append(finish)
    obj = bpy.data.objects.new(name, data)
    target.objects.link(obj)
    obj.location = (x, y, z)
    if width:
        bpy.context.view_layer.update()
        if obj.dimensions.x > width:
            data.size *= width / obj.dimensions.x
    return obj


def look_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat('-Z', 'Y').to_euler()


def area(target, name, loc, power, size, tint):
    data = bpy.data.lights.new(name, 'AREA')
    data.energy = power
    data.shape = 'DISK'
    data.size = size
    data.color = tint
    obj = bpy.data.objects.new(name, data)
    target.objects.link(obj)
    obj.location = loc
    look_at(obj, (0, 0, 0))


def orthographic(target, name, position, focus, scale):
    data = bpy.data.cameras.new(name)
    data.type = 'ORTHO'
    data.ortho_scale = scale
    obj = bpy.data.objects.new(name, data)
    target.objects.link(obj)
    obj.location = position
    look_at(obj, focus)
    return obj


def pack_type(path, name):
    font = bpy.data.fonts.load(str(path), check_existing=True)
    font.name = name
    font.pack()
    return font


def text_block(name, contents):
    page = bpy.data.texts.new(name)
    page.clear()
    page.write(contents)
    page.use_fake_user = True
    return page


MONTHS = 'Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split()
QUARTERLY = ('Jan', 'Apr', 'Jul', 'Oct')
WRITER_ACCOUNTS = 'Payoneer / Pub Bank\nPayPal / TuneCore'
PUBLISHER_ACCOUNTS = 'Pub Bank / Payoneer\nPayPal'
EXCHANGE_ACCOUNTS = 'Payoneer / Bank\nPayPal'

# Source: NFG Royalty Distribution Calendar, refreshed v2 (Apr 11, 2026).
PORTALS = (
    ('Writer PRO', 'ASCAP Writer', 'Free', 'Quarterly', QUARTERLY, WRITER_ACCOUNTS, WRITER_ACCOUNTS),
    ('Writer PRO', 'BMI Writer', 'Free', 'Quarterly', QUARTERLY, WRITER_ACCOUNTS, WRITER_ACCOUNTS),
    ('Writer PRO', 'SESAC Writer', 'Invite-only', 'Varies', (), WRITER_ACCOUNTS, WRITER_ACCOUNTS),
    ('Publisher', 'ASCAP Publisher', '$50 one-time*', 'Quarterly', QUARTERLY, PUBLISHER_ACCOUNTS, PUBLISHER_ACCOUNTS),
    ('Publisher', 'BMI Publisher (LLC)', '$250 one-time', 'Quarterly', QUARTERLY, PUBLISHER_ACCOUNTS, PUBLISHER_ACCOUNTS),
    ('Publisher', 'Songtrust Admin', '$100 + commission', 'Varies', (), PUBLISHER_ACCOUNTS, PUBLISHER_ACCOUNTS),
    ('Mechanical', 'The MLC', 'Free', 'Monthly', MONTHS, PUBLISHER_ACCOUNTS, PUBLISHER_ACCOUNTS),
    ('Mechanical', 'HFA / Harry Fox', 'Commission / varies', 'Varies', (), PUBLISHER_ACCOUNTS, PUBLISHER_ACCOUNTS),
    ('Mechanical', 'Music Reports', 'Varies', 'Varies', (), PUBLISHER_ACCOUNTS, PUBLISHER_ACCOUNTS),
    ('Neighboring', 'SoundExchange', 'Free', 'Monthly', MONTHS, EXCHANGE_ACCOUNTS, EXCHANGE_ACCOUNTS),
    ('Distribution', 'TuneCore', 'From $24.99/yr', 'Monthly-ish', MONTHS, 'TuneCore / Payoneer\nBank / PayPal', 'Bank / Card / PayPal'),
    ('Distribution', 'SoundCloud Artist', 'Free / Pro plan', 'Monthly-ish', MONTHS, 'PayPal / Bank\nPayoneer', 'Card / PayPal / Bank'),
)

PALETTE = {
    'Writer PRO': 'F3C952',
    'Publisher': '61C8E5',
    'Mechanical': '79D4AB',
    'Neighboring': 'BD83DF',
    'Distribution': 'FF977C',
}
HEADERS = ['Type', 'Company / Portal', 'Join Cost', 'Cadence', *MONTHS, 'Receive To', 'Pay From']
WIDTHS = [2.38, 3.76, 2.58, 1.68, *([.61] * 12), 2.77, 2.77]
LEFT = -sum(WIDTHS) / 2


def prepare_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version = 0
    scene = bpy.context.scene
    scene.name = 'NFG Royalty Distribution Calendar'
    scene['Source'] = 'nfg_distribution_calendar_logic_v2_refreshed (Apr 11, 2026)'
    scene['Lesson'] = 'Yellow · 3.4 Royalties'
    scene['Calendar example month'] = 'Apr'
    scene['Expected payment markers'] = sum(len(portal[4]) for portal in PORTALS)
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = 2
    scene.render.resolution_x = 1680
    scene.render.resolution_y = 1120
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.film_transparent = False
    scene.view_settings.view_transform = 'Standard'
    scene.world = bpy.data.worlds.new('Studio surroundings')
    scene.world.use_nodes = True
    background = scene.world.node_tree.nodes.get('Background')
    background.inputs['Color'].default_value = (.42, .47, .54, 1)
    background.inputs['Strength'].default_value = .28
    return scene


def build_calendar():
    scene = prepare_scene()
    board = collection('01 · Calendar board')
    header = collection('02 · Titles and headings')
    rows = collection('03 · Editable portal rows')
    markers = collection('04 · Expected payment markers')
    key = collection('05 · Reading guide')
    weather = collection('06 · Weather symbols')
    studio = collection('07 · Cameras and studio')

    black = material('Black ink', '151819', .13)
    soft_black = material('Secondary ink', '424640', .17)
    white = material('White ink', 'FBF8F1', .4)
    navy = material('Header black', '192024')
    cream = material('Ivory board', 'F4EFE2')
    edge = material('Warm aluminum edge', '827044', 0, .55)
    sand = material('Alternating row · sand', 'EAE3D4')
    paper = material('Alternating row · paper', 'FFFCF4')
    light_yellow = material('Highlighted month', 'FFE6A6')
    month_cell = material('Month inset', 'F6F3EB')
    palette = {kind: material(kind, shade, .07) for kind, shade in PALETTE.items()}
    stage_finish = material('Studio black', '15191B')

    regular = pack_type(FONT_DIR / 'DejaVuSans.ttf', 'Calendar Sans')
    bold = pack_type(FONT_DIR / 'DejaVuSans-Bold.ttf', 'Calendar Sans Bold')
    mono = pack_type(FONT_DIR / 'DejaVuSansMono.ttf', 'Calendar Mono')

    panel(board, 'Border frame', (0, -1.11, -.196), (24.55, 16.00, .42), edge, .114)
    panel(board, 'Ivory writing surface', (0, -1.11, .021), (24.36, 15.80, .102), cream, .083)
    for horizontal in (-1, 1):
        for edge_y in (-8.67, 6.45):
            disc(board, f'Corner fastener {horizontal} {edge_y}', (horizontal * 11.93, edge_y, .091), .085, .047, edge)
    panel(studio, 'Studio backdrop', (0, 0, -.55), (110, 110, .10), stage_finish, 0)

    label(header, 'NFG Royalty Distribution Calendar', 'NFG ROYALTY DISTRIBUTION CALENDAR', LEFT, 6.10, .094, .56, black, bold, 17)
    label(header, 'Planner description', 'Choose one writer PRO. Add publisher or admin rows when they apply.', LEFT, 5.52, .094, .245, soft_black, regular, 17)
    panel(header, 'Source snapshot badge', (9.67, 5.91, .119), (3.86, .67, .10), navy, .067)
    label(header, 'Source snapshot', 'SOURCE SNAPSHOT\nAPR 11, 2026', 9.67, 5.91, .179, .183, white, mono, 3.50, 'CENTER')

    category_width = (sum(WIDTHS) - .65) / len(PALETTE)
    for index, (kind, finish) in enumerate(palette.items()):
        x = LEFT + category_width / 2 + index * (category_width + .1625)
        panel(header, f'{kind} legend', (x, 4.86, .118), (category_width, .45, .10), finish, .054)
        label(header, f'{kind} legend label', kind.upper(), x, 4.86, .18, .237, black, bold, category_width - .25, 'CENTER')

    centers = []
    cursor = LEFT
    for column, (heading, width) in enumerate(zip(HEADERS, WIDTHS)):
        x = cursor + width / 2
        centers.append(x)
        heading_panel = palette['Writer PRO'] if heading == 'Apr' else navy
        lettering = black if heading == 'Apr' else white
        panel(header, f'{heading} heading panel', (x, 4.06, .12), (width - .042, .51, .105), heading_panel, .039)
        label(header, f'{heading} heading', heading, x, 4.06, .184, .248 if 4 <= column < 16 else .255, lettering, bold, width - .12, 'CENTER')
        cursor += width

    for index, (kind, portal, cost, cadence, expected, receive, pay) in enumerate(PORTALS):
        y = 3.43 - index * .685
        tile = paper if index % 2 == 0 else sand
        row = bpy.data.collections.new(f'{index + 1:02d} · {portal}')
        rows.children.link(row)
        face = panel(row, f'{portal} row panel', (0, y, .113), (sum(WIDTHS), .632, .099), tile, .030)
        face['Category'] = kind
        face['Source cadence'] = cadence
        face['Expected windows'] = ', '.join(expected)
        panel(row, f'{portal} type panel', (centers[0], y, .185), (WIDTHS[0] - .20, .46, .11), palette[kind], .047)
        label(row, f'{portal} type', kind.upper(), centers[0], y, .25, .203, black, bold, WIDTHS[0] - .28, 'CENTER')
        for column, detail, typeface, size in ((1, portal, bold, .26), (2, cost, regular, .237), (3, cadence, regular, .224),
                                                (16, receive, regular, .205), (17, pay, regular, .205)):
            start = centers[column] - WIDTHS[column] / 2 + .15
            label(row, f'{portal} · {HEADERS[column]}', detail, start, y, .178, size, black, typeface, WIDTHS[column] - .26)
        for month_index, month in enumerate(MONTHS):
            x = centers[4 + month_index]
            fill = light_yellow if month == 'Apr' else month_cell
            panel(row, f'{portal} · {month} slot', (x, y, .174), (.565, .54, .053), fill, .028)
            if month in expected:
                marker = disc(markers, f'{portal} · {month} payment window', (x, y, .221), .079, .057, navy)
                marker['Portal'] = portal
                marker['Month'] = month

    guide = (
        ('Writer and publisher', 'Choose one writer PRO. Add applicable\npublisher or admin rows.', navy, white),
        ('Payment windows', 'Each dot is an expected payment window.\nApril is highlighted in the source snapshot.', palette['Writer PRO'], black),
        ('Payout planning', 'Receive To and Pay From record the\naccounts used for each portal.', palette['Mechanical'], black),
    )
    guide_width = (sum(WIDTHS) - .40) / 3
    for index, (heading, copy, finish, lettering) in enumerate(guide):
        x = LEFT + guide_width / 2 + index * (guide_width + .20)
        panel(key, f'{heading} guide panel', (x, -5.52, .133), (guide_width, 1.32, .125), finish, .067)
        label(key, f'{heading} guide title', heading, x - guide_width / 2 + .25, -5.20, .206, .285, lettering, bold, guide_width - .50)
        label(key, f'{heading} guide copy', copy, x - guide_width / 2 + .25, -5.68, .206, .226, lettering, regular, guide_width - .50)

    weather_finish = material('Weather strip · warm grey', 'E6DFCF')
    panel(weather, 'Weather symbol tray', (0, -7.47, .13), (sum(WIDTHS), 2.15, .122), weather_finish, .08)
    label(weather, 'Weather strip heading', 'Weather symbols', LEFT + .25, -6.62, .21, .283, black, bold, 10)
    label(weather, 'Weather strip use', 'Place a symbol where you need it.', -8.41, -6.62, .21, .218, soft_black, regular, 7.60)
    weather_centers = {slug: (-9.91 + index * (19.82 / 7), -7.45, .32) for index, (slug, _) in enumerate(WEATHER)}
    sys.path.insert(0, str(WEATHER_MODULE.parent))
    from weather_assets import create_weather_assets

    create_weather_assets(parent_collection=weather, positions=weather_centers)
    for slug, title in WEATHER:
        label(weather, f'{title} symbol name', title, weather_centers[slug][0], -8.12, .214, .204, black, bold, 2.6, 'CENTER')

    scene.camera = orthographic(studio, 'Front reading camera', (0, -1.66, 34), (0, -1.11, 0), 25.75)
    orthographic(studio, 'Oblique presentation camera', (4.7, -9.1, 29), (0, -1.11, 0), 27.75)
    area(studio, 'Key softbox', (-7, 7, 15), 1850, 12.2, (1, .94, .82))
    area(studio, 'Fill softbox', (10, -6, 13), 1350, 9.7, (.84, .92, 1))

    text_block('READ ME · Calendar', '''NFG ROYALTY DISTRIBUTION CALENDAR
Yellow · 3.4 Royalties

This editable Blender scene follows the refreshed NFG calendar dated Apr 11, 2026.
The costs, cadences, and expected payment windows reproduce that source snapshot.

Use the Outliner to find Editable portal rows. Each cell label is editable Text.
Select a label and enter Edit Mode with Tab to revise wording or account names.
Expected payment markers are named by company and month. Move, duplicate, hide,
or replace marker objects as planning changes.

The Weather symbols collection contains eight editable 3D assets. Select the
named root Empty to move a symbol as a group. To copy one, use Select Hierarchy
on its root in the Outliner, then duplicate the selection in the 3D Viewport.

Front reading camera is framed for the entire annual calendar. The oblique
presentation camera shows the board's detail and can be made active for renders.
Typography is packed in the file. Source spreadsheet inputs are not included.
''')

    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = None
    for workspace in bpy.data.workspaces:
        for screen in workspace.screens:
            for region in screen.areas:
                if region.type == 'VIEW_3D':
                    space = region.spaces.active
                    space.region_3d.view_perspective = 'CAMERA'
                    space.region_3d.view_camera_zoom = 4
                    space.overlay.show_overlays = False
                    space.shading.color_type = 'MATERIAL'
                elif region.type == 'PROPERTIES':
                    region.spaces.active.context = 'RENDER'

    scene.render.filepath = '//nfg-distribution-calendar.png'
    destination = DISTRIBUTION / 'downloads/nfg-distribution-calendar.blend'
    destination.parent.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(destination), compress=True)
    scene.render.filepath = str(WORK / 'calendar-render.png')
    bpy.ops.render.render(write_still=True)


if __name__ == '__main__':
    build_calendar()
