import json
from pathlib import Path
import sys

import bpy

sys.path.insert(0, str(Path(__file__).parent))
from build_calendar import area, collection, disc, label, look_at, material, orthographic, panel


SITE = Path(__file__).resolve().parents[2] / 'web'
TOKENS_SCENE = 'NFG Room Day Tokens'


def group_parent(root, child):
    transform = child.matrix_world.copy()
    child.parent = root
    child.matrix_world = transform


def generate():
    existing = bpy.data.scenes.get(TOKENS_SCENE)
    if existing:
        existing.camera.location = (0, -.1, 25)
        existing.camera.data.ortho_scale = 13.7
        look_at(existing.camera, (0, .48, 0))
        bpy.context.preferences.filepaths.save_version = 0
        bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath, compress=True)
        return
    calendar = bpy.context.scene
    file_path = bpy.data.filepath
    scene = bpy.data.scenes.new(TOKENS_SCENE)
    scene.world = calendar.world
    scene.render.engine = calendar.render.engine
    scene.cycles.samples = calendar.cycles.samples
    scene.cycles.use_denoising = False
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = 2
    scene.render.resolution_x = 1440
    scene.render.resolution_y = 1080
    scene.view_settings.view_transform = 'Standard'
    bpy.context.window.scene = scene
    scene['Use'] = 'Edit or append room-day tokens for a calendar date of your choice.'

    data_path = SITE / 'assets/explore/lessons.js'
    days = json.loads(data_path.read_text().split('=', 1)[1].strip().removesuffix(';'))
    studio = collection('Room day tokens · display')
    library = collection('Room day tokens · appendable assets')
    dark = bpy.data.materials['Black ink']
    white = bpy.data.materials['White ink']
    backdrop = bpy.data.materials['Studio black']
    matte = material('Room token · edge', '353835', .05, .22)
    regular = bpy.data.fonts['Calendar Sans']
    bold = bpy.data.fonts['Calendar Sans Bold']
    mono = bpy.data.fonts['Calendar Mono']

    panel(studio, 'Token view backdrop', (0, 0, -.33), (32, 26, .18), backdrop, 0)
    label(studio, 'Token scene title', 'NFG ROOM DAY TOKENS', -5.9, 4.60, .02, .44, white, bold, 11)
    label(studio, 'Token scene help', 'Move a day token to a calendar date of your choice.', -5.9, 4.05, .02, .235, white, regular, 11)

    for day in days:
        number, title = day['day'], day['title']
        group = bpy.data.collections.new(f'Room Day {number} · {title}')
        library.children.link(group)
        group.asset_mark()
        group.asset_data.description = f'Movable calendar token for NFG Day {number}, {title}.'
        root = bpy.data.objects.new(f'Move · Room Day {number}', None)
        root.empty_display_type = 'PLAIN_AXES'
        root.empty_display_size = .2
        x, y = (number % 3 - 1) * 4.02, 2.68 - (number // 3) * 2.62
        root.location = x, y, 0
        root['Course day'] = number
        root['Course title'] = title
        group.objects.link(root)

        fill = material(f'Room token · {title}', day['color'].strip('#'), .10, .06)
        parts = (
            panel(group, 'Card edge', (x, y, -.004), (3.74, 1.97, .23), matte, .095),
            panel(group, 'Card face', (x, y, .105), (3.69, 1.91, .12), fill, .08),
            disc(group, 'Day stamp', (x - 1.16, y, .171), .39, .085, dark),
            label(group, 'Day number', str(number), x - 1.16, y, .22, .48, white, bold, .55, 'CENTER'),
            label(group, 'Day label', f'DAY {number}', x - .62, y + .30, .184, .186, dark, mono, 2.16),
            label(group, 'Course title', title, x - .62, y - .12, .184, .28, dark, bold, 2.23),
        )
        bpy.context.view_layer.update()
        for part in parts:
            group_parent(root, part)

    scene.camera = orthographic(studio, 'Room token camera', (0, -.1, 25), (0, .48, 0), 13.7)
    area(studio, 'Room token light', (-5, 6, 14), 1350, 8, (1, .94, .82))
    area(studio, 'Room token fill', (4, -2, 10), 750, 7, (.84, .92, 1))
    read_me = bpy.data.texts['READ ME · Calendar']
    read_me.from_string(read_me.as_string() + '''
Choose NFG Room Day Tokens from the scene menu to find nine movable tokens.
For a token in another Blender scene, append its named collection or open
the asset browser with the Current File library. Keep its pieces grouped by
the named root Empty as you move it to a date you choose.
''')
    bpy.context.window.scene = calendar
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=file_path, compress=True)


if __name__ == '__main__':
    generate()
