import json
import os

import bpy


scene = bpy.context.scene
month_names = 'Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec'.split()
source_windows = {
    **{name: {'Jan', 'Apr', 'Jul', 'Oct'} for name in (
        'ASCAP Writer', 'BMI Writer', 'ASCAP Publisher', 'BMI Publisher (LLC)',
    )},
    **{name: set(month_names) for name in ('The MLC', 'SoundExchange', 'TuneCore', 'SoundCloud Artist')},
}
expected = {(portal, month) for portal, months in source_windows.items() for month in months}
portal_collection = bpy.data.collections['03 · Editable portal rows']
marker_collection = bpy.data.collections['04 · Expected payment markers']
weather_collection = bpy.data.collections['06 · Weather symbols']
seen = {(obj['Portal'], obj['Month']) for obj in marker_collection.objects}
assert len(portal_collection.children) == 12
assert all(len([obj for obj in row.objects if obj.name.endswith(' slot')]) == 12 for row in portal_collection.children)
assert len(marker_collection.objects) == len(seen) == 64
assert seen == expected
assert all(bpy.data.fonts[name].packed_file for name in ('Calendar Sans', 'Calendar Sans Bold', 'Calendar Mono'))
assert len([obj for obj in bpy.data.objects if obj.type == 'FONT']) >= 100
assert scene.camera.name == 'Front reading camera'
assert len([obj for obj in scene.objects if obj.type == 'CAMERA']) == 2
weather_symbols = [item for group in weather_collection.children for item in group.children]
if os.environ.get('NFG_WEATHER_REQUIRED', '1') == '1':
    assert len(weather_symbols) == 8
    assert all(any(obj.type == 'MESH' for obj in group.all_objects) for group in weather_symbols)
    assert all(any(obj.type == 'EMPTY' for obj in group.all_objects) for group in weather_symbols)

token_scene = bpy.data.scenes['NFG Room Day Tokens']
tokens = list(token_scene.collection.children['Room day tokens · appendable assets'].children)
assert len(tokens) == 9
assert all(token.asset_data for token in tokens)
roots = [obj for token in tokens for obj in token.objects if obj.type == 'EMPTY']
assert {obj['Course day'] for obj in roots} == set(range(9))
assert all(len(obj.children) == 6 for obj in roots)
print(json.dumps({
    'scene': scene.name,
    'portal_rows': len(portal_collection.children),
    'expected_payment_windows': len(seen),
    'weather_symbol_groups': [group.name for group in weather_symbols],
    'appendable_room_tokens': [item.name for item in tokens],
    'packed_fonts': [font.name for font in bpy.data.fonts if font.packed_file],
    'cameras': [obj.name for obj in bpy.data.objects if obj.type == 'CAMERA'],
}))
