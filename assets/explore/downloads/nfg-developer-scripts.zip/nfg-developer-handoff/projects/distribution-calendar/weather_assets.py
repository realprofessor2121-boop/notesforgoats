"""Editable, beveled 3D weather symbols for the NFG distribution calendar."""

import math

import bpy


WEATHER_NAMES = {
    "sunny": "Sunny",
    "partly_cloudy": "Partly cloudy",
    "overcast": "Overcast",
    "rain": "Rain",
    "thunderstorm": "Thunderstorm",
    "snow": "Snow",
    "fog": "Fog",
    "wind": "Wind",
}

PALETTE = {
    "amber": ("F5AA16", 0.07),
    "gold": ("FFD03C", 0.13),
    "cream": ("FFF2AD", 0.13),
    "deep": ("2A415B", 0.05),
    "slate": ("566F89", 0.08),
    "steel": ("839CB3", 0.06),
    "mist": ("B7D2E5", 0.09),
    "white": ("F1F9FE", 0.13),
    "teal": ("006879", 0.03),
    "cyan": ("209CB3", 0.08),
    "ice": ("79D7E3", 0.12),
}


def finish(name):
    identifier = f"NFG weather · {name}"
    existing = bpy.data.materials.get(identifier)
    if existing:
        return existing

    hexcode, glow = PALETTE[name]

    def linear(index):
        value = int(hexcode[index:index + 2], 16) / 255.0
        return value / 12.92 if value < 0.04045 else ((value + 0.055) / 1.055) ** 2.4

    color = (linear(0), linear(2), linear(4), 1)
    material = bpy.data.materials.new(identifier)
    material.diffuse_color = color
    material.use_nodes = True
    shader = material.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = color
    shader.inputs["Emission Color"].default_value = color
    shader.inputs["Emission Strength"].default_value = glow
    shader.inputs["Metallic"].default_value = 0.16
    shader.inputs["Roughness"].default_value = 0.34
    return material


def outline(start, segments, samples=9):
    points = [start]
    for control_a, control_b, end in segments:
        x0, y0 = points[-1]
        x1, y1 = control_a
        x2, y2 = control_b
        x3, y3 = end
        for step in range(1, samples + 1):
            t = step / samples
            u = 1.0 - t
            points.append((
                u ** 3 * x0 + 3 * u ** 2 * t * x1 + 3 * u * t ** 2 * x2 + t ** 3 * x3,
                u ** 3 * y0 + 3 * u ** 2 * t * y1 + 3 * u * t ** 2 * y2 + t ** 3 * y3,
            ))
    return points[:-1] if points[0] == points[-1] else points


CLOUD = outline(
    (-0.34, -0.18),
    (
        ((-0.58, -0.18), (-0.62, 0.10), (-0.37, 0.12)),
        ((-0.32, 0.27), (-0.08, 0.31), (0.04, 0.17)),
        ((0.16, 0.27), (0.34, 0.22), (0.40, 0.12)),
        ((0.60, 0.10), (0.56, -0.18), (0.37, -0.18)),
        ((0.21, -0.18), (-0.17, -0.18), (-0.34, -0.18)),
    ),
)

DROP = outline(
    (-0.012, 0.102),
    (
        ((0.007, 0.078), (0.071, 0.003), (0.071, -0.038)),
        ((0.071, -0.128), (-0.071, -0.13), (-0.071, -0.04)),
        ((-0.071, 0.001), (-0.032, 0.064), (-0.012, 0.102)),
    ),
)


def mesh_profile(group, root, name, points, z, depth, color, bevel=0.015):
    count = len(points)
    area = sum(x * points[(index + 1) % count][1] - points[(index + 1) % count][0] * y
               for index, (x, y) in enumerate(points))
    if area < 0:
        points = list(reversed(points))

    vertices = [(x, y, height) for height in (z - depth / 2, z + depth / 2) for x, y in points]
    faces = [tuple(reversed(range(count))), tuple(range(count, 2 * count))]
    for index in range(count):
        next_index = (index + 1) % count
        faces.append((index, next_index, count + next_index, count + index))

    geometry = bpy.data.meshes.new(name)
    geometry.from_pydata(vertices, [], faces)
    geometry.update()
    item = bpy.data.objects.new(name, geometry)
    group.objects.link(item)
    item.parent = root
    item.data.materials.append(finish(color))

    if bevel:
        corners = item.modifiers.new("Round profile edges", "BEVEL")
        corners.width = bevel
        corners.segments = 3
        corners.limit_method = "ANGLE"
        normals = item.modifiers.new("Preserve flat faces", "WEIGHTED_NORMAL")
        normals.keep_sharp = True
    return item


def move(points, x=0, y=0, scale=1):
    return [(x + scale * px, y + scale * py) for px, py in points]


def disk(group, root, name, x, y, radius, z, depth, color):
    points = [(x + radius * math.cos(i * math.tau / 48), y + radius * math.sin(i * math.tau / 48))
              for i in range(48)]
    return mesh_profile(group, root, name, points, z, depth, color, bevel=min(depth / 3, 0.015))


def rounded_bar(group, root, name, start, end, radius, z, depth, color):
    angle = math.atan2(end[1] - start[1], end[0] - start[0])
    points = []
    for i, (x, y) in enumerate((end, start)):
        for step in range(9):
            offset = angle - math.pi / 2 + i * math.pi + step * math.pi / 8
            points.append((x + radius * math.cos(offset), y + radius * math.sin(offset)))
    return mesh_profile(group, root, name, points, z, depth, color, bevel=min(radius / 2, 0.012))


def sun(group, root, x=0, y=0, scale=1, z=0):
    for i in range(8):
        angle = i * math.tau / 8
        vector = (math.cos(angle) * scale, math.sin(angle) * scale)
        start = (x + 0.30 * vector[0], y + 0.30 * vector[1])
        end = (x + 0.382 * vector[0], y + 0.382 * vector[1])
        rounded_bar(group, root, f"Sun ray {i + 1}", start, end, 0.035 * scale, z, 0.085, "amber")
    disk(group, root, "Sun amber rim", x, y, 0.247 * scale, z, 0.145, "amber")
    disk(group, root, "Sun gold face", x, y, 0.220 * scale, z + 0.065, 0.090, "gold")
    rounded_bar(group, root, "Sun highlight", (x - 0.105 * scale, y + 0.104 * scale),
                (x - 0.052 * scale, y + 0.150 * scale), 0.014 * scale,
                z + 0.117, 0.015, "cream")


def cloud(group, root, label, x, y, z, scale=1, color="white", rim="slate"):
    mesh_profile(group, root, f"{label} rim", move(CLOUD, x, y - 0.011, 1.075 * scale),
                 z, 0.110, rim)
    mesh_profile(group, root, f"{label} face", move(CLOUD, x, y, scale),
                 z + 0.048, 0.116, color)


def sunny(group, root):
    sun(group, root)


def partly_cloudy(group, root):
    sun(group, root, x=-0.24, y=0.15, z=-0.038, scale=0.61)
    cloud(group, root, "Foreground cloud", 0.12, -0.12, 0.05, scale=0.82)


def overcast(group, root):
    cloud(group, root, "Rear cloud", -0.13, 0.14, -0.047, scale=0.84, color="steel", rim="deep")
    cloud(group, root, "Foreground cloud", 0.09, -0.12, 0.047, scale=0.88,
          color="mist", rim="slate")


def rain(group, root):
    cloud(group, root, "Rain cloud", 0, 0.15, 0.04, scale=0.94,
          color="mist", rim="slate")
    for i, (x, y) in enumerate(((-0.24, -0.21), (0, -0.29), (0.24, -0.21)), start=1):
        mesh_profile(group, root, f"Rain drop {i}", move(DROP, x, y, 0.85), 0.035, 0.09, "cyan")
        rounded_bar(group, root, f"Rain drop {i} glint", (x - 0.021, y - 0.008),
                    (x - 0.011, y + 0.030), 0.009, 0.087, 0.012, "ice")


def thunderstorm(group, root):
    cloud(group, root, "Thundercloud", 0, 0.15, 0.034, scale=0.95,
          color="steel", rim="deep")
    bolt = [(-0.042, 0.155), (0.195, 0.155), (0.074, -0.050), (0.192, -0.050),
            (-0.147, -0.415), (-0.054, -0.148), (-0.168, -0.148)]
    mesh_profile(group, root, "Lightning amber edge", bolt, 0.074, 0.13, "amber")
    mesh_profile(group, root, "Lightning gold face", move(bolt, 0, -0.014, 0.88),
                 0.136, 0.043, "gold", bevel=0.007)


def snowflake(group, root, x, y, scale, alternate=False):
    color = "slate" if alternate else "cyan"
    disk(group, root, "Snowflake center", x, y, 0.029 * scale, 0.043, 0.080, "slate")
    for i in range(6):
        angle = i * math.tau / 6 + math.pi / 2
        branch = (math.cos(angle), math.sin(angle))
        tip = (x + branch[0] * 0.115 * scale, y + branch[1] * 0.115 * scale)
        rounded_bar(group, root, f"Snowflake arm {i + 1}", (x, y), tip, 0.012 * scale,
                    0.043, 0.075, color)
        if not alternate:
            split = (x + branch[0] * 0.066 * scale, y + branch[1] * 0.066 * scale)
            for sign in (-1, 1):
                spur = angle + sign * math.pi / 3
                outer = (split[0] + math.cos(spur) * 0.030 * scale,
                         split[1] + math.sin(spur) * 0.030 * scale)
                rounded_bar(group, root, f"Snowflake fork {i + 1} {sign}", split, outer,
                            0.009 * scale, 0.043, 0.066, color)


def snow(group, root):
    cloud(group, root, "Snow cloud", 0, 0.16, 0.044, scale=0.93, color="white", rim="slate")
    snowflake(group, root, -0.25, -0.18, 0.62, alternate=True)
    snowflake(group, root, 0, -0.27, 1.1)
    snowflake(group, root, 0.25, -0.18, 0.62, alternate=True)


def fog(group, root):
    cloud(group, root, "Fog bank", 0, 0.15, -0.029, scale=0.87, color="mist", rim="slate")
    for i, (left, right, y) in enumerate(((-0.49, 0.35, 0.01), (-0.39, 0.47, -0.135),
                                           (-0.49, 0.24, -0.28)), start=1):
        rounded_bar(group, root, f"Fog ribbon {i}", (left, y), (right, y), 0.040,
                    0.068, 0.104, "steel")
        rounded_bar(group, root, f"Fog highlight {i}", (left + 0.02, y + 0.007),
                    (right - 0.015, y + 0.007), 0.020, 0.119, 0.034, "mist")


def curved_bar(group, root, name, points, radius, z, color):
    points = [(x * 0.86, y) for x, y in points]
    data = bpy.data.curves.new(name, "CURVE")
    data.dimensions = "3D"
    data.bevel_depth = 1.0
    data.bevel_resolution = 3
    data.use_fill_caps = True
    path = data.splines.new("BEZIER")
    path.bezier_points.add(len(points) - 1)
    for point, (x, y) in zip(path.bezier_points, points):
        point.co = x, y, z
        point.radius = radius
        point.handle_left_type = "AUTO"
        point.handle_right_type = "AUTO"
    data.materials.append(finish(color))
    item = bpy.data.objects.new(name, data)
    group.objects.link(item)
    item.parent = root
    for suffix, (x, y) in zip(("start", "end"), (points[0], points[-1])):
        disk(group, root, f"{name} round {suffix}", x, y, radius, z, 1.45 * radius, color)


def wind(group, root):
    curved_bar(group, root, "Wind high curl",
               [(-0.39, 0.19), (0.13, 0.19), (0.27, 0.26), (0.24, 0.36), (0.14, 0.35)],
               0.045, 0.036, "cyan")
    curved_bar(group, root, "Wind middle curl",
               [(-0.52, -0.01), (0.33, -0.01), (0.51, 0.08), (0.49, 0.20), (0.38, 0.21)],
               0.058, 0.014, "teal")
    curved_bar(group, root, "Wind low curl",
               [(-0.38, -0.21), (0.08, -0.21), (0.22, -0.27), (0.17, -0.34), (0.09, -0.325)],
               0.043, 0.036, "cyan")


BUILDERS = {
    "sunny": sunny,
    "partly_cloudy": partly_cloudy,
    "overcast": overcast,
    "rain": rain,
    "thunderstorm": thunderstorm,
    "snow": snow,
    "fog": fog,
    "wind": wind,
}


def create_weather_assets(parent_collection=None, anchor=(0, 0, 0), scale=1.0, positions=None):
    """Return eight individually movable editable weather collections.

    Place the model roots with an absolute XYZ mapping keyed by WEATHER_NAMES.
    Unspecified centers use a four-column grid relative to anchor. X runs to
    the right, Y up, and positive Z faces out from the calendar.
    """
    destination = parent_collection or bpy.context.scene.collection
    weather = bpy.data.collections.new("NFG · 3D weather symbols")
    destination.children.link(weather)
    placements = positions or {}
    collections = {}

    for i, (key, name) in enumerate(WEATHER_NAMES.items()):
        group = bpy.data.collections.new(f"Weather · {name}")
        weather.children.link(group)
        root = bpy.data.objects.new(f"Move · {name}", None)
        root.empty_display_type = "PLAIN_AXES"
        root.empty_display_size = 0.17
        root.location = placements.get(key, (anchor[0] + (i % 4 - 1.5) * 1.50 * scale,
                                             anchor[1] + (0.5 - i // 4) * 1.05 * scale,
                                             anchor[2]))
        root.scale = (scale,) * 3
        root["Weather condition"] = name
        group.objects.link(root)
        BUILDERS[key](group, root)
        collections[key] = group

    return collections
