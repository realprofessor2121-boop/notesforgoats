import { deflateSync } from 'node:zlib';

const SEGMENTS = 16;
const RINGS = 10;
const TUBE_SEGMENTS = 8;
const TAU = 2 * Math.PI;

const add = (a, b) => a.map((value, axis) => value + b[axis]);
const subtract = (a, b) => a.map((value, axis) => value - b[axis]);
const scale = (vector, factor) => vector.map(value => value * factor);
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [
    a[1] * b[2] - a[2] * b[1],
    a[2] * b[0] - a[0] * b[2],
    a[0] * b[1] - a[1] * b[0]
];
const magnitude = vector => Math.hypot(...vector);
const normalize = vector => {
    const length = magnitude(vector);
    return length > 1e-9 ? scale(vector, 1 / length) : [0, 0, 0];
};

function rotateVector([xAngle, yAngle, zAngle]) {
    const [cx, cy, cz] = [xAngle, yAngle, zAngle].map(Math.cos);
    const [sx, sy, sz] = [xAngle, yAngle, zAngle].map(Math.sin);
    return ([x, y, z]) => {
        const y1 = cx * y - sx * z;
        const z1 = sx * y + cx * z;
        const x2 = cy * x + sy * z1;
        return [cz * x2 - sz * y1, sz * x2 + cz * y1, -sy * x + cy * z1];
    };
}

function getColor(color) {
    if (!/^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(color)) {
        throw new Error(`Expected a hex material color, received ${color}`);
    }
    let hex = color.slice(1).toLowerCase();
    if (hex.length === 3) hex = [...hex].map(character => character.repeat(2)).join('');
    return hex;
}

function toLinear(channel) {
    return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
}

function toByte(channel) {
    const bounded = Math.max(0, Math.min(1, channel));
    return Math.round(255 * (bounded <= 0.0031308 ? bounded * 12.92 : 1.055 * bounded ** (1 / 2.4) - 0.055));
}

const BOX_FACES = [
    [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
    [[-1, 0, 0], [0, -1, 0], [0, 0, 1]],
    [[0, 1, 0], [0, 0, 1], [1, 0, 0]],
    [[0, -1, 0], [0, 0, -1], [1, 0, 0]],
    [[0, 0, 1], [1, 0, 0], [0, 1, 0]],
    [[0, 0, -1], [-1, 0, 0], [0, 1, 0]]
];
const BOX_CORNERS = [[-1, -1], [1, -1], [1, 1], [-1, 1]];

class Scene {
    batches = new Map();

    material(color) {
        const hex = getColor(color);
        if (!this.batches.has(hex)) {
            const rgb = hex.match(/../g).map(channel => toLinear(parseInt(channel, 16) / 255));
            this.batches.set(hex, { hex, rgb, positions: [], normals: [], indices: [] });
        }
        return this.batches.get(hex);
    }

    box(center, dimensions, color, rotation = [0, 0, 0]) {
        const batch = this.material(color);
        const rotate = rotateVector(rotation);
        for (const [normal, across, vertical] of BOX_FACES) {
            const first = batch.positions.length / 3;
            const outward = rotate(normal);
            for (const [u, v] of BOX_CORNERS) {
                const corner = add(normal, add(scale(across, u), scale(vertical, v)));
                const position = corner.map((value, axis) => value * dimensions[axis] / 2);
                batch.positions.push(...add(center, rotate(position)));
                batch.normals.push(...outward);
            }
            batch.indices.push(first, first + 1, first + 2, first, first + 2, first + 3);
        }
    }

    ellipsoid(center, radii, color, rotation = [0, 0, 0]) {
        const batch = this.material(color);
        const rotate = rotateVector(rotation);
        const first = batch.positions.length / 3;
        for (let ring = 0; ring <= RINGS; ring += 1) {
            const latitude = Math.PI * (ring / RINGS - 0.5);
            for (let step = 0; step < SEGMENTS; step += 1) {
                const longitude = TAU * step / SEGMENTS;
                const unit = [
                    Math.cos(latitude) * Math.cos(longitude),
                    Math.sin(latitude),
                    Math.cos(latitude) * Math.sin(longitude)
                ];
                const position = unit.map((value, axis) => value * radii[axis]);
                const outward = normalize(unit.map((value, axis) => value / radii[axis]));
                batch.positions.push(...add(center, rotate(position)));
                batch.normals.push(...rotate(outward));
            }
        }
        for (let ring = 0; ring < RINGS; ring += 1) {
            for (let step = 0; step < SEGMENTS; step += 1) {
                const next = (step + 1) % SEGMENTS;
                const a = first + ring * SEGMENTS + step;
                const b = a + SEGMENTS;
                const d = first + ring * SEGMENTS + next;
                const c = d + SEGMENTS;
                if (ring !== RINGS - 1) batch.indices.push(a, b, c);
                if (ring !== 0) batch.indices.push(a, c, d);
            }
        }
    }

    sphere(center, radius, color) {
        this.ellipsoid(center, [radius, radius, radius], color);
    }

    tube(points, radius, color) {
        const path = [];
        const radii = [];
        for (const [index, point] of points.entries()) {
            if (path.length && magnitude(subtract(point, path.at(-1))) < 1e-8) continue;
            path.push(point);
            radii.push(Array.isArray(radius) ? radius[index] : radius);
        }
        if (path.length < 2) return;

        const batch = this.material(color);
        const first = batch.positions.length / 3;
        const tangents = [];
        let across;
        for (const [index, point] of path.entries()) {
            const previous = path[Math.max(0, index - 1)];
            const next = path[Math.min(index + 1, path.length - 1)];
            const direction = normalize(subtract(next, previous));
            const tangent = magnitude(direction) ? direction : normalize(subtract(point, previous));
            const projected = across && subtract(across, scale(tangent, dot(across, tangent)));
            const reference = Math.abs(tangent[1]) < 0.85 ? [0, 1, 0] : [1, 0, 0];
            across = projected && magnitude(projected) > 1e-4
                ? normalize(projected)
                : normalize(cross(tangent, reference));
            const around = cross(tangent, across);
            tangents.push(tangent);
            for (let step = 0; step < TUBE_SEGMENTS; step += 1) {
                const angle = TAU * step / TUBE_SEGMENTS;
                const radial = add(scale(across, Math.cos(angle)), scale(around, Math.sin(angle)));
                batch.positions.push(...add(point, scale(radial, radii[index])));
                batch.normals.push(...radial);
            }
        }
        for (let index = 0; index < path.length - 1; index += 1) {
            for (let step = 0; step < TUBE_SEGMENTS; step += 1) {
                const a = first + index * TUBE_SEGMENTS + step;
                const b = first + index * TUBE_SEGMENTS + (step + 1) % TUBE_SEGMENTS;
                batch.indices.push(a, b, a + TUBE_SEGMENTS, b, b + TUBE_SEGMENTS, a + TUBE_SEGMENTS);
            }
        }
        this.capTube(batch, path[0], scale(tangents[0], -1), first, true);
        this.capTube(batch, path.at(-1), tangents.at(-1), first + (path.length - 1) * TUBE_SEGMENTS, false);
    }

    capTube(batch, center, normal, ring, reverse) {
        const first = batch.positions.length / 3;
        batch.positions.push(...center);
        batch.normals.push(...normal);
        for (let step = 0; step < TUBE_SEGMENTS; step += 1) {
            const offset = 3 * (ring + step);
            batch.positions.push(...batch.positions.slice(offset, offset + 3));
            batch.normals.push(...normal);
        }
        for (let step = 0; step < TUBE_SEGMENTS; step += 1) {
            const a = first + 1 + step;
            const b = first + 1 + (step + 1) % TUBE_SEGMENTS;
            batch.indices.push(first, reverse ? b : a, reverse ? a : b);
        }
    }
}

function generateScene(build) {
    const scene = new Scene();
    build(scene);
    const batches = [...scene.batches.values()].filter(batch => batch.indices.length);
    if (!batches.length) throw new Error('The model has no geometry');
    return batches;
}

function boundsOf(positions, stride) {
    const min = Array(stride).fill(Infinity);
    const max = Array(stride).fill(-Infinity);
    for (let index = 0; index < positions.length; index += stride) {
        for (let axis = 0; axis < stride; axis += 1) {
            const value = positions[index + axis];
            min[axis] = Math.min(min[axis], value);
            max[axis] = Math.max(max[axis], value);
        }
    }
    return { min, max };
}

export function buildGlb(build) {
    const batches = generateScene(build);
    const accessors = [];
    const bufferViews = [];
    const chunks = [];
    let byteLength = 0;

    function accessor(array, componentType, type, count, target, bounds = {}) {
        const buffer = Buffer.from(array.buffer, array.byteOffset, array.byteLength);
        bufferViews.push({ buffer: 0, byteOffset: byteLength, byteLength: buffer.length, target });
        chunks.push(buffer);
        const padding = (4 - buffer.length % 4) % 4;
        if (padding) chunks.push(Buffer.alloc(padding));
        byteLength += buffer.length + padding;
        accessors.push({ bufferView: bufferViews.length - 1, componentType, count, type, ...bounds });
        return accessors.length - 1;
    }

    const materials = batches.map(({ hex, rgb }) => ({
        name: `#${hex}`,
        pbrMetallicRoughness: { baseColorFactor: [...rgb, 1], metallicFactor: 0, roughnessFactor: 0.82 }
    }));
    const primitives = batches.map((batch, material) => {
        const positions = new Float32Array(batch.positions);
        const count = positions.length / 3;
        const position = accessor(positions, 5126, 'VEC3', count, 34962, boundsOf(positions, 3));
        const normal = accessor(new Float32Array(batch.normals), 5126, 'VEC3', count, 34962);
        const useShort = count < 65536;
        const array = useShort ? new Uint16Array(batch.indices) : new Uint32Array(batch.indices);
        const indices = accessor(array, useShort ? 5123 : 5125, 'SCALAR', array.length, 34963);
        return { attributes: { POSITION: position, NORMAL: normal }, indices, material };
    });
    const root = {
        asset: { version: '2.0', generator: 'Notes For Goats scene exporter' },
        scene: 0,
        scenes: [{ nodes: [0] }],
        nodes: [{ mesh: 0 }],
        meshes: [{ primitives }],
        materials,
        accessors,
        bufferViews,
        buffers: [{ byteLength }]
    };
    const json = Buffer.from(JSON.stringify(root));
    const jsonPadding = Buffer.alloc((4 - json.length % 4) % 4, 0x20);
    const jsonLength = json.length + jsonPadding.length;
    const header = Buffer.alloc(20);
    header.write('glTF', 0);
    header.writeUInt32LE(2, 4);
    header.writeUInt32LE(28 + jsonLength + byteLength, 8);
    header.writeUInt32LE(jsonLength, 12);
    header.write('JSON', 16);
    const binHeader = Buffer.alloc(8);
    binHeader.writeUInt32LE(byteLength, 0);
    binHeader.write('BIN\0', 4);
    return Buffer.concat([header, json, jsonPadding, binHeader, ...chunks]);
}

const PNG_SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

const CRC_TABLE = Uint32Array.from({ length: 256 }, (_, index) => {
    let remainder = index;
    for (let bit = 0; bit < 8; bit += 1) {
        remainder = remainder & 1 ? 0xedb88320 ^ (remainder >>> 1) : remainder >>> 1;
    }
    return remainder >>> 0;
});

function pngChunk(type, data) {
    const header = Buffer.alloc(8);
    header.writeUInt32BE(data.length, 0);
    header.write(type, 4);
    let crc = 0xffffffff;
    for (const byte of header.subarray(4)) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
    for (const byte of data) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
    const tail = Buffer.alloc(4);
    tail.writeUInt32BE((crc ^ 0xffffffff) >>> 0);
    return Buffer.concat([header, data, tail]);
}

function encodePng(width, height, pixels) {
    const header = Buffer.alloc(13);
    header.writeUInt32BE(width, 0);
    header.writeUInt32BE(height, 4);
    header[8] = 8;
    header[9] = 2;
    const rowSize = 3 * width;
    const filtered = Buffer.alloc((rowSize + 1) * height);
    for (let y = 0; y < height; y += 1) {
        const start = y * rowSize;
        const row = y * (rowSize + 1);
        filtered[row] = 1;
        for (let index = 0; index < rowSize; index += 1) {
            const left = index >= 3 ? pixels[start + index - 3] : 0;
            filtered[row + index + 1] = pixels[start + index] - left;
        }
    }
    return Buffer.concat([
        PNG_SIGNATURE,
        pngChunk('IHDR', header),
        pngChunk('IDAT', deflateSync(filtered, { level: 7 })),
        pngChunk('IEND', Buffer.alloc(0))
    ]);
}

const KEY_LIGHT = normalize([-0.55, 0.72, 0.65]);
const FILL_LIGHT = normalize([0.75, 0.23, 0.29]);
const RIM_LIGHT = normalize([0.35, 0.63, -0.75]);

function projectedVertices(batches, azimuth, elevation) {
    const angle = azimuth * Math.PI / 180;
    const tilt = elevation * Math.PI / 180;
    const forward = [Math.sin(angle) * Math.cos(tilt), Math.sin(tilt), Math.cos(angle) * Math.cos(tilt)];
    const right = [Math.cos(angle), 0, -Math.sin(angle)];
    const up = cross(forward, right);
    return batches.map(batch => {
        const points = new Float32Array(batch.positions.length);
        const lighting = new Float32Array(points.length / 3);
        for (let index = 0; index < points.length; index += 3) {
            const position = batch.positions.slice(index, index + 3);
            const normal = batch.normals.slice(index, index + 3);
            points[index] = dot(position, right);
            points[index + 1] = -dot(position, up);
            points[index + 2] = dot(position, forward);
            lighting[index / 3] = 0.35
                + 0.69 * Math.max(0, dot(normal, KEY_LIGHT))
                + 0.23 * Math.max(0, dot(normal, FILL_LIGHT))
                + 0.19 * Math.max(0, dot(normal, RIM_LIGHT));
        }
        return { ...batch, points, lighting };
    });
}

function fillPosterBackground(pixels, width, height, shadowX, shadowY, shadowWidth) {
    const centerX = width * 0.45;
    const centerY = height * 0.44;
    for (let y = 0; y < height; y += 1) {
        const vertical = (y - centerY) / (height * 0.67);
        const shadowVertical = ((y - shadowY) / (height * 0.042)) ** 2;
        for (let x = 0; x < width; x += 1) {
            const horizontal = (x - centerX) / (width * 0.66);
            const glow = Math.max(0, 1 - Math.hypot(horizontal, vertical)) ** 1.2;
            const shadow = 1 - 0.55 * Math.exp(-shadowVertical - ((x - shadowX) / shadowWidth) ** 2);
            const offset = 3 * (y * width + x);
            pixels[offset] = (15 + glow * 25) * shadow;
            pixels[offset + 1] = (14 + glow * 22) * shadow;
            pixels[offset + 2] = (17 + glow * 22) * shadow;
        }
    }
}

function paintBatch(batch, pixels, depth, width, height) {
    const { points, indices, lighting, rgb } = batch;
    const colorRamp = Array.from({ length: 256 }, (_, index) =>
        rgb.map(color => toByte(color * index * 1.5 / 255))
    );
    for (let index = 0; index < indices.length; index += 3) {
        const a = indices[index];
        const b = indices[index + 1];
        const c = indices[index + 2];
        const ax = points[3 * a];
        const ay = points[3 * a + 1];
        const az = points[3 * a + 2];
        const bx = points[3 * b];
        const by = points[3 * b + 1];
        const bz = points[3 * b + 2];
        const cx = points[3 * c];
        const cy = points[3 * c + 1];
        const cz = points[3 * c + 2];
        const area = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
        if (area >= -0.0001) continue;

        const minX = Math.max(0, Math.floor(Math.min(ax, bx, cx)));
        const maxX = Math.min(width - 1, Math.ceil(Math.max(ax, bx, cx)));
        const minY = Math.max(0, Math.floor(Math.min(ay, by, cy)));
        const maxY = Math.min(height - 1, Math.ceil(Math.max(ay, by, cy)));
        const aDx = (by - cy) / area;
        const aDy = (cx - bx) / area;
        const bDx = (cy - ay) / area;
        const bDy = (ax - cx) / area;
        for (let y = minY; y <= maxY; y += 1) {
            let weightA = aDx * (minX + 0.5 - cx) + aDy * (y + 0.5 - cy);
            let weightB = bDx * (minX + 0.5 - cx) + bDy * (y + 0.5 - cy);
            for (let x = minX; x <= maxX; x += 1, weightA += aDx, weightB += bDx) {
                const weightC = 1 - weightA - weightB;
                if (weightA < -1e-6 || weightB < -1e-6 || weightC < -1e-6) continue;
                const z = az * weightA + bz * weightB + cz * weightC;
                const pixel = y * width + x;
                if (z <= depth[pixel]) continue;
                depth[pixel] = z;
                const intensity = lighting[a] * weightA + lighting[b] * weightB + lighting[c] * weightC;
                const [red, green, blue] = colorRamp[Math.min(255, Math.round(intensity * 170))];
                pixels[pixel * 3] = red;
                pixels[pixel * 3 + 1] = green;
                pixels[pixel * 3 + 2] = blue;
            }
        }
    }
}

export function buildPoster(build, { width = 576, height = 408, azimuth = 28, elevation = 19 } = {}) {
    const batches = projectedVertices(generateScene(build), azimuth, elevation);
    const bounds = batches.map(batch => boundsOf(batch.points, 3));
    const minX = Math.min(...bounds.map(bound => bound.min[0]));
    const minY = Math.min(...bounds.map(bound => bound.min[1]));
    const maxX = Math.max(...bounds.map(bound => bound.max[0]));
    const maxY = Math.max(...bounds.map(bound => bound.max[1]));
    const fit = Math.min(width * 0.83 / (maxX - minX), height * 0.82 / (maxY - minY));
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    const projectedBottom = (maxY - centerY) * fit + height * 0.49;
    const pixels = Buffer.alloc(3 * width * height);
    const depth = new Float32Array(width * height).fill(-Infinity);
    fillPosterBackground(pixels, width, height, width * 0.5, projectedBottom + height * 0.017,
        Math.max((maxX - minX) * fit * 0.33, width * 0.09));
    for (const batch of batches) {
        for (let index = 0; index < batch.points.length; index += 3) {
            batch.points[index] = (batch.points[index] - centerX) * fit + width * 0.5;
            batch.points[index + 1] = (batch.points[index + 1] - centerY) * fit + height * 0.49;
        }
        paintBatch(batch, pixels, depth, width, height);
    }
    return encodePng(width, height, pixels);
}
