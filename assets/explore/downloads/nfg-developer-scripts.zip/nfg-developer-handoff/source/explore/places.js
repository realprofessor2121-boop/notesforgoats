const colors = {
  white: '#e6e7e0', trim: '#aebfba', wall: '#d6d2c0', base: '#41464a',
  grass: '#769a63', pavement: '#aeb5b9', road: '#3c464e', roof: '#a23c39',
  roofEdge: '#702f35', glass: '#557b91', frame: '#23303b', solar: '#1c3a66',
  wood: '#9c6848', lightWood: '#c49364', oak: '#704a3a', linen: '#e7d9bd',
  charcoal: '#303438', sage: '#557668', gold: '#d8a854', chrome: '#b5bebc',
  carpet: '#ae7666', clay: '#a16c59', navy: '#263b51', foam: '#3b3d46',
};

function windowFrame(scene, x, y, z, width, height, rotation = 0) {
  const turn = [0, rotation, 0];
  const offset = (horizontal, depth) => [
    x + horizontal * Math.cos(rotation) + depth * Math.sin(rotation),
    y,
    z - horizontal * Math.sin(rotation) + depth * Math.cos(rotation),
  ];
  scene.box([x, y, z], [width, height, 0.11], colors.frame, turn);
  scene.box(offset(0, 0.058), [width - 0.11, height - 0.11, 0.027], colors.glass, turn);
  scene.box(offset(0, 0.077), [0.036, height, 0.033], colors.frame, turn);
  scene.box(offset(0, 0.077), [width, 0.035, 0.033], colors.frame, turn);
}

function solarArray(scene, x, y, z, width, depth, pitch) {
  const turn = [0, 0, pitch];
  const surface = (along, raise, front) => [
    x + along * Math.cos(pitch) - raise * Math.sin(pitch),
    y + along * Math.sin(pitch) + raise * Math.cos(pitch),
    z + front,
  ];
  scene.box(surface(0, 0, 0), [width + 0.065, 0.08, depth + 0.065], '#79818d', turn);
  scene.box(surface(0, 0.05, 0), [width, 0.035, depth], colors.solar, turn);
  for (const divider of [-0.25, 0, 0.25]) {
    scene.box(surface(width * divider, 0.074, 0), [0.015, 0.014, depth], '#6382a4', turn);
    scene.box(surface(0, 0.074, depth * divider), [width, 0.014, 0.015], '#6382a4', turn);
  }
}

function gable(scene, { x, y, z, width, depth, pitch }) {
  const slope = Math.atan(pitch);
  const rise = width * pitch / 2;
  const panelWidth = (width / 2 + 0.18) / Math.cos(slope);
  for (let step = 0; step < 12; step += 1) {
    const fraction = step / 12;
    scene.box([x, y + rise * (fraction + 1 / 24), z],
      [width * (1 - fraction), rise / 12 + 0.01, depth - 0.16], colors.white);
  }
  for (const side of [-1, 1]) {
    const rotation = [0, 0, -side * slope];
    const center = [x + side * width / 4, y + rise / 2 + 0.06, z];
    scene.box(center, [panelWidth, 0.17, depth], colors.roof, rotation);
    for (const end of [-1, 1]) {
      scene.box([center[0], center[1], z + end * depth / 2],
        [panelWidth + 0.04, 0.2, 0.075], colors.roofEdge, rotation);
    }
    for (let edge = 1; edge < 9; edge += 1) {
      const along = -panelWidth / 2 + edge * panelWidth / 9;
      scene.box([center[0] + along * Math.cos(slope),
        center[1] - side * along * Math.sin(slope) + 0.087, z],
      [0.025, 0.025, depth - 0.12], '#bc554d', rotation);
    }
  }
  scene.box([x, y + rise + 0.13, z], [0.17, 0.13, depth + 0.05], colors.roofEdge);
}

function steps(scene, x, z, width) {
  for (let index = 0; index < 4; index += 1) {
    scene.box([x, 0.055 + index * 0.055, z - index * 0.1],
      [width, 0.11 + index * 0.11, 0.21], colors.pavement);
  }
}

function arc(scene, x, y, z, radius, start, end, color, thickness = 0.017) {
  const points = Array.from({ length: 19 }, (_, index) => {
    const angle = start + (end - start) * index / 18;
    return [x + radius * Math.cos(angle), y, z + radius * Math.sin(angle)];
  });
  scene.tube(points, thickness, color);
}

function court(scene) {
  const x = -2.57;
  const z = 0.05;
  const stripe = '#e7e1d1';
  const fence = '#526160';
  scene.box([x, 0.025, z], [2.82, 0.055, 3.48], '#626d6e');
  for (const side of [-1, 1]) {
    scene.box([x + side * 1.34, 0.056, z], [0.018, 0.009, 3.32], stripe);
    scene.box([x, 0.056, z + side * 1.65], [2.7, 0.009, 0.018], stripe);
    scene.box([x, 0.056, z + side * 1.24], [0.74, 0.009, 0.018], stripe);
    for (const edge of [-1, 1]) {
      scene.box([x + edge * 0.37, 0.056, z + side * 1.44], [0.018, 0.009, 0.42], stripe);
    }
    arc(scene, x, 0.057, z + side * 1.43, 0.95,
      side === 1 ? Math.PI : 0, side === 1 ? Math.PI * 2 : Math.PI, stripe, 0.009);
    scene.box([x, 0.38, z + side * 1.61], [0.045, 0.69, 0.045], fence);
    scene.box([x, 0.66, z + side * 1.51], [0.38, 0.22, 0.04], colors.white);
    arc(scene, x, 0.605, z + side * 1.37, 0.1, 0, Math.PI * 2, '#c75f3e', 0.014);
  }
  scene.box([x, 0.056, z], [2.7, 0.009, 0.02], stripe);
  arc(scene, x, 0.057, z, 0.32, 0, 2 * Math.PI, stripe, 0.009);
  for (const side of [-1, 1]) {
    for (let position = 0; position < 5; position += 1) {
      const fraction = position / 4 - 0.5;
      scene.box([x + side * 1.45, 0.245, z + 3.58 * fraction], [0.024, 0.49, 0.024], fence);
      scene.box([x + 2.9 * fraction, 0.245, z + side * 1.79], [0.024, 0.49, 0.024], fence);
    }
    for (const height of [0.12, 0.31, 0.48]) {
      scene.box([x + side * 1.45, height, z], [0.013, 0.013, 3.58], fence);
      scene.box([x, height, z + side * 1.79], [2.9, 0.013, 0.013], fence);
    }
  }
}

function planter(scene, x, z, size = 1, y = 0) {
  scene.ellipsoid([x, y + 0.16 * size, z], [0.19, 0.16, 0.19].map(value => value * size), colors.clay);
  for (const [dx, dy, dz] of [[-0.1, 0.39, 0], [0, 0.47, 0.02], [0.12, 0.36, -0.01]]) {
    scene.ellipsoid([x + dx * size, y + dy * size, z + dz * size],
      [0.09, 0.16, 0.08].map(value => value * size), '#5d805a', [0, 0, dx * -3]);
  }
}

function house(scene) {
  scene.box([0, -0.28, 0.42], [8.72, 0.5, 7.4], colors.base);
  scene.box([0, -0.072, -0.25], [8.68, 0.14, 6.05], colors.grass);
  scene.box([0, -0.08, 3.28], [8.68, 0.14, 1.77], colors.road);
  for (const z of [2.64, 4.07]) {
    scene.box([0, -0.037, z], [8.69, 0.07, 0.23], colors.pavement);
  }
  for (let index = -4; index <= 4; index += 1) {
    scene.box([index * 0.9, -0.007, 3.35], [0.4, 0.011, 0.022], '#c6bfac');
  }
  scene.box([0.94, -0.014, 1.95], [3.75, 0.05, 1.4], colors.pavement);
  scene.box([1.18, 0.98, -0.45], [3.55, 1.96, 3.25], colors.white);
  scene.box([1.18, 0.11, -0.45], [3.62, 0.22, 3.34], colors.trim);
  scene.box([-0.05, 0.85, 0.9], [1.52, 1.7, 1.93], colors.white);
  scene.box([2.8, 1.04, 0.46], [0.87, 2.08, 1.7], '#a8bac0');
  scene.box([2.8, 2.12, 0.46], [0.97, 0.1, 1.78], '#bfd0d2');
  gable(scene, { x: 1.18, y: 1.96, z: -0.47, width: 3.75, depth: 3.56, pitch: 0.58 });
  gable(scene, { x: -0.05, y: 1.69, z: 0.95, width: 1.56, depth: 2.08, pitch: 0.69 });
  const solarPitch = -Math.atan(0.58);
  solarArray(scene, 2.02, 2.68, -0.43, 0.89, 0.61, solarPitch);
  solarArray(scene, 2.08, 2.64, 0.45, 0.91, 0.73, solarPitch);
  solarArray(scene, 2.18, 2.59, -1.28, 0.73, 0.8, solarPitch);
  scene.box([1.55, 2.91, -1.73], [0.28, 0.58, 0.35], '#aa9c94');
  scene.box([1.55, 3.21, -1.73], [0.35, 0.095, 0.41], colors.roofEdge);
  windowFrame(scene, -0.25, 1.16, 1.89, 0.63, 0.83);
  windowFrame(scene, 0.82, 1.57, 1.19, 0.47, 0.57);
  windowFrame(scene, 1.95, 1.51, 1.19, 0.7, 0.57);
  windowFrame(scene, 2.96, 1.38, -0.44, 0.76, 0.7, Math.PI / 2);
  windowFrame(scene, 2.96, 0.62, -1.42, 0.64, 0.5, Math.PI / 2);
  windowFrame(scene, 0.33, 1.34, -2.08, 0.72, 0.61, Math.PI);
  windowFrame(scene, 1.81, 1.34, -2.08, 0.82, 0.61, Math.PI);
  windowFrame(scene, -0.61, 1.2, -1.04, 0.77, 0.82, -Math.PI / 2);
  scene.box([1.32, 0.49, 1.2], [0.52, 0.94, 0.065], colors.frame);
  scene.box([1.32, 0.49, 1.24], [0.42, 0.86, 0.034], colors.glass);
  scene.box([2.8, 0.49, 1.35], [0.67, 0.86, 0.09], colors.frame);
  for (let index = 0; index < 6; index += 1) {
    scene.box([2.8, 0.15 + index * 0.13, 1.407], [0.58, 0.092, 0.027], '#758389');
  }
  steps(scene, 1.33, 1.69, 0.74);
  steps(scene, 0.13, 2.22, 0.83);
  for (const x of [-0.53, 0.55, 2.28]) planter(scene, x, 1.85, 0.55);
  court(scene);
  scene.box([-3.03, 0.31, -2.37], [0.88, 0.62, 0.72], '#7f8f84');
  gable(scene, { x: -3.03, y: 0.61, z: -2.37, width: 0.94, depth: 0.87, pitch: 0.32 });
  scene.box([-3.03, 0.24, -2.0], [0.3, 0.46, 0.046], colors.frame);
  for (const x of [-1.4, 3.39, 3.96]) {
    scene.box([x, 0.22, 2.45], [0.11, 0.44, 0.11], '#859591');
  }
}

function room(scene, wall, floor, edge = colors.trim, seam = '#907d6c') {
  scene.box([0, -0.13, 0], [5.55, 0.25, 4.67], colors.base);
  scene.box([0, -0.015, 0], [5.39, 0.075, 4.51], floor);
  if (seam) {
    for (let index = -6; index <= 6; index += 1) {
      scene.box([index * 0.395, 0.026, 0], [0.014, 0.006, 4.48], seam);
    }
  }
  scene.box([0, 0.83, -2.22], [5.44, 1.66, 0.16], wall);
  scene.box([-2.64, 0.67, -1.22], [0.15, 1.34, 1.9], wall);
  scene.box([-2.64, 0.21, 0.95], [0.15, 0.42, 2.46], wall);
  scene.box([2.64, 0.17, 0], [0.15, 0.34, 4.53], wall);
  scene.box([0, 0.12, 2.18], [5.24, 0.24, 0.13], wall);
  scene.box([0, 1.68, -2.22], [5.5, 0.1, 0.21], edge);
  scene.box([-2.64, 1.35, -1.22], [0.19, 0.08, 1.96], edge);
}

function raisedSurface(scene, x, z, width, depth, height, color = colors.wood) {
  scene.box([x, height, z], [width, 0.11, depth], color);
  for (const dx of [-1, 1]) for (const dz of [-1, 1]) {
    scene.box([x + dx * (width / 2 - 0.12), height / 2, z + dz * (depth / 2 - 0.12)],
      [0.1, height, 0.1], colors.oak);
  }
}

function livingRoom(scene) {
  room(scene, '#b6b3a5', colors.lightWood);
  windowFrame(scene, 1.47, 1.1, -2.11, 1.52, 1.0);
  scene.box([-0.38, 0.04, 0.24], [3.47, 0.024, 2.62], colors.carpet);
  scene.box([-0.38, 0.055, 0.24], [3.3, 0.012, 2.46], '#bc8371');
  scene.box([-0.48, 0.24, -1.2], [2.96, 0.32, 1.13], colors.sage);
  scene.box([-0.48, 0.58, -1.66], [2.96, 0.54, 0.28], colors.sage);
  for (const x of [-1.88, 0.92]) {
    scene.box([x, 0.43, -1.19], [0.27, 0.55, 1.11], '#466153');
  }
  for (const x of [-1.29, -0.47, 0.35]) {
    scene.box([x, 0.434, -1.11], [0.79, 0.12, 0.8], '#749184');
  }
  scene.box([-1.37, 0.69, -1.46], [0.36, 0.35, 0.15], colors.linen, [0.2, 0, 0.15]);
  scene.box([0.39, 0.7, -1.47], [0.39, 0.37, 0.15], colors.gold, [0.2, 0, -0.13]);
  raisedSurface(scene, -0.34, 0.28, 1.38, 0.81, 0.45);
  scene.box([-0.56, 0.52, 0.31], [0.43, 0.048, 0.29], colors.navy, [0, 0.14, 0]);
  scene.box([-0.5, 0.554, 0.29], [0.34, 0.026, 0.23], colors.linen, [0, 0.33, 0]);
  scene.ellipsoid([0.06, 0.54, 0.23], [0.14, 0.058, 0.14], colors.linen);
  scene.box([1.19, 0.22, 1.55], [2.12, 0.34, 0.43], colors.oak);
  scene.box([1.19, 0.47, 1.52], [0.54, 0.08, 0.25], colors.frame);
  scene.box([1.19, 0.79, 1.54], [1.74, 0.85, 0.08], colors.frame);
  scene.box([1.19, 0.79, 1.486], [1.59, 0.71, 0.032], '#425566');
  planter(scene, 2.16, -1.69, 1.2);
}

function studio(scene) {
  room(scene, '#29983f', '#59ad51', '#93cf77', null);
  for (const x of [-1.9, -1.23, 1.23, 1.9]) {
    scene.box([x, 1.16, -2.098], [0.51, 0.82, 0.07], colors.foam);
    for (let ridge = -2; ridge <= 2; ridge += 1) {
      scene.box([x + ridge * 0.083, 1.16, -2.047], [0.036, 0.78, 0.028], '#535764');
    }
  }
  scene.box([0, 0.045, -0.08], [3.77, 0.025, 2.63], '#4e5765');
  raisedSurface(scene, 0, -1.04, 2.88, 1.13, 0.82, colors.oak);
  scene.box([0, 1.03, -1.33], [0.43, 0.06, 0.31], colors.charcoal);
  scene.box([0, 1.12, -1.37], [0.17, 0.21, 0.12], colors.charcoal);
  scene.box([0, 1.36, -1.36], [1.28, 0.66, 0.09], colors.charcoal);
  scene.box([0, 1.36, -1.295], [1.17, 0.55, 0.043], '#53677a');
  for (const [index, color] of ['#7da78d', '#c0a16a', '#9b7b9d', '#8e9caf'].entries()) {
    scene.box([-0.06 + index * 0.03, 1.49 - index * 0.082, -1.267],
      [0.88 - index * 0.14, 0.04, 0.014], color);
  }
  for (const x of [-1, 1]) {
    scene.box([x, 1.13, -1.3], [0.36, 0.55, 0.36], colors.charcoal);
    for (const [y, size] of [[1.21, 0.125], [1.03, 0.065]]) {
      scene.ellipsoid([x, y, -1.107], [size, size, 0.032], colors.gold);
      scene.ellipsoid([x, y, -1.081], [size * 0.48, size * 0.48, 0.021], colors.frame);
    }
  }
  scene.box([-0.45, 0.906, -0.73], [1.38, 0.085, 0.37], colors.charcoal);
  for (let key = 0; key < 14; key += 1) {
    const x = -1.045 + key * 0.091;
    scene.box([x, 0.958, -0.697], [0.079, 0.035, 0.28], colors.white);
    if (![2, 6, 9, 13].includes(key)) scene.box([x + 0.042, 0.986, -0.75],
      [0.044, 0.041, 0.17], colors.charcoal);
  }
  scene.box([0.85, 0.921, -0.73], [0.79, 0.1, 0.35], '#554e54');
  for (let column = 0; column < 4; column += 1) for (const row of [-1, 1]) {
    scene.box([0.57 + column * 0.19, 0.979, -0.73 + row * 0.074],
      [0.1, 0.033, 0.1], row === -1 ? '#d29763' : '#85918e');
  }
  scene.box([0.06, 0.49, 0.19], [0.69, 0.15, 0.61], colors.charcoal);
  scene.box([0.06, 0.8, 0.45], [0.68, 0.66, 0.17], colors.charcoal);
  scene.tube([[0.06, 0.09, 0.19], [0.06, 0.44, 0.19]], 0.067, colors.chrome);
  for (const [dx, dz] of [[-0.28, 0.22], [0.28, 0.22], [-0.28, -0.22], [0.28, -0.22]]) {
    scene.tube([[0.06, 0.1, 0.19], [0.06 + dx, 0.1, 0.19 + dz]], 0.04, colors.charcoal);
  }
  scene.ellipsoid([1.89, 0.064, 0.46], [0.32, 0.04, 0.32], colors.charcoal);
  scene.tube([[1.89, 0.1, 0.46], [1.89, 1.5, 0.46], [1.68, 1.55, 0.61]], 0.036, colors.chrome);
  scene.ellipsoid([1.63, 1.55, 0.65], [0.19, 0.082, 0.085], colors.charcoal, [0, -0.5, 0]);
  scene.ellipsoid([1.51, 1.55, 0.72], [0.08, 0.069, 0.069], '#ad9878');
}

function kitchen(scene) {
  room(scene, '#b82d37', '#d75a59', '#eb9290', null);
  windowFrame(scene, 0.46, 1.13, -2.11, 1.35, 0.83);
  scene.box([-0.74, 0.41, -1.64], [3.46, 0.77, 0.84], colors.sage);
  scene.box([-0.74, 0.83, -1.64], [3.55, 0.1, 0.92], colors.linen);
  for (const x of [-2.02, -1.32, -0.62, 0.08, 0.71]) {
    scene.box([x, 0.39, -1.201], [0.58, 0.64, 0.035], '#668276');
    scene.box([x, 0.64, -1.162], [0.27, 0.035, 0.045], colors.chrome);
  }
  scene.box([1.7, 0.91, -1.68], [1.0, 1.78, 0.97], '#aab0b1');
  for (const y of [0.46, 1.29]) {
    scene.box([1.7, y, -1.17], [0.91, 0.76, 0.08], '#c6cccb');
    scene.box([1.38, y + 0.06, -1.102], [0.05, 0.38, 0.065], '#687273');
  }
  scene.box([-1.72, 0.89, -1.59], [0.83, 0.04, 0.62], colors.charcoal);
  for (const x of [-1.93, -1.52]) for (const z of [-1.46, -1.72]) {
    arc(scene, x, 0.921, z, 0.113, 0, 2 * Math.PI, '#7f8585', 0.015);
  }
  scene.box([0.43, 0.887, -1.62], [0.72, 0.034, 0.55], colors.chrome);
  scene.box([0.43, 0.909, -1.62], [0.54, 0.023, 0.41], '#687776');
  scene.tube([[0.43, 0.92, -1.86], [0.43, 1.17, -1.86], [0.43, 1.22, -1.75],
    [0.43, 1.16, -1.64]], 0.036, colors.chrome);
  scene.box([0.0, 0.476, 0.27], [2.77, 0.88, 1.15], colors.wood);
  scene.box([0.0, 0.958, 0.29], [2.95, 0.12, 1.31], colors.linen);
  scene.box([0.46, 1.03, 0.25], [0.68, 0.033, 0.42], colors.lightWood, [0, -0.2, 0]);
  scene.ellipsoid([-0.52, 1.042, 0.22], [0.37, 0.06, 0.31], '#e0d8bd');
  for (const [x, z, color] of [[-0.6, 0.26, '#b9564b'], [-0.44, 0.28, '#d8ae57'], [-0.5, 0.11, '#92a653']]) {
    scene.sphere([x, 1.117, z], 0.105, color);
  }
  for (const x of [-0.74, 0.74]) {
    scene.ellipsoid([x, 0.085, 1.56], [0.23, 0.06, 0.23], colors.charcoal);
    scene.tube([[x, 0.1, 1.56], [x, 0.61, 1.56]], 0.055, colors.chrome);
    scene.ellipsoid([x, 0.62, 1.56], [0.28, 0.08, 0.28], colors.clay);
  }
}

function bedroom(scene) {
  room(scene, '#262e3a', '#4f555d', '#5d7386', null);
  windowFrame(scene, -1.56, 1.09, -2.11, 1.42, 0.97);
  scene.box([0.16, 0.045, 0.24], [2.91, 0.026, 3.69], '#8d7c76');
  scene.box([0.2, 0.25, -0.33], [2.22, 0.36, 2.62], colors.oak);
  scene.box([0.2, 0.6, -1.66], [2.31, 0.97, 0.19], colors.wood);
  for (let slat = -3; slat <= 3; slat += 1) {
    scene.box([0.2 + slat * 0.29, 0.69, -1.546], [0.05, 0.72, 0.04], colors.lightWood);
  }
  scene.box([0.2, 0.49, -0.29], [2.15, 0.23, 2.57], colors.linen);
  scene.box([0.2, 0.62, 0.17], [2.2, 0.11, 1.73], colors.navy);
  scene.box([0.2, 0.688, -0.4], [2.23, 0.064, 0.36], '#708a95');
  for (const x of [-0.34, 0.73]) {
    scene.ellipsoid([x, 0.666, -1.14], [0.46, 0.13, 0.275], '#e6d7bf');
  }
  raisedSurface(scene, -1.37, -1.1, 0.64, 0.57, 0.56);
  scene.ellipsoid([-1.37, 0.637, -1.1], [0.16, 0.043, 0.16], colors.charcoal);
  scene.tube([[-1.37, 0.64, -1.1], [-1.37, 1.02, -1.1]], 0.042, colors.chrome);
  scene.ellipsoid([-1.37, 1.04, -1.1], [0.24, 0.14, 0.24], colors.gold);
  scene.box([2.12, 0.58, -0.97], [0.75, 1.13, 1.23], colors.wood);
  for (const y of [0.27, 0.61, 0.95]) {
    scene.box([1.729, y, -0.97], [0.038, 0.27, 1.14], colors.lightWood);
    scene.box([1.688, y, -0.97], [0.05, 0.046, 0.28], colors.chrome);
  }
  planter(scene, -2.07, 1.48, 1.13);
}

function desk(scene, x, z, { monitor = true, color = colors.white, width = 1.65 } = {}) {
  raisedSurface(scene, x, z, width, 0.72, 0.78, color);
  if (monitor) {
    scene.box([x, 0.87, z - 0.1], [0.34, 0.058, 0.21], colors.charcoal);
    scene.box([x, 0.96, z - 0.12], [0.095, 0.19, 0.09], colors.charcoal);
    scene.box([x, 1.14, z - 0.12], [0.7, 0.43, 0.087], colors.charcoal);
    scene.box([x, 1.14, z - 0.055], [0.6, 0.33, 0.023], colors.glass);
    scene.box([x, 0.862, z + 0.16], [0.47, 0.033, 0.15], '#ddded4');
  }
  const chairZ = z + 0.7;
  scene.ellipsoid([x, 0.09, chairZ], [0.26, 0.055, 0.27], colors.charcoal);
  scene.tube([[x, 0.11, chairZ], [x, 0.44, chairZ]], 0.062, colors.chrome);
  scene.box([x, 0.47, chairZ], [0.57, 0.13, 0.57], colors.charcoal);
  scene.box([x, 0.72, chairZ + 0.23], [0.55, 0.5, 0.135], colors.charcoal);
}

function sofa(scene, x, z, width, color) {
  scene.box([x, 0.2, z], [width, 0.3, 0.82], color);
  scene.box([x, 0.53, z - 0.35], [width, 0.45, 0.18], color);
  for (const side of [-1, 1]) {
    scene.box([x + side * (width / 2 - 0.1), 0.4, z], [0.22, 0.43, 0.82], color);
    scene.box([x + side * (width / 4 - 0.01), 0.37, z + 0.035],
      [(width - 0.46) / 2, 0.11, 0.62], '#6b7881');
  }
}

function shelf(scene, x, z, width, highlight) {
  for (const side of [-1, 1]) {
    scene.box([x + side * width / 2, 0.78, z], [0.065, 1.54, 0.45], colors.charcoal);
  }
  for (const level of [0.14, 0.56, 0.99, 1.4]) {
    scene.box([x, level, z], [width, 0.05, 0.42], colors.wood);
    scene.box([x - width * 0.2, level + 0.13, z - 0.029], [width * 0.29, 0.21, 0.19], highlight);
    scene.box([x + width * 0.19, level + 0.17, z + 0.07], [width * 0.16, 0.28, 0.16], colors.linen);
  }
}

function camera(scene, x, z, height = 1.06) {
  const tip = [x, height - 0.13, z];
  for (const [dx, dz] of [[-0.21, 0.15], [0.21, 0.15], [0, -0.23]]) {
    scene.tube([[x + dx, 0.055, z + dz], tip], 0.024, colors.charcoal);
  }
  scene.box([x, height, z], [0.28, 0.16, 0.17], colors.charcoal);
  scene.ellipsoid([x, height, z + 0.1], [0.084, 0.076, 0.058], colors.glass);
}

function gameRoom(scene) {
  room(scene, '#ba602a', '#d9955b', '#f2b780', null);
  desk(scene, -1.57, -1.1, { width: 1.36, color: '#b28b71' });
  sofa(scene, 1.17, 0.8, 2.27, '#3f494e');
  scene.box([0.19, 0.82, -1.82], [0.73, 1.59, 0.63], colors.charcoal);
  scene.box([0.19, 1.2, -1.484], [0.61, 0.45, 0.06], '#404c63');
  scene.box([0.19, 1.47, -1.484], [0.61, 0.124, 0.073], colors.gold);
  scene.box([0.19, 0.9, -1.415], [0.74, 0.07, 0.18], colors.charcoal);
  scene.sphere([0.04, 0.973, -1.388], 0.052, '#a64b45');
  scene.sphere([0.32, 0.955, -1.348], 0.029, colors.gold);
  camera(scene, 0.9, 1.53, 0.84);
}

function businessRoom(scene) {
  room(scene, '#c0a52a', '#d9bf5e', '#f0d77d', null);
  desk(scene, -0.79, -1.42, { width: 1.57 });
  desk(scene, 1.34, -0.97, { width: 1.29 });
  shelf(scene, -2.02, -1.84, 0.54, colors.navy);
  scene.box([0.38, 0.41, -1.85], [0.61, 0.76, 0.64], colors.white);
  for (const y of [0.23, 0.5]) scene.box([0.38, y, -1.505], [0.4, 0.039, 0.036], colors.chrome);
  scene.ellipsoid([-0.18, 1.42, -2.087], [0.18, 0.179, 0.041], colors.charcoal);
  scene.ellipsoid([-0.18, 1.42, -2.044], [0.149, 0.149, 0.026], colors.linen);
  scene.box([-0.18, 1.46, -2.012], [0.027, 0.073, 0.024], colors.charcoal);
  scene.box([-0.144, 1.421, -2.012], [0.078, 0.02, 0.024], colors.charcoal);
}

function distributionOffice(scene) {
  room(scene, '#337cbb', '#5499d0', '#91bdda', null);
  desk(scene, -0.34, -1.13, { width: 1.78, monitor: false, color: '#adc7d7' });
  scene.box([-0.12, 0.861, -1.2], [0.54, 0.05, 0.31], colors.charcoal);
  scene.box([-0.12, 1.046, -1.32], [0.54, 0.34, 0.055], colors.navy, [-0.17, 0, 0]);
  for (const x of [-1.87, -1.39]) {
    scene.box([x, 0.228, -1.43], [0.45, 0.4, 0.63], '#5d7188');
    scene.box([x, 0.435, -1.43], [0.47, 0.067, 0.65], '#6d8295');
  }
}

function marketingRoom(scene) {
  room(scene, '#7555ac', '#a688d4', '#c5abec', null);
  sofa(scene, 1.26, 1.18, 1.93, '#41475e');
  scene.box([-1.3, 0.94, -1.75], [1.33, 1.81, 0.074], colors.charcoal);
  scene.box([-1.3, 0.91, -1.69], [1.21, 1.68, 0.048], '#79a960');
  scene.box([-1.3, 0.042, -1.3], [1.21, 0.04, 0.85], '#79a960');
  camera(scene, -0.5, -0.31, 1.19);
  camera(scene, 0.11, 0.29, 0.91);
  scene.ellipsoid([-1.8, 0.064, -0.23], [0.23, 0.05, 0.23], colors.charcoal);
  scene.tube([[-1.8, 0.09, -0.23], [-1.8, 1.21, -0.23]], 0.035, colors.chrome);
  scene.ellipsoid([-1.8, 1.25, -0.23], [0.32, 0.31, 0.1], colors.charcoal, [0, -0.53, 0]);
  scene.ellipsoid([-1.72, 1.25, -0.29], [0.2, 0.2, 0.065], colors.linen, [0, -0.53, 0]);
}

function trophyRoom(scene) {
  room(scene, '#b84987', '#d275a9', '#f1a1cc', null);
  scene.box([-1.51, 0.83, -1.899], [1.74, 1.63, 0.08], '#865b8d');
  for (const x of [-2.4, -1.51, -0.62]) {
    scene.box([x, 0.85, -1.62], [0.062, 1.64, 0.57], '#9a7b9a');
  }
  for (const tier of [0.19, 0.65, 1.11]) {
    scene.box([-1.51, tier, -1.62], [1.78, 0.046, 0.58], '#a2899e');
    for (const x of [-2.03, -1.13]) {
      scene.box([x, tier + 0.044, -1.6], [0.25, 0.065, 0.23], colors.charcoal);
      scene.tube([[x, tier + 0.07, -1.6], [x, tier + 0.22, -1.6]], 0.034, colors.gold);
      scene.ellipsoid([x, tier + 0.29, -1.6], [0.13, 0.12, 0.12], colors.gold);
    }
  }
  scene.box([0.84, 0.052, 0.32], [1.37, 0.036, 2.63], '#a53650');
  for (const side of [-1, 1]) {
    const x = 0.84 + side * 0.78;
    const rope = [];
    for (const z of [-0.97, -0.1, 0.77, 1.64]) {
      scene.ellipsoid([x, 0.069, z], [0.12, 0.039, 0.12], colors.gold);
      scene.tube([[x, 0.083, z], [x, 0.49, z]], 0.031, colors.gold);
      scene.sphere([x, 0.5, z], 0.053, colors.gold);
      if (rope.length) rope.push([x, 0.369, z - 0.435]);
      rope.push([x, 0.46, z]);
    }
    scene.tube(rope, 0.029, '#9a2f42');
  }
}

function legacyRoom(scene) {
  room(scene, '#c1c7cd', '#d1d4d6', '#e5e8eb', null);
  scene.box([-1.09, 0.61, -1.35], [1.07, 1.17, 0.87], '#728294');
  scene.box([-1.09, 0.98, -0.895], [0.91, 0.39, 0.14], '#596b7d');
  scene.box([-1.09, 1.28, -1.05], [0.86, 0.52, 0.12], colors.charcoal, [-0.29, 0, 0]);
  scene.box([-1.09, 1.28, -0.964], [0.63, 0.29, 0.04], '#62929d', [-0.29, 0, 0]);
  scene.box([-1.09, 0.79, -0.805], [0.405, 0.06, 0.046], '#2a3640');
  scene.box([-1.09, 0.936, -0.792], [0.39, 0.15, 0.042], '#99a4ae', [-0.25, 0, 0]);
  for (const x of [-1.18, -1.09, -1]) for (const y of [0.918, 0.958]) {
    scene.box([x, y, -0.756], [0.067, 0.026, 0.024], colors.charcoal);
  }
}

export const placeModels = {
  house, livingRoom, studio, kitchen, bedroom, gameRoom, businessRoom,
  distributionOffice, marketingRoom, trophyRoom, legacyRoom,
};
