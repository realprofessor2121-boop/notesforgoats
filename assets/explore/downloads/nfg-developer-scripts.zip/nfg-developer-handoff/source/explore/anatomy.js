const muscleColors = {
  red: '#b43743', scarlet: '#d34d53', deep: '#842932', rose: '#e07870',
  fascia: '#efc2a0', tendon: '#e7d7be', eye: '#f3e9dd', pupil: '#3f2c2a',
};

const boneColors = {
  ivory: '#eee3c6', cream: '#fff1d1', shaded: '#c2ab85', cartilage: '#96b1ae',
  socket: '#494236', teeth: '#fff5df',
};

const vesselColors = {
  artery: '#de4552', fineArtery: '#bb536d', vein: '#2679cc', fineVein: '#439ee7',
  connection: '#9366bd', heart: '#c7546f',
};

const organColors = {
  brain: '#e89785', fold: '#ba6b69', cord: '#d2aa78', trachea: '#e4c8ae',
  lungs: '#dd8779', lungDetail: '#bd666a', heart: '#bb414d', artery: '#df5352',
  vein: '#548dbe', liver: '#854b59', kidneys: '#b95b5d', stomach: '#e6a081',
  pancreas: '#edb883', colon: '#a3677f', smallIntestine: '#ebad92',
  appendix: '#b67482', diaphragm: '#bc7d67', bladder: '#d48783', gallbladder: '#6f996a',
  spleen: '#7d5b8c',
};

const mirrored = (point, side) => [point[0] * side, point[1], point[2]];

function spindle(scene, start, end, width, depth, color) {
  const delta = end.map((coordinate, axis) => coordinate - start[axis]);
  const center = start.map((coordinate, axis) => coordinate + delta[axis] / 2);
  const length = Math.hypot(...delta);
  const rotation = [
    Math.atan2(delta[2], Math.hypot(delta[0], delta[1])),
    0,
    Math.atan2(-delta[0], delta[1]),
  ];
  scene.ellipsoid(center, [width, length / 2, depth], color, rotation);
}

function curve(scene, points, radius, color, endRadius = radius) {
  const smooth = [];
  const steps = 4;

  for (let index = 0; index < points.length - 1; index += 1) {
    const earlier = points[Math.max(index - 1, 0)];
    const start = points[index];
    const end = points[index + 1];
    const later = points[Math.min(index + 2, points.length - 1)];

    for (let step = 0; step < steps; step += 1) {
      const t = step / steps;
      const t2 = t * t;
      const t3 = t2 * t;
      smooth.push(start.map((startCoordinate, axis) => {
        const previousCoordinate = earlier[axis];
        const endCoordinate = end[axis];
        const laterCoordinate = later[axis];
        return (2 * startCoordinate + (endCoordinate - previousCoordinate) * t
          + (2 * previousCoordinate - 5 * startCoordinate + 4 * endCoordinate - laterCoordinate) * t2
          + (-previousCoordinate + 3 * startCoordinate - 3 * endCoordinate + laterCoordinate) * t3) / 2;
      }));
    }
  }

  smooth.push(points.at(-1));
  const radii = smooth.map((_, index) => radius + (endRadius - radius) * index / (smooth.length - 1));
  scene.tube(smooth, radii, color);
}

function makeMuscle(scene) {
  const { red, scarlet, deep, rose, fascia, tendon, eye, pupil } = muscleColors;

  scene.ellipsoid([0, 1.59, 0], [.81, 1.01, .37], deep);
  scene.ellipsoid([0, .46, -.02], [.56, .61, .32], deep);
  scene.ellipsoid([0, -.12, -.055], [.61, .46, .36], red);
  scene.ellipsoid([0, 3.35, 0], [.375, .508, .355], red);
  scene.ellipsoid([0, 3.08, .08], [.29, .24, .27], deep);
  scene.ellipsoid([0, 3.35, .333], [.074, .12, .078], rose);
  scene.ellipsoid([0, 3.19, .32], [.16, .057, .037], deep);
  scene.ellipsoid([0, 2.82, -.025], [.23, .33, .235], deep);
  spindle(scene, [0, .34, .32], [0, 2.32, .36], .023, .028, fascia);
  spindle(scene, [0, .06, -.315], [0, 2.72, -.302], .055, .04, fascia);

  for (const side of [-1, 1]) {
    const layer = (center, radii, color, angle = 0) => {
      scene.ellipsoid(mirrored(center, side), radii, color, [0, 0, angle * side]);
    };
    const muscle = (bottom, top, width, depth, color) => {
      spindle(scene, mirrored(bottom, side), mirrored(top, side), width, depth, color);
    };

    // Facial, neck, and shoulder muscles.
    layer([.135, 3.63, .228], [.133, .145, .075], rose, -.24);
    layer([.295, 3.47, .18], [.096, .187, .101], scarlet, -.23);
    layer([.194, 3.243, .27], [.092, .105, .07], scarlet, -.52);
    layer([.135, 3.421, .329], [.092, .048, .028], deep);
    layer([.135, 3.421, .35], [.057, .028, .018], eye);
    scene.sphere(mirrored([.133, 3.421, .365], side), .022, pupil);
    layer([.362, 3.33, -.022], [.08, .119, .077], scarlet, .15);
    muscle([.06, 2.49, .225], [.25, 3.05, .085], .087, .063, rose);
    muscle([.28, 2.04, -.28], [.175, 3.09, -.23], .207, .108, scarlet);
    muscle([.97, 2.25, -.16], [.137, 2.79, -.22], .2, .115, scarlet);
    muscle([1.13, 1.88, .024], [.78, 2.49, .015], .292, .26, scarlet);

    // Chest, serratus, abdominal wall, and back.
    layer([.386, 2.227, .301], [.42, .242, .17], scarlet, -.12);
    layer([.36, 2.092, .344], [.34, .087, .112], red, -.24);
    for (let stripe = 0; stripe < 3; stripe += 1) {
      muscle([.16, 2.11 + stripe * .058, .449], [.68, 2.179 + stripe * .075, .392], .012, .012, rose);
    }
    for (let row = 0; row < 3; row += 1) {
      layer([.165, 1.8 - row * .258, .344 - row * .011], [.144, .141, .098], row === 1 ? red : scarlet, -.06);
      layer([.57 - row * .045, 1.84 - row * .176, .225], [.104, .167, .09], rose, .91);
    }
    muscle([.083, .397, .265], [.457, 1.429, .26], .13, .095, red);
    muscle([.261, .333, .286], [.573, 1.226, .185], .13, .084, scarlet);
    muscle([.335, .459, -.263], [.78, 1.96, -.216], .218, .112, red);
    muscle([.177, .348, -.307], [.283, 1.932, -.313], .104, .081, scarlet);
    muscle([.454, 1.559, -.348], [.707, 2.209, -.289], .15, .08, deep);
    layer([.303, -.133, -.285], [.311, .32, .192], scarlet, -.1);

    // Upper arm, forearm, hand, and the individual fingers.
    muscle([1.398, 1.148, .138], [1.075, 1.991, .11], .185, .155, red);
    muscle([1.355, 1.295, .225], [1.169, 1.902, .193], .134, .098, scarlet);
    muscle([1.399, 1.181, -.14], [1.106, 2.046, -.15], .19, .148, deep);
    muscle([1.337, 1.279, -.235], [1.087, 1.917, -.218], .132, .086, scarlet);
    muscle([1.642, .326, .105], [1.442, 1.16, .079], .122, .124, scarlet);
    muscle([1.69, .319, -.078], [1.48, 1.139, -.083], .123, .107, red);
    muscle([1.584, .423, .161], [1.414, 1.09, .147], .07, .068, rose);
    muscle([1.668, .171, .049], [1.633, .465, .087], .073, .063, tendon);
    layer([1.71, .131, .056], [.142, .199, .08], red, .22);
    muscle([1.505, -.046, .105], [1.615, .169, .092], .053, .055, scarlet);
    for (let finger = 0; finger < 4; finger += 1) {
      const x = 1.616 + finger * .059;
      const tip = -.225 - [0, .043, .013, -.041][finger];
      muscle([x + .023, tip, .059], [x, .068, .058], .027, .03, rose);
    }

    // Thigh, calf, ankle, and foot.
    muscle([.377, -1.862, .188], [.357, -.198, .236], .233, .214, red);
    muscle([.451, -1.748, .289], [.583, -.277, .148], .173, .153, scarlet);
    muscle([.325, -1.672, .302], [.29, -.358, .298], .154, .126, scarlet);
    muscle([.266, -1.69, .238], [.13, -.347, .137], .119, .138, rose);
    muscle([.373, -1.6, .384], [.591, -.404, .231], .05, .056, rose);
    muscle([.479, -1.831, -.13], [.523, -.334, -.237], .132, .15, deep);
    muscle([.348, -1.776, -.235], [.275, -.322, -.31], .151, .166, red);
    layer([.398, -1.844, .21], [.139, .145, .135], tendon);
    layer([.406, -1.922, .294], [.107, .107, .071], rose);
    muscle([.47, -3.324, .1], [.415, -1.928, .113], .112, .13, red);
    muscle([.453, -3.219, -.035], [.34, -1.968, -.164], .142, .158, scarlet);
    muscle([.508, -3.175, -.073], [.508, -1.948, -.154], .143, .155, scarlet);
    muscle([.485, -3.487, -.132], [.471, -2.536, -.22], .052, .054, tendon);
    muscle([.473, -3.486, .162], [.427, -2.128, .24], .047, .048, rose);
    layer([.506, -3.52, .125], [.16, .116, .303], red, -.02);
    layer([.511, -3.545, .348], [.155, .075, .14], rose);
    for (let toe = 0; toe < 5; toe += 1) {
      layer([.396 + toe * .05, -3.547, .497 - toe * .021], [.039 - toe * .004, .048, .084 - toe * .007], rose);
    }
  }
}

function makeMuscleBoundNotes(scene) {
  const skin = '#9e6448';
  const warmSkin = '#a46a4e';
  const shadowSkin = '#8c553e';
  const hair = '#232024';
  const shorts = '#292729';
  const waistband = '#201e20';
  const gold = '#c6a362';
  const sock = '#414c65';
  const shoe = '#dad9d7';
  const sole = '#f0ede8';

  scene.ellipsoid([0, 3.305, .01], [.328, .448, .31], skin);
  scene.ellipsoid([0, 3.19, .128], [.277, .289, .231], skin);
  scene.ellipsoid([0, 3.293, .331], [.069, .112, .069], warmSkin, [-.19, 0, 0]);
  scene.ellipsoid([0, 3.072, .311], [.102, .112, .057], hair);
  scene.ellipsoid([0, 3.133, .357], [.085, .053, .021], skin);
  scene.ellipsoid([0, 3.124, .387], [.077, .012, .008], '#754338');
  scene.ellipsoid([0, 3.627, -.025], [.328, .177, .298], hair);
  scene.box([0, 3.604, .139], [.526, .115, .257], hair);
  scene.ellipsoid([0, 2.918, -.026], [.247, .311, .254], skin);
  scene.ellipsoid([0, 2.324, -.042], [.95, .55, .455], skin);
  scene.ellipsoid([0, 1.88, -.039], [.715, .684, .377], skin);
  scene.ellipsoid([0, 1.292, -.038], [.584, .532, .354], skin);
  scene.ellipsoid([0, 1.264, .317], [.039, .042, .009], shadowSkin);
  scene.ellipsoid([0, .842, -.029], [.642, .266, .399], shorts);
  scene.ellipsoid([0, .968, -.009], [.612, .074, .403], waistband);
  scene.ellipsoid([0, .336, -.094], [.366, .376, .351], shorts);
  scene.box([0, 3.437, .369], [.142, .03, .044], hair);
  curve(scene, [[-.275, 2.94, .179], [-.311, 2.718, .303], [-.254, 2.515, .43], [-.143, 2.396, .484], [0, 2.357, .5], [.143, 2.396, .484], [.254, 2.515, .43], [.311, 2.718, .303], [.275, 2.94, .179], [.229, 2.983, -.071], [0, 2.98, -.27], [-.229, 2.983, -.071], [-.275, 2.94, .179]], .014, gold);

  for (const side of [-1, 1]) {
    const layer = (center, radii, color, angle = 0) => {
      scene.ellipsoid(mirrored(center, side), radii, color, [0, 0, angle * side]);
    };
    const body = (start, end, width, depth, color = skin) => {
      spindle(scene, mirrored(start, side), mirrored(end, side), width, depth, color);
    };
    const path = (points, radius, color, tip = radius) => {
      curve(scene, points.map((point) => mirrored(point, side)), radius, color, tip);
    };

    layer([.309, 3.314, .012], [.072, .124, .073], skin);
    layer([.276, 3.51, -.031], [.057, .132, .242], hair);
    layer([.148, 3.431, .338], [.15, .087, .051], '#272a2e', -.07);
    layer([.141, 3.447, .375], [.127, .065, .028], '#38444e', -.07);
    layer([.154, 3.474, .396], [.085, .017, .009], '#56646e', -.15);
    path([[.254, 3.449, .358], [.298, 3.451, .2], [.318, 3.415, .046]], .017, hair);
    path([[.039, 3.161, .366], [.093, 3.143, .346], [.099, 3.091, .333], [.084, 3.062, .315]], .012, hair);

    body([.103, 2.447, -.06], [.753, 2.61, -.031], .239, .276);
    layer([.405, 2.309, .316], [.463, .276, .195], warmSkin, .045);
    layer([.561, 2.202, .408], [.039, .028, .015], shadowSkin);
    for (let row = 0; row < 3; row += 1) {
      layer([.175 - row * .014, 1.983 - row * .201, .325], [.191 - row * .012, .133, .07], warmSkin, -.05);
    }
    body([.398, 1.214, .129], [.581, 2.13, .14], .14, .125);
    body([.303, 1.302, -.299], [.748, 2.387, -.314], .166, .131);

    layer([.941, 2.326, -.003], [.298, .31, .331], warmSkin, .29);
    body([.902, 2.424, .037], [1.538, 1.576, .092], .238, .213);
    body([.956, 2.406, .181], [1.559, 1.636, .188], .208, .121, warmSkin);
    body([.991, 2.365, -.126], [1.511, 1.646, -.074], .194, .131);
    layer([1.498, 1.677, .051], [.151, .149, .146], skin, .27);
    body([1.429, 1.753, .044], [2.107, 1.102, .134], .145, .14);
    body([1.475, 1.69, .132], [1.984, 1.238, .171], .104, .081, warmSkin);
    body([1.977, 1.233, .111], [2.247, .972, .153], .079, .081);
    body([2.125, 1.098, .152], [2.389, .821, .157], .109, .077);
    body([2.173, 1.049, .185], [2.238, .843, .207], .047, .04);
    for (let finger = 0; finger < 4; finger += 1) {
      const offset = (finger - 1.5) * .037;
      body([2.34 + offset, .854 + offset, .152], [2.527 + offset - finger * .02, .685 + offset + finger * .021, .151], .023, .026);
    }

    body([.3, .995, -.056], [.475, -.553, -.028], .353, .37, shorts);
    body([.429, .132, -.017], [.493, -.553, -.008], .371, .366, shorts);
    scene.tube([mirrored([.473, -.266, -.019], side), mirrored([.482, -.493, -.009], side)], [.345, .35], shorts);
    scene.tube([mirrored([.482, -.44, -.009], side), mirrored([.492, -.504, -.009], side)], [.352, .354], waistband);
    body([.487, -.361, .027], [.461, -1.192, .059], .258, .253);
    body([.466, -.572, .179], [.444, -1.212, .204], .151, .108, warmSkin);
    layer([.457, -1.193, .049], [.165, .198, .173], skin, -.091);
    body([.474, -1.159, -.014], [.639, -2.572, -.029], .243, .229);
    body([.511, -1.316, -.095], [.605, -2.221, -.078], .208, .189, warmSkin);
    body([.488, -1.281, .124], [.658, -2.594, .117], .119, .115);
    layer([.647, -2.532, .057], [.094, .185, .112], skin, -.1);
    layer([.651, -2.657, .061], [.099, .103, .109], sock, -.07);
    scene.ellipsoid(mirrored([.681, -2.746, .213], side), [.17, .145, .29], shoe, [-.12, .17 * side, 0]);
    scene.ellipsoid(mirrored([.682, -2.83, .242], side), [.174, .055, .294], sole, [0, .17 * side, 0]);
    scene.ellipsoid(mirrored([.702, -2.793, .407], side), [.113, .05, .123], '#f2efeb', [-.15, .17 * side, 0]);
    for (let lace = 0; lace < 4; lace += 1) {
      path([[.594 + lace * .009, -2.676 - lace * .023, .223 + lace * .043], [.684 + lace * .008, -2.627 - lace * .021, .245 + lace * .04], [.746 + lace * .007, -2.681 - lace * .02, .24 + lace * .044]], .013, '#f6f4ef');
    }
  }

  curve(scene, [[2.031, 1.19, .177], [2.069, 1.178, .217], [2.115, 1.124, .205], [2.131, 1.08, .148], [2.106, 1.102, .093], [2.055, 1.154, .065], [2.023, 1.193, .107], [2.031, 1.19, .177]], .012, gold);
}

function makeSkeleton(scene) {
  const { ivory, cream, shaded, cartilage, socket, teeth } = boneColors;
  const bone = (start, end, width, endWidth = width * 1.36) => {
    scene.tube([start, end], [width, width], ivory);
    scene.sphere(start, endWidth, cream);
    scene.sphere(end, endWidth, cream);
  };

  scene.ellipsoid([0, 3.475, -.035], [.35, .41, .337], ivory);
  scene.ellipsoid([0, 3.23, .085], [.29, .23, .252], cream);
  scene.ellipsoid([0, 3.258, .31], [.055, .092, .029], socket, [0, 0, .07]);
  scene.ellipsoid([0, 3.137, .273], [.188, .085, .076], shaded);
  scene.ellipsoid([0, 3.033, .111], [.237, .105, .201], ivory);
  for (let tooth = 0; tooth < 8; tooth += 1) {
    const x = (tooth - 3.5) * .045;
    const z = .323 - 1.25 * x * x;
    scene.box([x, 3.154, z], [.039, .055, .033], teeth);
    scene.box([x, 3.102, z - .012], [.037, .043, .03], teeth);
  }

  for (let index = 0; index < 24; index += 1) {
    const progress = index / 23;
    const y = 2.98 - progress * 3.14;
    const z = -.24 + .135 * Math.cos(progress * Math.PI * 2.1);
    const size = .085 + progress * .072;
    scene.ellipsoid([0, y, z], [size, .055, size * .89], ivory);
    scene.ellipsoid([0, y - .021, z - .091], [.06, .028, .08], cream);
    if (index !== 23) {
      scene.ellipsoid([0, y - .061, z], [size * .8, .022, size * .7], cartilage);
    }
  }

  scene.ellipsoid([0, -.135, -.16], [.154, .234, .123], shaded, [-.13, 0, 0]);
  spindle(scene, [0, 1.265, .353], [0, 2.324, .3], .096, .055, cream);
  scene.ellipsoid([0, 1.302, .367], [.062, .118, .035], ivory);

  for (const side of [-1, 1]) {
    const point = (x, y, z) => [x * side, y, z];
    const path = (points, radius, color, endRadius = radius) => {
      curve(scene, points.map((coordinate) => mirrored(coordinate, side)), radius, color, endRadius);
    };
    scene.ellipsoid(point(.146, 3.407, .275), [.104, .098, .04], socket, [0, .1 * side, .1 * side]);
    scene.ellipsoid(point(.231, 3.245, .211), [.104, .102, .071], cream);
    path([[.223, 3.261, .055], [.245, 3.13, .07], [.226, 3.053, .16], [.123, 3.03, .269]], .044, ivory, .034);

    path([[.065, 2.4, .171], [.268, 2.49, .258], [.588, 2.442, .171], [.917, 2.382, -.016]], .065, cream, .058);
    scene.ellipsoid(point(.539, 2.139, -.306), [.256, .353, .075], ivory, [.07, -.29 * side, -.29 * side]);
    path([[.282, 2.191, -.363], [.568, 2.28, -.367], [.859, 2.33, -.142]], .057, cream);

    // Seven true ribs, three false ribs, and two floating ribs on each side.
    for (let index = 0; index < 12; index += 1) {
      const y = 2.391 - index * .108;
      const width = .36 + .38 * Math.sin((index + 1) * Math.PI / 14);
      const rearZ = -.295 - .036 * Math.sin(index * .3);
      const frontY = y - .15 - .038 * index;
      const frontZ = .296 + .069 * Math.sin(index * .28);
      const ribs = [
        [.071, y, rearZ], [width * .58, y + .025, rearZ - .033],
        [width, y - .061, -.091], [width * .86, y - .185, .161],
      ];
      if (index < 10) {
        ribs.push([width * .57, frontY - .065, frontZ - .041]);
        path(ribs, .045 - index * .0017, ivory, .037 - index * .0012);
        const last = ribs.at(-1);
        const connection = index < 7
          ? [.072, Math.max(1.32, frontY), frontZ]
          : [.2 + (index - 7) * .09, 1.265 - (index - 7) * .083, frontZ - .03];
        path([last, [last[0] * .68 + connection[0] * .32, last[1] + .032, frontZ + .016], connection], .03, cartilage);
      } else {
        path(ribs, .027, ivory, .016);
      }
    }

    scene.ellipsoid(point(.334, -.03, -.156), [.302, .249, .133], ivory, [0, -.37 * side, -.33 * side]);
    path([[.153, .077, -.235], [.359, .184, -.18], [.584, .105, -.057], [.601, -.068, .067]], .058, cream);
    path([[.551, -.106, .049], [.557, -.275, .133], [.336, -.372, .158], [.119, -.28, .195], [.032, -.335, .164]], .066, ivory);
    path([[.568, -.192, -.025], [.502, -.373, -.02], [.337, -.474, .078], [.202, -.418, .171]], .058, ivory);
    scene.sphere(point(.461, -.267, .021), .119, shaded);

    bone(point(.889, 2.347, -.015), point(1.402, 1.206, .057), .089, .125);
    bone(point(1.376, 1.172, .089), point(1.61, .334, .037), .053, .07);
    bone(point(1.482, 1.174, -.029), point(1.735, .313, .015), .043, .061);
    scene.ellipsoid(point(1.676, .246, .003), [.099, .096, .068], cream, [0, 0, -.18 * side]);
    bone(point(1.621, .222, .019), point(1.508, .02, .067), .026, .034);
    bone(point(1.508, .02, .067), point(1.483, -.052, .081), .023, .028);
    for (let finger = 0; finger < 4; finger += 1) {
      const x = 1.613 + finger * .064;
      const baseY = .083 - finger * .01;
      const tipY = -.184 - [0, .049, .035, -.019][finger];
      bone(point(x, .225 - finger * .012, .017), point(x + .022, baseY, .021), .026, .033);
      bone(point(x + .022, baseY, .021), point(x + .035, tipY * .29, .04), .023, .028);
      bone(point(x + .035, tipY * .29, .04), point(x + .043, tipY * .68, .049), .019, .022);
      bone(point(x + .043, tipY * .68, .049), point(x + .045, tipY, .06), .015, .018);
    }

    path([[.429, -.278, -.012], [.568, -.425, -.021], [.509, -.585, .054]], .098, cream);
    bone(point(.509, -.585, .054), point(.399, -1.82, .058), .095, .133);
    scene.ellipsoid(point(.406, -1.865, .169), [.102, .123, .06], cream);
    bone(point(.387, -1.936, .054), point(.447, -3.378, .034), .075, .116);
    bone(point(.514, -1.935, -.037), point(.539, -3.334, -.003), .038, .062);
    scene.ellipsoid(point(.484, -3.464, -.018), [.12, .112, .204], cream);
    scene.ellipsoid(point(.476, -3.482, .19), [.112, .08, .143], ivory);
    for (let toe = 0; toe < 5; toe += 1) {
      const x = .391 + toe * .051;
      const z = .366 - toe * .018;
      const width = .029 - toe * .0027;
      bone(point(.45 + toe * .021, -3.47, .132), point(x, -3.54, z), width, width * 1.32);
      bone(point(x, -3.54, z), point(x, -3.548, z + .143 - toe * .009), width * .79, width * 1.18);
    }
  }
}

function makeVeins(scene) {
  const { artery, fineArtery, vein, fineVein, connection, heart } = vesselColors;

  scene.ellipsoid([-.127, 1.89, .035], [.19, .277, .158], heart, [.11, 0, -.48]);
  scene.ellipsoid([.099, 1.946, .041], [.184, .224, .16], '#d66275', [0, 0, .19]);
  curve(scene, [[.041, 1.834, .126], [.129, 2.036, .097], [.146, 2.273, -.007], [.014, 2.382, -.053], [-.161, 2.229, -.105], [-.132, 1.741, -.154], [-.085, .88, -.103], [-.066, .151, -.046], [-.042, -.182, .003]], .084, artery, .059);
  curve(scene, [[.144, 2.33, -.146], [.219, 2.091, -.113], [.164, 1.843, -.019]], .08, vein);
  curve(scene, [[.139, 1.942, -.044], [.249, 1.368, -.114], [.195, .658, -.091], [.155, .098, -.037], [.096, -.218, .003]], .077, vein, .063);

  for (const side of [-1, 1]) {
    const vessel = (path, size, color, tip) => {
      curve(scene, path.map((point) => mirrored(point, side)), size, color, tip);
    };
    vessel([[.025, 2.269, -.035], [.149, 2.463, .006], [.161, 2.86, .065], [.225, 3.217, .081], [.278, 3.493, .012], [.164, 3.739, -.061]], .054, artery, .019);
    vessel([[.104, 2.259, -.114], [.226, 2.47, -.039], [.263, 2.844, -.03], [.331, 3.203, -.085], [.293, 3.491, -.201], [.071, 3.694, -.187]], .061, vein, .022);
    vessel([[.204, 3.17, .084], [.169, 3.326, .201], [.125, 3.494, .215], [.047, 3.603, .16]], .031, artery, .012);
    vessel([[.324, 3.188, -.099], [.285, 3.333, .084], [.242, 3.531, .187], [.086, 3.689, .112]], .028, fineVein, .012);
    vessel([[.244, 3.43, .072], [.306, 3.559, .02], [.268, 3.691, -.09], [.16, 3.771, -.145]], .022, connection, .009);
    vessel([[.151, 2.418, .015], [.475, 2.415, .051], [.89, 2.285, .008], [1.072, 2.06, .04], [1.218, 1.59, .108], [1.411, 1.178, .164], [1.482, .749, .103], [1.625, .31, .082], [1.68, .093, .102]], .054, artery, .024);
    vessel([[.198, 2.443, -.026], [.537, 2.454, -.093], [.943, 2.255, -.113], [1.143, 1.978, -.101], [1.321, 1.511, -.091], [1.488, 1.126, -.066], [1.637, .608, -.063], [1.738, .235, -.061], [1.727, .074, -.021]], .063, vein, .028);
    vessel([[.882, 2.282, .015], [1.085, 2.273, -.153], [1.237, 2.087, -.193], [1.263, 1.823, -.125], [1.321, 1.503, -.051]], .035, fineVein, .022);
    vessel([[1.397, 1.163, .162], [1.504, .961, .177], [1.587, .655, .133], [1.73, .253, .072]], .031, artery, .021);
    vessel([[1.479, 1.136, -.064], [1.462, .921, .024], [1.501, .642, .015], [1.62, .319, -.081], [1.727, .074, -.021]], .036, fineVein, .024);
    vessel([[1.275, 1.504, -.077], [1.22, 1.526, .077], [1.236, 1.685, .143], [1.16, 1.968, .07]], .024, connection, .015);
    vessel([[1.745, .131, .011], [1.624, .089, .097], [1.581, .002, .11], [1.525, -.085, .092]], .022, fineVein, .01);
    for (let finger = 0; finger < 4; finger += 1) {
      const x = 1.615 + finger * .066;
      const y = -.186 - [0, .044, .024, -.039][finger];
      vessel([[1.682, .161, .078], [x, .053, .077], [x + .023, y + .081, .081], [x + .043, y, .059]], .016, fineArtery, .009);
      vessel([[1.729, .131, -.03], [x + .016, .044, -.011], [x + .05, y + .065, -.003], [x + .042, y, .059]], .017, fineVein, .009);
    }

    for (let rib = 0; rib < 6; rib += 1) {
      const y = 2.02 - rib * .155;
      const width = .57 + .085 * Math.sin(rib * .64);
      vessel([[.103, y, -.12], [width * .65, y + .003, -.27], [width, y - .11, -.109], [width * .83, y - .15, .17], [.277, y - .087, .243]], .025, artery, .012);
      vessel([[.14, y - .058, -.087], [width * .68, y - .044, -.273], [width, y - .164, -.106], [width * .79, y - .209, .174], [.246, y - .14, .246]], .028, vein, .012);
    }
    vessel([[.212, 2.337, .12], [.349, 2.136, .265], [.324, 1.798, .289], [.273, 1.412, .254], [.176, 1.093, .225], [.151, .635, .184], [.229, .262, .141]], .028, fineArtery, .014);
    vessel([[.413, 2.394, .155], [.461, 2.142, .262], [.407, 1.784, .282], [.354, 1.379, .258], [.268, .976, .211], [.2, .621, .186], [.279, .203, .11]], .032, fineVein, .015);
    vessel([[.073, .964, -.079], [.24, .92, -.119], [.398, .79, -.142], [.493, .719, -.205]], .04, artery, .02);
    vessel([[.118, .808, -.06], [.307, .769, -.092], [.428, .65, -.145], [.448, .516, -.209]], .047, vein, .023);
    vessel([[.056, .441, -.043], [.193, .371, .101], [.255, .229, .173], [.345, .137, .09]], .035, fineArtery, .014);
    vessel([[.079, .326, -.029], [.225, .24, .075], [.287, .086, .136], [.345, .137, .09]], .035, fineVein, .014);

    vessel([[.064, -.176, -.003], [.288, -.248, .014], [.405, -.443, .082], [.398, -.874, .141], [.442, -1.334, .068], [.453, -1.82, .03], [.439, -2.334, .082], [.453, -2.96, .07], [.48, -3.42, .09], [.464, -3.5, .37]], .064, artery, .023);
    vessel([[.069, -.206, -.025], [.318, -.247, -.068], [.467, -.449, -.047], [.484, -.934, -.1], [.494, -1.433, -.1], [.502, -1.847, -.08], [.541, -2.385, -.132], [.528, -3.037, -.107], [.545, -3.425, -.046], [.51, -3.498, .341]], .066, vein, .026);
    vessel([[.458, -.638, .037], [.618, -.754, .044], [.618, -1.113, .018], [.544, -1.53, -.014], [.461, -1.821, .031]], .037, fineArtery, .017);
    vessel([[.375, -.319, -.037], [.33, -.652, .121], [.304, -1.179, .114], [.335, -1.748, .079], [.38, -2.321, .096], [.413, -2.898, .106], [.433, -3.392, .087], [.51, -3.498, .341]], .038, fineVein, .02);
    vessel([[.47, -1.868, -.067], [.397, -2.195, -.099], [.413, -2.53, -.088], [.447, -2.945, -.04], [.554, -3.426, -.019]], .036, fineVein, .018);
    vessel([[.459, -1.824, .039], [.552, -2.159, .017], [.54, -2.612, .051], [.536, -3.043, .04], [.492, -3.448, .12]], .034, fineArtery, .017);
    vessel([[.494, -1.181, -.091], [.523, -1.288, .031], [.49, -1.431, .079], [.418, -1.488, .098]], .023, connection, .014);

    for (let toe = 0; toe < 5; toe += 1) {
      const x = .379 + toe * .063;
      const z = .505 - toe * .026;
      vessel([[.473, -3.476, .236], [x, -3.516, .348], [x, -3.535, z]], .017, fineArtery, .008);
      vessel([[.502, -3.477, .209], [x + .015, -3.486, .342], [x, -3.535, z]], .018, fineVein, .009);
    }
  }
}

function makeOrgans(scene) {
  const {
    brain, fold, cord, trachea, lungs, lungDetail, heart, artery, vein, liver, kidneys,
    stomach, pancreas, colon, smallIntestine, appendix, diaphragm, bladder, gallbladder, spleen,
  } = organColors;

  for (const side of [-1, 1]) {
    scene.ellipsoid([.213 * side, 2.792, -.045], [.291, .348, .362], brain, [0, .08 * side, -.12 * side]);
    scene.ellipsoid([.163 * side, 2.571, -.248], [.214, .181, .229], fold);
    for (let foldIndex = 0; foldIndex < 5; foldIndex += 1) {
      const y = 2.575 + foldIndex * .101;
      const outerX = .495 - .049 * Math.abs(foldIndex - 2);
      const route = [[.058, y + .107, .221], [.247, y + .083, .298], [outerX, y, .149], [outerX, y + .033, -.108], [.287, y + .077, -.336], [.07, y + .105, -.351]];
      curve(scene, route.map((point) => mirrored(point, side)), .029, fold, .021);
    }
  }
  scene.ellipsoid([0, 2.448, -.211], [.098, .179, .096], cord);
  curve(scene, [[0, 2.452, -.209], [0, 2.189, -.161], [0, 1.708, -.224], [0, 1.077, -.287], [0, .417, -.265], [0, -.257, -.235]], .056, cord, .029);
  curve(scene, [[0, 2.222, .101], [0, 1.914, .191], [0, 1.617, .221], [0, 1.366, .21]], .108, trachea, .077);
  for (let ring = 0; ring < 7; ring += 1) {
    scene.ellipsoid([0, 2.166 - ring * .105, .133 + ring * .013], [.118 - ring * .004, .03, .096], '#f2d9be');
  }
  curve(scene, [[.027, 2.115, -.045], [.052, 1.651, -.025], [.083, 1.083, -.243], [.236, .295, -.09], [.469, .115, .143]], .066, stomach);

  // The right lung has three lobes. The left lung has two and leaves room for the heart.
  scene.ellipsoid([-.53, 1.174, .027], [.346, .564, .367], lungs, [0, 0, -.17]);
  scene.ellipsoid([-.638, .886, .152], [.334, .428, .345], '#e79a8b', [0, -.08, -.15]);
  scene.ellipsoid([-.528, .629, -.046], [.382, .348, .353], '#d27c73', [-.18, -.11, -.12]);
  scene.ellipsoid([.511, 1.181, .014], [.312, .558, .338], lungs, [0, .09, .17]);
  scene.ellipsoid([.593, .679, -.039], [.326, .398, .331], '#d27c73', [-.09, .13, .04]);
  curve(scene, [[-.895, 1.024, -.055], [-.819, .99, .242], [-.53, 1.009, .459], [-.295, 1.044, .257]], .026, lungDetail);
  curve(scene, [[-.898, .651, -.164], [-.765, .703, .252], [-.492, .741, .437], [-.271, .759, .201]], .024, lungDetail);
  curve(scene, [[.864, .95, -.088], [.783, .907, .227], [.563, .853, .306], [.352, .842, .181]], .024, lungDetail);
  for (const side of [-1, 1]) {
    curve(scene, [[0, 1.438, .213], [.29 * side, 1.294, .204], [.509 * side, 1.181, .251], [.627 * side, .953, .311]], .072, trachea, .029);
    curve(scene, [[.402 * side, 1.236, .218], [.522 * side, 1.351, .268], [.601 * side, 1.45, .216]], .046, trachea, .022);
    curve(scene, [[.539 * side, 1.151, .264], [.625 * side, 1.098, .35], [.75 * side, 1.05, .276]], .036, trachea, .017);
  }

  scene.ellipsoid([.155, .795, .308], [.24, .358, .215], heart, [.15, .06, .4]);
  scene.ellipsoid([-.019, .925, .291], [.19, .224, .186], '#cc5561', [.13, 0, -.25]);
  curve(scene, [[-.025, .87, .427], [.049, 1.01, .483], [.11, 1.228, .402], [.022, 1.305, .321], [-.103, 1.264, .247]], .076, artery, .055);
  curve(scene, [[.111, .939, .371], [.246, 1.093, .349], [.416, 1.173, .275], [.481, 1.199, .183]], .066, vein, .04);
  curve(scene, [[.016, .982, .488], [.14, .86, .499], [.204, .72, .49], [.281, .586, .401]], .026, '#e88975', .012);
  curve(scene, [[-.035, .989, .47], [.089, .934, .502], [.214, .945, .481], [.308, .884, .407]], .025, '#e88975', .012);

  scene.ellipsoid([-.277, .308, .002], [.546, .083, .321], diaphragm, [.17, 0, .12]);
  scene.ellipsoid([.352, .319, -.012], [.443, .073, .307], diaphragm, [.14, 0, -.12]);
  scene.ellipsoid([-.431, .055, .19], [.44, .222, .301], liver, [.12, -.1, -.29]);
  scene.ellipsoid([-.066, .083, .169], [.34, .174, .256], '#965665', [.08, .07, .17]);
  scene.ellipsoid([-.396, -.124, .28], [.068, .11, .067], gallbladder, [0, .27, -.23]);
  scene.ellipsoid([.426, -.02, .187], [.253, .264, .238], stomach, [-.1, -.12, -.32]);
  curve(scene, [[.495, .16, .164], [.531, .019, .196], [.377, -.185, .242], [.22, -.212, .263], [.109, -.175, .202]], .138, stomach, .068);
  scene.ellipsoid([.684, -.046, -.144], [.135, .188, .15], spleen, [-.18, .06, -.19]);
  spindle(scene, [-.187, -.268, -.044], [.519, -.19, -.035], .104, .127, pancreas);

  for (const side of [-1, 1]) {
    const y = -.293 + side * .057;
    scene.ellipsoid([.461 * side, y, -.307], [.148, .197, .134], kidneys, [-.19, .1 * side, -.21 * side]);
    scene.ellipsoid([.408 * side, y - .05, -.334], [.126, .121, .123], '#aa5358');
    scene.ellipsoid([.461 * side, y + .156, -.334], [.1, .064, .107], pancreas, [0, 0, -.3 * side]);
    curve(scene, [[.375 * side, y + .02, -.33], [.308 * side, y - .06, -.346], [.268 * side, -.803, -.239], [.105 * side, -1.385, -.131]], .024, trachea, .017);
    curve(scene, [[.037 * side, y + .019, -.271], [.245 * side, y + .06, -.364], [.431 * side, y + .013, -.376]], .034, artery, .022);
    curve(scene, [[.079 * side, y - .067, -.302], [.222 * side, y - .034, -.395], [.42 * side, y - .047, -.379]], .033, vein, .024);
  }

  const largeBowel = [
    [-.56, -1.251, .077], [-.675, -1.055, .041], [-.656, -.667, .022],
    [-.606, -.439, .109], [-.346, -.394, .281], [-.014, -.452, .303],
    [.336, -.437, .274], [.605, -.4, .152], [.668, -.686, .098],
    [.616, -.983, .147], [.525, -1.205, .208], [.219, -1.305, .145],
    [.077, -1.477, .004], [.083, -1.622, -.062],
  ];
  curve(scene, largeBowel, .114, colon, .077);
  for (const [x, y, z] of largeBowel.slice(0, -2)) {
    scene.ellipsoid([x, y, z + .025], [.115, .104, .102], '#b8788a');
  }
  curve(scene, [[-.56, -1.232, .08], [-.52, -1.358, .126], [-.583, -1.45, .134]], .054, appendix, .025);
  curve(scene, [[.084, -.272, .158], [-.343, -.553, .18], [-.427, -.682, .2], [.393, -.645, .233], [.454, -.784, .199], [-.428, -.816, .19], [-.468, -.94, .205], [.415, -.956, .223], [.427, -1.074, .21], [-.363, -1.074, .21], [-.463, -1.179, .173], [-.535, -1.22, .153]], .078, smallIntestine, .058);
  scene.ellipsoid([.066, -1.424, .106], [.187, .161, .156], bladder, [-.12, 0, .05]);
  curve(scene, [[.066, -1.454, .099], [.064, -1.555, .081], [.067, -1.65, .053]], .048, bladder, .034);
}

export const anatomyModels = {
  muscle: makeMuscle,
  muscleBoundNotes: makeMuscleBoundNotes,
  skeleton: makeSkeleton,
  veins: makeVeins,
  organs: makeOrgans,
};
