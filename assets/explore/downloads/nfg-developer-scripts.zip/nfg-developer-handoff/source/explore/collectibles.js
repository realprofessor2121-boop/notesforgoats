const ink = '#161d25';
const ivory = '#fff2c5';

const metal = '#99a8b0';
const blue = '#4397c8';
const brass = '#c39754';

function waterBill(scene) {
    scene.box([0, 0.11, 0], [1.47, 0.22, 0.98], '#455b6c');
    scene.tube([[0, 0.2, 0], [0, 0.57, 0], [0.04, 0.88, 0], [0.3, 1.1, 0], [0.66, 1.1, 0],
        [0.86, 0.9, 0], [0.86, 0.72, 0]], 0.17, metal);
    scene.tube([[0.86, 0.82, 0], [0.86, 0.7, 0]], 0.182, '#617888');
    scene.tube([[0, 0.63, 0], [0, 1.28, 0]], 0.089, metal);
    scene.tube([[-0.29, 1.29, 0], [0.29, 1.29, 0]], 0.068, blue);
    scene.sphere([0, 1.29, 0], 0.1, blue);
    scene.tube([[0.86, 0.19, 0], [0.86, 0.31, 0], [0.86, 0.51, 0]], [0.046, 0.127, 0.006], blue);
    scene.sphere([0.86, 0.26, 0], 0.1, blue);
}

function housingBill(scene) {
    scene.box([0, 0.09, 0], [2.18, 0.18, 1.51], '#50686d');
    scene.box([0, 0.55, 0], [1.72, 0.84, 1.12], '#e7d8b0');
    scene.box([-0.48, 1.11, 0], [1.16, 0.12, 1.39], '#8e4650', [0, 0, 0.48]);
    scene.box([0.48, 1.11, 0], [1.16, 0.12, 1.39], '#8e4650', [0, 0, -0.48]);
    scene.box([0.58, 1.17, -0.26], [0.23, 0.44, 0.25], '#724f4c');
    scene.box([0, 0.44, 0.568], [0.36, 0.61, 0.034], '#465b66');
    scene.sphere([0.112, 0.39, 0.614], 0.035, brass);
    for (const side of [-1, 1]) {
        scene.box([side * 0.543, 0.6, 0.575], [0.3, 0.32, 0.035], '#fff0ce');
        scene.box([side * 0.543, 0.6, 0.6], [0.225, 0.246, 0.025], blue);
        scene.box([side * 0.543, 0.6, 0.62], [0.026, 0.242, 0.012], '#d4e4d9');
    }
}

function wasteBill(scene) {
    for (const [x, body, lid] of [[-0.58, '#447d69', '#77a582'], [0.55, '#425d88', '#6595bd']]) {
        scene.box([x, 0.5, 0], [0.86, 0.83, 0.76], body);
        scene.box([x, 0.96, 0], [0.98, 0.15, 0.87], lid);
        scene.box([x, 1.07, -0.255], [0.36, 0.085, 0.11], body);
        for (const side of [-1, 1]) {
            scene.tube([[x + side * 0.28, 0.106, -0.3], [x + side * 0.45, 0.106, -0.3]], 0.13, ink);
        }
    }
    const arrows = [[[-0.75, 0.63], [-0.53, 0.72], [-0.40, 0.58]],
        [[-0.38, 0.53], [-0.48, 0.36], [-0.65, 0.38]], [[-0.71, 0.39], [-0.84, 0.47], [-0.78, 0.58]]];
    for (const arrow of arrows) {
        scene.tube(arrow.map(([x, y]) => [x, y, 0.39]), [0.022, 0.024, 0.034], ivory);
    }
}

function insuranceBill(scene) {
    const edge = [[-0.87, 0.79, 0.03], [-0.89, 1.34, 0.03], [-0.46, 1.39, 0.03], [0, 1.56, 0.03],
        [0.46, 1.39, 0.03], [0.89, 1.34, 0.03], [0.87, 0.79, 0.03], [0.68, 0.43, 0.03],
        [0.3, 0.13, 0.03], [0, 0.03, 0.03], [-0.3, 0.13, 0.03], [-0.68, 0.43, 0.03], [-0.87, 0.79, 0.03]];
    scene.tube(edge, 0.06, brass);
    scene.ellipsoid([0, 0.82, 0], [0.86, 0.714, 0.15], '#3f6d82');
    scene.tube([[-0.32, 0.79, 0.157], [-0.083, 0.58, 0.172], [0.38, 1.04, 0.155]], 0.071, ivory);
}

function powerBill(scene) {
    scene.box([0, 0.75, 0], [1.24, 1.4, 0.28], '#b2b8ac');
    scene.box([0, 0.75, 0.15], [1.12, 1.27, 0.07], '#e5dfc6');
    for (const socketY of [0.48, 1.03]) {
        scene.ellipsoid([0, socketY, 0.192], [0.39, 0.24, 0.075], '#e9e2c2');
        for (const side of [-1, 1]) {
            scene.box([side * 0.143, socketY + 0.033, 0.266], [0.051, 0.14, 0.017], ink);
        }
        scene.ellipsoid([0, socketY - 0.116, 0.263], [0.041, 0.041, 0.014], ink);
    }
    scene.sphere([0, 0.747, 0.205], 0.026, metal);
}

function heatBill(scene) {
    for (let panel = 0; panel < 7; panel++) {
        const x = (panel - 3) * 0.246;
        scene.ellipsoid([x, 0.65, 0], [0.173, 0.52, 0.243], '#b6ad95');
        scene.box([x, 0.649, 0.12], [0.195, 0.8, 0.275], '#d6ccb1');
    }
    scene.tube([[-0.91, 0.9, 0], [1.09, 0.9, 0], [1.12, 0.62, 0]], 0.069, metal);
    scene.tube([[-0.89, 0.35, 0], [-1.03, 0.31, 0], [-1.03, 0.16, 0]], 0.069, metal);
    for (const side of [-1, 1]) {
        scene.box([side * 0.66, 0.105, 0], [0.2, 0.21, 0.39], '#9c8a72');
    }
    scene.tube([[0.96, 0.93, 0], [0.96, 1.1, 0]], 0.07, brass);
    scene.ellipsoid([0.96, 1.144, 0], [0.14, 0.06, 0.16], '#a44d48');
}

function plumbingBill(scene) {
    const pipe = [[-0.68, 1.44, 0], [-0.68, 0.64, 0.02], [-0.61, 0.39, 0.02], [-0.41, 0.23, 0.01],
        [-0.15, 0.25, 0], [0.059, 0.45, 0], [0.13, 0.67, 0], [0.31, 0.83, 0], [0.94, 0.83, 0]];
    scene.tube(pipe, 0.16, '#b66e4f');
    scene.tube([[-0.68, 1.31, 0], [-0.68, 1.44, 0]], 0.198, brass);
    scene.tube([[-0.68, 0.62, 0.02], [-0.68, 0.77, 0.02]], 0.195, brass);
    scene.tube([[0.79, 0.83, 0], [0.94, 0.83, 0]], 0.19, brass);
    scene.tube([[0.941, 0.83, 0], [0.962, 0.83, 0]], 0.116, '#543a38');
}

function fuelBill(scene) {
    scene.tube([[0, 0.11, 0], [0, 1.3, 0]], 0.57, '#566f79');
    for (const y of [0.16, 0.46, 0.95, 1.27]) {
        scene.tube([[0, y - 0.039, 0], [0, y + 0.039, 0]], 0.595, '#8199a0');
    }
    scene.tube([[0.17, 1.302, 0.11], [0.17, 1.36, 0.11]], 0.113, brass);
    scene.box([0, 0.69, 0.557], [0.54, 0.31, 0.045], '#eac16e');
    scene.tube([[0, 0.6, 0.588], [0, 0.69, 0.588], [0.025, 0.793, 0.588]], [0.031, 0.061, 0.004], ink);
}

function internetBill(scene) {
    scene.box([0, 0.24, 0], [1.91, 0.39, 0.96], '#283b54');
    scene.box([0, 0.455, 0], [1.85, 0.065, 0.89], '#4b5d76');
    for (const side of [-1, 1]) {
        scene.tube([[side * 0.7, 0.43, -0.27], [side * 0.82, 1.34, -0.33]], [0.06, 0.04], '#334760');
        scene.box([side * 0.66, 0.046, 0], [0.24, 0.08, 0.54], ink);
    }
    for (let item = 0; item < 5; item++) {
        scene.sphere([-0.217 + item * 0.112, 0.28, 0.492], 0.025, item < 4 ? '#7acd8a' : '#edb358');
    }
    for (const radius of [0.27, 0.45, 0.64]) {
        scene.tube(Array.from({length: 13}, (_, step) => {
            const angle = 0.75 + step * (Math.PI - 1.5) / 12;
            return [radius * Math.cos(angle), 0.56 + radius * Math.sin(angle), 0.28];
        }), 0.025, blue);
    }
}

function groceriesBill(scene) {
    scene.box([0, 0.53, 0], [1.28, 0.84, 0.67], '#bf8d53');
    scene.box([0, 0.945, 0], [1.17, 0.05, 0.58], '#896044');
    for (const side of [-1, 1]) {
        scene.tube([[-0.34, 0.94, side * 0.307], [-0.32, 1.27, side * 0.302], [-0.18, 1.43, side * 0.303],
            [0.17, 1.43, side * 0.303], [0.32, 1.27, side * 0.302], [0.34, 0.94, side * 0.307]], 0.04, '#a87546');
    }
    scene.ellipsoid([-0.28, 1.1, -0.058], [0.19, 0.52, 0.183], '#d3a65f', [0, 0, -0.23]);
    for (let item = 0; item < 4; item++) {
        scene.box([-0.23 + item * 0.034, 1.54 - item * 0.11, 0.12], [0.12, 0.026, 0.029], '#edc988', [0, 0, -0.25]);
    }
    scene.sphere([0.31, 1.03, 0.12], 0.21, '#bd4742');
    scene.ellipsoid([0.36, 1.23, 0.113], [0.125, 0.03, 0.077], '#527b4c', [0, 0, 0.31]);
    scene.ellipsoid([0.117, 1.13, -0.085], [0.16, 0.27, 0.12], '#658b52', [-0.3, 0.05, -0.3]);
}

function familyBill(scene) {
    const people = [
        { x: -0.61, y: 1.31, scale: 1, shirt: '#bd6756', skin: '#a87755' },
        { x: 0.51, y: 1.39, scale: 1.08, shirt: '#416f89', skin: '#936348' },
        { x: -0.015, y: 0.997, scale: 0.77, shirt: '#c79c48', skin: '#c99469' }
    ];
    scene.ellipsoid([0, 0.081, 0], [1.23, 0.081, 0.58], '#5a6d68');
    for (const {x, y, scale, shirt, skin} of people) {
        const z = scale < 1 ? 0.26 : -0.02;
        const shoulder = y - scale * 0.293;
        scene.ellipsoid([x, y, z], [0.19 * scale, 0.207 * scale, 0.177 * scale], skin);
        scene.ellipsoid([x, y + 0.102 * scale, z - 0.049], [0.18 * scale, 0.13 * scale, 0.148 * scale], '#40322f');
        scene.ellipsoid([x, y - 0.4 * scale, z], [0.235 * scale, 0.31 * scale, 0.13 * scale], shirt);
        for (const side of [-1, 1]) {
            scene.tube([[x + side * 0.18 * scale, shoulder, z], [x + side * 0.28 * scale, shoulder - 0.34 * scale, z]],
                [0.065 * scale, 0.046 * scale], shirt);
            scene.tube([[x + side * 0.1 * scale, 0.59 * scale, z], [x + side * 0.1 * scale, 0.18, z]],
                0.074 * scale, '#313d4d');
            scene.ellipsoid([x + side * 0.1 * scale, 0.180, z + 0.052], [0.075, 0.051, 0.109], ink);
        }
    }
}

function wheel(scene, side, z) {
    const y = 0.46;
    scene.tube([[side * 0.94, y, z], [side * 1.31, y, z]], 0.445, '#1c2027');
    scene.tube([[side * 1.308, y, z], [side * 1.331, y, z]], 0.31, '#111923');
    scene.tube([[side * 1.33, y, z], [side * 1.35, y, z]], 0.24, '#9cb1bf');
    scene.tube([[side * 1.35, y, z], [side * 1.368, y, z]], 0.17, '#233142');
    scene.ellipsoid([side * 1.38, y, z], [0.037, 0.075, 0.075], '#e8ded0');
    for (let spoke = 0; spoke < 6; spoke++) {
        const angle = Math.PI * spoke / 3;
        scene.tube([[side * 1.37, y, z], [side * 1.365, y + 0.222 * Math.sin(angle),
            z + 0.222 * Math.cos(angle)]], 0.023, '#bdc9ce');
    }
}

function broadwayCar(scene, { paint, trim, taxi }) {
    const glass = '#345e76';
    const glow = '#acc4cd';
    const roofHeight = taxi ? 1.72 : 1.54;
    const carWidth = taxi ? 2.19 : 2.25;
    scene.box([0, 0.52, 0], [2.02, 0.28, 4.2], ink);
    scene.ellipsoid([0, 0.79, 0], [1.23, 0.39, 2.52], paint);
    scene.box([0, 0.83, 0], [carWidth, 0.42, 3.82], paint);
    scene.ellipsoid([0, 1.03, 1.55], [1.09, 0.2, 0.92], paint);
    scene.ellipsoid([0, 1.02, -1.68], [1.08, 0.21, 0.71], paint);
    scene.box([0, 1.29, -0.24], [1.78, 0.45, 1.53], glass);
    scene.box([0, roofHeight, -0.22], [1.82, 0.16, 1.61], paint);
    scene.ellipsoid([0, roofHeight + 0.045, -0.22], [0.9, 0.12, 0.83], paint);
    scene.box([0, (roofHeight + 1.09) / 2, 0.76], [1.77, roofHeight - 0.94, 0.09], glass, [0.58, 0, 0]);
    scene.box([0, (roofHeight + 1.08) / 2, -1.13], [1.73, roofHeight - 0.95, 0.09], glass, [-0.53, 0, 0]);
    scene.box([0, 0.68, 2.36], [1.78, 0.17, 0.11], trim);
    scene.box([0, 0.65, -2.34], [1.95, 0.17, 0.11], trim);
    scene.box([0, 0.9, 2.409], [0.91, 0.15, 0.028], ink);
    scene.box([0, 0.797, -2.39], [0.43, 0.12, 0.025], ivory);
    for (let bar = 0; bar < 10; bar++) {
        scene.box([-0.395 + bar * 0.088, 0.9, 2.429], [0.016, 0.105, 0.01], '#78838d');
    }
    for (const side of [-1, 1]) {
        const x = side * (carWidth / 2 + 0.014);
        wheel(scene, side, 1.47);
        wheel(scene, side, -1.52);
        scene.ellipsoid([side * 0.74, 0.938, 2.338], [0.273, 0.102, 0.12], glow);
        scene.ellipsoid([side * 0.79, 0.937, -2.28], [0.25, 0.092, 0.098], '#d83e48');
        scene.ellipsoid([side * 1.02, 1.294, 0.59], [0.16, 0.09, 0.16], paint);
        scene.box([x, 0.89, 0.09], [0.04, 0.026, 1.43], trim);
        scene.box([side * 0.897, 1.37, -0.29], [0.039, roofHeight - 1.01, 0.065], paint);
        scene.box([side * 0.892, 1.28, 0.58], [0.06, roofHeight - 0.88, 0.055], paint, [0.58, 0, 0]);
        scene.box([side * 0.88, 1.28, -0.999], [0.06, roofHeight - 0.88, 0.055], paint, [-0.54, 0, 0]);
        scene.box([x, 0.989, 0.14], [0.034, 0.042, 0.21], trim);
        if (taxi) {
            for (let stripe = 0; stripe < 11; stripe++) {
                scene.box([x, stripe % 2 ? 0.79 : 0.7, -0.642 + stripe * 0.122],
                    [0.027, 0.077, 0.107], ink);
            }
        } else {
            for (const z of [1.72, -1.87]) {
                scene.box([side * 0.13, 1.224, z], [0.12, 0.024, 0.67], ivory);
            }
        }
    }
    if (taxi) {
        scene.box([0, 1.87, -0.18], [0.97, 0.19, 0.34], ink);
        scene.box([0, 1.962, -0.18], [0.85, 0.1, 0.30], '#ffe693');
        for (const side of [-1, 1]) {
            scene.box([side * 0.23, 1.96, -0.18], [0.047, 0.092, 0.317], '#d07622');
        }
    }
}

function apple(scene) {
    for (let lobe = 0; lobe < 5; lobe++) {
        const angle = lobe * Math.PI * 2 / 5;
        scene.ellipsoid([-0.52 + 0.257 * Math.cos(angle), 0.1, 0.26 * Math.sin(angle)],
            [0.49, 0.66, 0.51], ['#cf4531', '#bd342e', '#d54935', '#d74832', '#bd382e'][lobe]);
    }
    scene.ellipsoid([-0.52, -0.31, 0], [0.57, 0.37, 0.55], '#bd362f');
    scene.tube([[-0.51, 0.61, 0], [-0.53, 0.81, 0.01], [-0.47, 0.96, 0.018]], [0.055, 0.049, 0.038], '#79432e');
    scene.ellipsoid([-0.21, 0.84, 0.01], [0.27, 0.065, 0.12], '#59863a', [0.26, -0.32, 0.35]);
    scene.tube([[-0.46, 0.76, 0.012], [-0.21, 0.84, 0.03], [0.04, 0.92, 0.038]], 0.013, '#8aaf57');
    scene.ellipsoid([0.68, -0.27, 0.3], [0.52, 0.39, 0.19], '#cb4530', [0, 0, 0.26]);
    scene.ellipsoid([0.68, -0.25, 0.406], [0.47, 0.33, 0.111], '#fff0b5', [0, 0, 0.26]);
    for (const side of [-1, 1]) {
        scene.ellipsoid([0.69 + side * 0.09, -0.23, 0.513], [0.03, 0.058, 0.012], '#875538', [0, 0, side * -0.53]);
    }
}

function avocado(scene) {
    scene.ellipsoid([-0.67, -0.11, -0.1], [0.52, 0.74, 0.54], '#465b32', [0, 0, 0.21]);
    scene.ellipsoid([-0.8, 0.42, -0.12], [0.398, 0.48, 0.47], '#485f36', [0, 0, 0.26]);
    scene.ellipsoid([-0.93, 0.81, -0.13], [0.088, 0.069, 0.08], '#624f2c');
    for (let index = 0; index < 34; index++) {
        const angle = index * Math.PI * (3 - Math.sqrt(5));
        const y = 1 - (2 * (index + 0.5)) / 34;
        const ring = Math.sqrt(1 - y * y);
        scene.sphere([-0.67 + 0.51 * Math.cos(angle) * ring - y * 0.145, -0.13 + y * 0.7,
            -0.1 + 0.513 * Math.sin(angle) * ring], 0.045, index % 2 ? '#58713d' : '#394e31');
    }
    scene.ellipsoid([0.65, -0.08, 0.1], [0.57, 0.78, 0.42], '#425c32', [0.04, 0, -0.18]);
    scene.ellipsoid([0.75, 0.42, 0.08], [0.42, 0.53, 0.37], '#425c32', [0, 0, -0.24]);
    scene.ellipsoid([0.65, -0.07, 0.258], [0.52, 0.709, 0.265], '#82a748', [0.04, 0, -0.18]);
    scene.ellipsoid([0.75, 0.4, 0.223], [0.376, 0.488, 0.235], '#82a748', [0, 0, -0.24]);
    scene.ellipsoid([0.65, -0.052, 0.289], [0.441, 0.636, 0.248], '#d0dc69', [0.04, 0, -0.18]);
    scene.ellipsoid([0.74, 0.357, 0.276], [0.325, 0.46, 0.216], '#d0dc69', [0, 0, -0.22]);
    scene.ellipsoid([0.624, -0.176, 0.481], [0.29, 0.34, 0.177], '#a35f39', [0, 0, -0.16]);
    scene.ellipsoid([0.581, -0.14, 0.596], [0.203, 0.243, 0.069], '#af7246', [0, 0, -0.16]);
}

function saladBowl(scene) {
    scene.ellipsoid([0, 0.34, 0], [1.53, 0.43, 1.42], '#4f7284');
    scene.ellipsoid([0, 0.18, 0], [1.08, 0.18, 1.03], '#395d70');
    scene.ellipsoid([0, 0.62, 0], [1.5, 0.19, 1.38], '#d9e3dd');
    scene.ellipsoid([0, 0.69, 0], [1.35, 0.11, 1.25], '#6e8948');
    const greens = ['#365e39', '#537a3b', '#779546', '#638b43'];
    for (let index = 0; index < 20; index++) {
        const angle = index * Math.PI * (3 - Math.sqrt(5));
        const radius = Math.sqrt((index + 0.5) / 20);
        scene.ellipsoid([Math.cos(angle) * radius, 0.78 + 0.1 * (1 - radius), Math.sin(angle) * radius],
            [0.36, 0.075, 0.22], greens[index % greens.length], [0.3 * Math.sin(angle), angle, 0.15]);
    }
    for (const [x, z] of [[-0.74, 0.27], [-0.38, -0.53], [0.42, -0.23], [0.43, 0.58], [0.03, 0.16]]) {
        scene.ellipsoid([x, 0.93, z], [0.17, 0.143, 0.145], '#d4583e');
        scene.ellipsoid([x - 0.03, 1.009, z + 0.02], [0.09, 0.064, 0.084], '#e77b54');
    }
    for (const [x, z, rotation] of [[-0.19, 0.63, 0.67], [0.51, 0.18, 0.11], [0.31, -0.69, -0.92], [-0.64, -0.25, -0.27]]) {
        scene.ellipsoid([x, 0.912, z], [0.23, 0.047, 0.155], '#4d8247', [0.18, rotation, 0]);
        scene.ellipsoid([x, 0.94, z], [0.202, 0.04, 0.12], '#a8c96d', [0.18, rotation, 0]);
    }
    for (const [x, z, direction] of [[-0.25, -0.23, 0.2], [0.02, -0.48, 1.32], [-0.4, 0.26, 2.51], [0.66, 0.37, -1.18]]) {
        scene.box([x, 0.944, z], [0.30, 0.046, 0.075], '#f1a545', [0, direction, 0.12]);
    }
}

function ricePlate(scene) {
    scene.ellipsoid([0, 0.06, 0], [1.64, 0.115, 1.55], '#657f9a');
    scene.ellipsoid([0, 0.135, 0], [1.6, 0.082, 1.51], '#e7e9e0');
    scene.ellipsoid([0, 0.166, 0], [1.31, 0.052, 1.24], '#cbd8d9');
    scene.ellipsoid([-0.58, 0.3, -0.23], [0.61, 0.22, 0.67], '#eee2c8');
    for (let grain = 0; grain < 34; grain++) {
        const angle = grain * Math.PI * (3 - Math.sqrt(5));
        const radius = Math.sqrt(grain / 34);
        scene.ellipsoid([-0.58 + 0.58 * radius * Math.cos(angle), 0.31 + 0.21 * Math.sqrt(1 - radius ** 2),
            -0.23 + 0.63 * radius * Math.sin(angle)], [0.105, 0.034, 0.04],
        grain % 2 ? '#f8ead0' : '#dccaac', [0.13, angle, 0.15]);
    }
    scene.ellipsoid([0.43, 0.32, 0.3], [0.72, 0.15, 0.37], '#b75f41', [0, -0.44, 0]);
    scene.ellipsoid([0.43, 0.416, 0.3], [0.67, 0.13, 0.33], '#eb8b69', [0, -0.44, 0]);
    for (let index = 0; index < 5; index++) {
        const x = 0.01 + index * 0.166;
        const z = 0.09 + index * 0.079;
        scene.tube([[x + 0.065, 0.51, z - 0.15], [x + 0.025, 0.553, z - 0.017],
            [x - 0.088, 0.51, z + 0.113]], 0.013, '#f3b18b');
    }
    for (const [x, z] of [[0.53, -0.55], [0.78, -0.44], [0.27, -0.69], [0.82, -0.74]]) {
        scene.tube([[x, 0.22, z], [x + 0.036, 0.4, z]], [0.065, 0.085], '#729449');
        for (const [offsetX, offsetZ, shade] of [[0.05, -0.07, '#537c3f'], [0.106, 0.07, '#719548'], [-0.07, 0.076, '#456e3d']]) {
            scene.ellipsoid([x + offsetX, 0.46, z + offsetZ], [0.146, 0.117, 0.134], shade);
        }
    }
}

export const collectibleModels = {
    waterBill,
    housingBill,
    wasteBill,
    insuranceBill,
    powerBill,
    heatBill,
    plumbingBill,
    fuelBill,
    internetBill,
    groceriesBill,
    familyBill,
    transportBill(scene) {
        broadwayCar(scene, { paint: '#457d85', trim: '#bac6c6', taxi: false });
    },
    broadwayTaxi(scene) {
        broadwayCar(scene, { paint: '#f3b433', trim: '#7a572c', taxi: true });
    },
    broadwayCoupe(scene) {
        broadwayCar(scene, { paint: '#b73849', trim: '#b6b5b7', taxi: false });
    },
    apple,
    avocado,
    saladBowl,
    ricePlate
};
