const origin = 'https://nfg-360-lesson-gallery.mrdeyomusic.chatgpt.site';
const idPattern = /^[a-f0-9-]{36}$/i;
const endpoint = '/api/community';
const projections = 'id, owner_id, author, body, link, parent_id, created_at';
const headers = { 'Cache-Control': 'private, no-store' };

function json(payload, status = 200) {
    return Response.json(payload, { status, headers });
}

function entry(row, viewer) {
    return {
        id: row.id, author: row.author, body: row.body, link: row.link || '',
        createdAt: new Date(row.created_at).toISOString(), canDelete: row.owner_id === viewer,
    };
}

function externalLink(value) {
    if (!value) return '';
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && !url.username && !url.password && url.href.length <= 500 ? url.href : null;
    } catch {
        return null;
    }
}

async function list(db, user) {
    const result = await db.prepare(`
        SELECT ${projections} FROM nfg_community WHERE deleted_at IS NULL AND parent_id IS NULL
        ORDER BY created_at DESC, id DESC LIMIT 40
    `).all();
    const items = result.results || [];
    if (!items.length) return json({ posts: [] });
    const params = items.map(() => '?').join(',');
    const replies = await db.prepare(`
        SELECT ${projections} FROM nfg_community WHERE deleted_at IS NULL AND parent_id IN (${params})
        ORDER BY created_at DESC, id DESC LIMIT 300
    `).bind(...items.map(item => item.id)).all();
    const groups = new Map(items.map(item => [item.id, []]));
    for (const row of replies.results || []) groups.get(row.parent_id)?.unshift(entry(row, user));
    return json({ posts: items.map(row => ({ ...entry(row, user), replies: groups.get(row.id) })) });
}

async function create(request, db, user) {
    if (request.headers.get('origin') !== origin ||
        !request.headers.get('content-type')?.split(';')[0]?.startsWith('application/json')) {
        return json({ error: 'Submit from the NFG community page.' }, 403);
    }
    const size = Number(request.headers.get('content-length') || 0);
    if (size > 16_000) return json({ error: 'This post is too long.' }, 413);
    let data;
    try {
        const text = await request.text();
        if (text.length > 16_000) return json({ error: 'This post is too long.' }, 413);
        data = JSON.parse(text);
    } catch {
        return json({ error: 'Enter a message and try again.' }, 400);
    }
    const body = typeof data?.body === 'string' ? data.body.trim() : '';
    const name = typeof data?.name === 'string' ? data.name.trim().slice(0, 60) : '';
    const link = typeof data?.link === 'string' ? externalLink(data.link.trim()) : '';
    const parent = typeof data?.parentId === 'string' && data.parentId ? data.parentId : null;
    if (!body || body.length > 2000) return json({ error: 'Use 1–2,000 characters for the message.' }, 400);
    if (link === null) return json({ error: 'Use a valid HTTPS project link.' }, 400);
    if (parent && !idPattern.test(parent)) return json({ error: 'This thread could not be found.' }, 404);

    const id = crypto.randomUUID(), now = Date.now(), author = name || 'NFG Member';
    const insert = await db.prepare(`
        INSERT INTO nfg_community (id, owner_id, author, body, link, parent_id, created_at)
        SELECT ?,?,?,?,?,?,?
        WHERE (? IS NULL OR EXISTS (
            SELECT 1 FROM nfg_community WHERE id = ? AND parent_id IS NULL AND deleted_at IS NULL
        )) AND (
            SELECT COUNT(*) FROM nfg_community WHERE owner_id = ? AND created_at > ?
        ) < 8
    `).bind(id, user, author, body, link, parent, now, parent, parent, user, now - 60_000).run();
    if (!insert.meta?.changes) {
        if (parent) {
            const thread = await db.prepare(
                'SELECT 1 FROM nfg_community WHERE id = ? AND parent_id IS NULL AND deleted_at IS NULL',
            ).bind(parent).first();
            if (!thread) return json({ error: 'This thread could not be found.' }, 404);
        }
        return json({ error: 'Please wait a minute before posting again.' }, 429);
    }
    return json({ id, author, body, link, createdAt: new Date(now).toISOString(), canDelete: true }, 201);
}

async function remove(request, db, user, id) {
    if (request.headers.get('origin') !== origin) return json({ error: 'Remove posts from the NFG site.' }, 403);
    if (!idPattern.test(id)) return json({ error: 'This post could not be found.' }, 404);
    const remove = await db.prepare(`
        UPDATE nfg_community SET deleted_at = ?, body = '', link = ''
        WHERE id = ? AND owner_id = ? AND deleted_at IS NULL
    `).bind(Date.now(), id, user).run();
    if (!remove.meta?.changes) return json({ error: 'This post could not be found.' }, 404);
    return new Response(null, { status: 204, headers });
}

export default {
    async fetch(request, env) {
        const url = new URL(request.url);
        if (url.pathname !== endpoint && !url.pathname.startsWith(endpoint + '/')) {
            if (env.ASSETS?.fetch) return env.ASSETS.fetch(request);
            return new Response('NFG site assets are unavailable.', { status: 503 });
        }
        const user = request.headers.get('oai-authenticated-user-id');
        if (!user) return json({ error: 'Sign in to open the NFG community.' }, 401);
        if (!env.DB) return json({ error: 'The community store is unavailable.' }, 503);
        try {
            if (url.pathname === endpoint && request.method === 'GET') return await list(env.DB, user);
            if (url.pathname === endpoint && request.method === 'POST') return await create(request, env.DB, user);
            if (url.pathname.startsWith(endpoint + '/') && request.method === 'DELETE') {
                return await remove(request, env.DB, user, url.pathname.slice(endpoint.length + 1));
            }
            return json({ error: 'This community action is unavailable.' }, 405);
        } catch (error) {
            console.error('Community request failed', error?.name || 'Error');
            return json({ error: 'Community storage is unavailable. Try again shortly.' }, 503);
        }
    },
};
