CREATE TABLE `nfg_community` (
    `id` text PRIMARY KEY NOT NULL,
    `owner_id` text NOT NULL,
    `author` text NOT NULL,
    `body` text NOT NULL,
    `link` text DEFAULT '' NOT NULL,
    `parent_id` text,
    `created_at` integer NOT NULL,
    `deleted_at` integer,
    FOREIGN KEY (`parent_id`) REFERENCES `nfg_community`(`id`) ON DELETE RESTRICT
);
--> statement-breakpoint
CREATE INDEX `nfg_community_parent_recent` ON `nfg_community` (`parent_id`, `deleted_at`, `created_at`);
--> statement-breakpoint
CREATE INDEX `nfg_community_owner_recent` ON `nfg_community` (`owner_id`, `created_at`);
