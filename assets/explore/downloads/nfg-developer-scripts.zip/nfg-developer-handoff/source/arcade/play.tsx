"use client";

import type { CSSProperties } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import { movementAfterStep, playerPosition, runFrame } from "./runner";
import type { PlayerMotion } from "./runner";
import { awardDayPose, poseRewards, savedPoses } from "./pose-rewards";

type Direction = { x: number; y: number };
type Mode = "Gamed" | "Gamer";
type Difficulty = "Easy" | "Hard";
type PlayStyle = "Solo" | "1V1";
type Screen = "menu" | "playing" | "paused" | "won" | "lost";
type Player = {
  x: number;
  y: number;
  dir: Direction;
  next: Direction;
  motion?: PlayerMotion;
  facing?: number;
};

const W = 25,
  H = 25,
  TILE = 34;
const SPRITE_FRAME = 192;
const RUNNER_SIZE = 42;
const COLORS = [
  "#111111",
  "#ef3340",
  "#f58220",
  "#f4d43a",
  "#21b85b",
  "#28a9e8",
  "#7857d8",
  "#ef76b8",
  "#f4f6fa",
];
const DAY_NAMES = [
  "BLACK",
  "RED",
  "ORANGE",
  "YELLOW",
  "GREEN",
  "BLUE",
  "PURPLE",
  "PINK",
  "WHITE",
];
const DAYS = [
  "BLACK · START",
  "RED · REBUILD",
  "ORANGE · GAME",
  "YELLOW · BUSINESS",
  "GREEN · CREATE",
  "BLUE · DISTRIBUTE",
  "PURPLE · COLLECT",
  "PINK · REACH",
  "WHITE · OWN",
];
const ROOM_FILES = COLORS.map(
  (_, i) => `./rooms/nfg-room-${i}-${DAY_NAMES[i].toLowerCase()}-256.png`,
);
const SOUNDTRACK_PATH = "./audio/nfg-perfectly-happy.m4a";
const TRACKS = [
  null,
  SOUNDTRACK_PATH,
  null,
  null,
  null,
  null,
  null,
  null,
  null,
] as const;
const TRACK_TITLES = [
  "Journey",
  "Perfectly Happy",
  "808King",
  "Command Bounce",
  "What U On",
  "Forget U!",
  "We Did It",
  "Dreamer",
  "Modern Bounce",
];
const COIN_LABELS = ["REGISTER", "CREATE", "DISTRIBUTE", "COLLECT"];
const GATEKEEPERS = [
  { name: "THE LABEL", color: "#ef76b8", start: { x: 11, y: 12 } },
  { name: "MANAGEMENT", color: "#ff8c24", start: { x: 12, y: 12 } },
  { name: "DISTRIBUTION", color: "#26b7df", start: { x: 13, y: 12 } },
  { name: "YOUR SELF", color: "#f03b41", start: { x: 12, y: 13 } },
];
const SYLLABUS = [
  [
    "START FROM ZERO",
    "THE RAT RACE",
    "THINKING MORE",
    "UP AT NIGHT",
    "NIGHTMARE / DREAM",
    "WAKE UP MOTIVATED",
    "WALK NEW ROAD",
    "PLAN OF ACTION",
  ],
  [
    "LOOK AT YOU",
    "TARGET",
    "BRAINS",
    "BODY",
    "FOOD",
    "WHAT'S INSIDE",
    "LIGHTS, CAMERA…",
  ],
  [
    "I.T.M. INVESTMENTS",
    "FORMULA 2 SUCCEED",
    "WHAT IS MUSIC BIZ",
    "LABEL STRUCTURE",
    "MEET THE AUTHOR",
    "NFG GATEKEEPERS",
    "COLLABORATE",
  ],
  ["LLC", "BANK", "PROTECTIONS", "ROYALTIES", "INVENTORY", "INVOICES", "AI"],
  [
    "STUDIO LAYOUT",
    "PADS",
    "DAW SHORTCUTS",
    "ENVIRONMENT",
    "MIX MUSIC",
    "RECORD VOCALS",
    "MAKE MUSIC",
  ],
  [
    "MASTERING",
    "ISRC & UPC",
    "SPLIT SHEETS & TM",
    "FOR ARTISTS",
    "SONG STORAGE",
    "UPLOAD 2 DSP & SF",
    "QUALITY CHECK",
  ],
  [
    "MARKETING 101",
    "SOCIAL MEDIA MRK",
    "RADIO & TV MONITOR",
    "LIVE SHOWS & TOURS",
    "STRATEGY & RELEASE",
    "ELEVATOR PITCH",
    "BLOCKCHAIN NFTS",
  ],
  [
    "TOURS",
    "MONTHLY LISTENERS",
    "MEDIAN INCOME",
    "PROGRESS BAR",
    "MAP OF FOLLOWERS",
    "PLAQUES RED CARPET",
    "YOU DID IT!",
  ],
  [
    "LEGACY",
    "GEN. WEALTH",
    "ABUNDANCE",
    "MY PRECIOUS",
    "SCALE UP",
    "TEDTALKS",
    "NEW PROPERTIES",
  ],
].flatMap((titles, day) => titles.map((title) => ({ day, title })));
const ROOMS_PER_DAY = DAY_NAMES.map(
  (_, day) => SYLLABUS.filter((room) => room.day === day).length,
);

const keyOf = (x: number, y: number) => `${x},${y}`;

function isWall(x: number, y: number) {
  if (x < 0 || y < 0 || x >= W || y >= H) return true;
  if (y === 12 && (x === 0 || x === W - 1)) return false;
  if (x === 0 || y === 0 || x === W - 1 || y === H - 1) return true;
  if (x >= 10 && x <= 14 && y >= 10 && y <= 14) {
    const edge = x === 10 || x === 14 || y === 10 || y === 14;
    return edge && !(x === 12 && y === 10);
  }
  const blocks = [
    [2, 2, 4, 3],
    [8, 2, 11, 3],
    [13, 2, 16, 3],
    [20, 2, 22, 3],
    [2, 6, 5, 7],
    [8, 6, 10, 8],
    [14, 6, 16, 8],
    [19, 6, 22, 7],
    [2, 10, 5, 11],
    [19, 10, 22, 11],
    [2, 13, 5, 14],
    [19, 13, 22, 14],
    [2, 17, 4, 19],
    [7, 17, 10, 18],
    [14, 17, 17, 18],
    [20, 17, 22, 19],
    [2, 21, 6, 22],
    [9, 21, 11, 22],
    [13, 21, 15, 22],
    [18, 21, 22, 22],
  ];
  return blocks.some(
    ([x1, y1, x2, y2]) => x >= x1 && x <= x2 && y >= y1 && y <= y2,
  );
}

function knowledgeCells() {
  const cells: { x: number; y: number }[] = [];
  for (let y = 1; y < H - 1; y++)
    for (let x = 1; x < W - 1; x++) {
      const corner = (x === 1 || x === 23) && (y === 1 || y === 23);
      if (
        !isWall(x, y) &&
        !corner &&
        !(x >= 10 && x <= 14 && y >= 10 && y <= 14) &&
        !(x === 12 && y === 19) &&
        !(x === 11 && y === 19)
      )
        cells.push({ x, y });
    }
  return Array.from(
    { length: 64 },
    (_, i) => cells[Math.floor((i * cells.length) / 64)],
  );
}

function makePellets(mode: Mode) {
  const cells = knowledgeCells(),
    pellets = new Map<string, number>();
  if (mode === "Gamer") {
    pellets.set(keyOf(cells[0].x, cells[0].y), 0);
    return pellets;
  }
  const order = Array.from({ length: 64 }, (_, i) => i);
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  cells.forEach((cell, i) => pellets.set(keyOf(cell.x, cell.y), order[i]));
  return pellets;
}

function drawRoom(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  day: number,
  image: HTMLImageElement | undefined,
  pulse = 0,
) {
  const size = 38;
  if (image?.complete && image.naturalWidth) {
    ctx.save();
    if (pulse > 0) {
      const pulseColor = day === 0 ? "#f4f6fa" : COLORS[day];
      ctx.shadowColor = pulseColor;
      ctx.shadowBlur = 12 + pulse * 20;
      ctx.globalAlpha = 0.86 + pulse * 0.14;
      ctx.strokeStyle = pulseColor;
      ctx.lineWidth = 1.5 + pulse * 2;
      ctx.strokeRect(x - size / 2 - 3, y - size / 2 - 3, size + 6, size + 6);
    }
    ctx.drawImage(image, x - size / 2, y - size / 2, size, size);
    ctx.restore();
  }
}
function drawCoin(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  index: number,
  image: HTMLImageElement | null,
) {
  const size = 62;
  if (image?.complete && image.naturalWidth) {
    ctx.save();
    ctx.shadowColor = "#ffd65c";
    ctx.shadowBlur = 13;
    ctx.drawImage(
      image,
      index * 200,
      0,
      200,
      197,
      x - size / 2,
      y - size / 2,
      size,
      (size * 197) / 200,
    );
    ctx.restore();
  }
}
function drawPlayer(
  ctx: CanvasRenderingContext2D,
  player: Player,
  image: HTMLImageElement | null,
  time: number,
  playing: boolean,
  playerTwo = false,
) {
  const motion = playing ? player.motion : undefined;
  const position = playerPosition(player, motion, time, W);
  const facing = player.facing ?? (player.dir.x < 0 ? -1 : 1);
  const frame = runFrame(motion, time);
  const locations =
    position.wrapX === undefined ? [position.x] : [position.x, position.wrapX];

  for (const x of locations) {
    ctx.save();
    ctx.translate(x * TILE + TILE / 2, position.y * TILE + TILE / 2);
    if (playerTwo) {
      ctx.beginPath();
      ctx.arc(0, 0, 17, 0, Math.PI * 2);
      ctx.strokeStyle = "#28a9e8";
      ctx.lineWidth = 3;
      ctx.stroke();
    }
    if (image?.complete && image.naturalWidth) {
      ctx.scale(facing, 1);
      ctx.shadowColor = playerTwo ? "#28a9e8" : "#ffe39b";
      ctx.shadowBlur = 4;
      ctx.drawImage(
        image,
        frame * SPRITE_FRAME,
        0,
        SPRITE_FRAME,
        SPRITE_FRAME,
        -RUNNER_SIZE / 2,
        -RUNNER_SIZE / 2,
        RUNNER_SIZE,
        RUNNER_SIZE,
      );
    }
    ctx.restore();
  }
}
function drawOpponent(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: string,
  vulnerable: boolean,
  label: string,
  image: HTMLImageElement | null,
  index: number,
) {
  const cx = x * TILE + TILE / 2,
    cy = y * TILE + TILE / 2,
    w = 31,
    h = 38;
  ctx.save();
  ctx.translate(cx, cy);
  if (vulnerable) {
    ctx.globalAlpha = 0.72;
    ctx.shadowColor = "#ffd65c";
    ctx.shadowBlur = 15;
  }
  if (image?.complete && image.naturalWidth) {
    const cell = image.naturalWidth / 4;
    ctx.drawImage(
      image,
      index * cell,
      0,
      cell,
      image.naturalHeight,
      -w / 2,
      -h / 2,
      w,
      h,
    );
  } else {
    ctx.fillStyle = vulnerable ? "#5964f2" : color;
    ctx.fillRect(-8, -13, 16, 22);
    ctx.beginPath();
    ctx.arc(0, -14, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#e9eef8";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-5, 8);
    ctx.lineTo(-11, 17);
    ctx.moveTo(5, 8);
    ctx.lineTo(11, 17);
    ctx.stroke();
  }
  ctx.restore();
  ctx.fillStyle = vulnerable ? "#ffd65c" : color;
  ctx.font = "800 6.5px Arial";
  ctx.textAlign = "center";
  ctx.fillText(label, cx, cy + 25);
}

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null),
    gameRef = useRef<any>(null),
    audioRef = useRef<AudioContext | null>(null),
    musicRef = useRef<HTMLAudioElement | null>(null),
    runnerImageRef = useRef<HTMLImageElement | null>(null),
    opponentImageRef = useRef<HTMLImageElement | null>(null),
    roomImagesRef = useRef<HTMLImageElement[]>([]),
    coinImageRef = useRef<HTMLImageElement | null>(null);
  const [screen, setScreen] = useState<Screen>("menu"),
    [mode, setMode] = useState<Mode>("Gamer"),
    [difficulty, setDifficulty] = useState<Difficulty>("Easy"),
    [playStyle, setPlayStyle] = useState<PlayStyle>("Solo");
  const [score, setScore] = useState(0),
    [high, setHigh] = useState(0),
    [lives, setLives] = useState(3),
    [learned, setLearned] = useState(0),
    [collection, setCollection] = useState<number[]>(Array(9).fill(0)),
    [versus, setVersus] = useState<[number, number]>([0, 0]);
  const [lesson, setLesson] = useState("Choose a game in NFG Game Center."),
    [sound, setSound] = useState(true),
    [skinDay, setSkinDay] = useState(2),
    [liked, setLiked] = useState(false),
    [skinsOpen, setSkinsOpen] = useState(false),
    [soundtrackOpen, setSoundtrackOpen] = useState(false),
    [musicPlaying, setMusicPlaying] = useState(false),
    [powerTicks, setPowerTicks] = useState(0),
    [guide, setGuide] = useState("");
  const skin = COLORS[skinDay];
  const galleryRef = useRef<HTMLDialogElement>(null);
  const [unlockedPoses, setUnlockedPoses] = useState(savedPoses);
  const poseProgress = useRef(unlockedPoses);
  const [unlockMessage, setUnlockMessage] = useState("");

  const unlockPose = useCallback((day: number, count: number) => {
    const next = awardDayPose(
      poseProgress.current,
      day,
      count,
      ROOMS_PER_DAY[day],
    );
    if (!next) return;
    poseProgress.current = next;
    setUnlockedPoses(next);
    setUnlockMessage(
      `Day ${day} complete. ${poseRewards[day].title} unlocked.`,
    );
  }, []);

  function openPoseGallery() {
    if (screen === "playing") setScreen("paused");
    galleryRef.current?.showModal();
  }

  useEffect(() => {
    setHigh(Number(localStorage.getItem("nfg-gatekeepers-high") || 0));
    setLiked(localStorage.getItem("nfg-gatekeepers-liked") === "1");
    const runner = new Image();
    runner.src = "./notes-run.webp";
    runnerImageRef.current = runner;
    const opponents = new Image();
    opponents.src = "./nfg-suited-gatekeepers.png";
    opponentImageRef.current = opponents;
    roomImagesRef.current = ROOM_FILES.map((src) => {
      const room = new Image();
      room.src = src;
      return room;
    });
    const coins = new Image();
    coins.src = "./nfg-goat-coins.gif";
    coinImageRef.current = coins;
  }, []);

  const tone = useCallback(
    (freq: number, duration = 0.06, type: OscillatorType = "square") => {
      if (!sound) return;
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      if (!AC) return;
      const ac = audioRef.current || new AC();
      audioRef.current = ac;
      const o = ac.createOscillator(),
        g = ac.createGain();
      o.type = type;
      o.frequency.value = freq;
      g.gain.setValueAtTime(0.04, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + duration);
      o.connect(g);
      g.connect(ac.destination);
      o.start();
      o.stop(ac.currentTime + duration);
    },
    [sound],
  );

  useEffect(() => {
    const audio = musicRef.current || new Audio();
    musicRef.current = audio;
    const day = mode === "Gamed" ? 2 : skinDay,
      src = TRACKS[day] || TRACKS[1];
    if (src && audio.src !== new URL(src, document.baseURI).href) {
      audio.src = src;
      audio.loop = true;
      audio.volume = 0.42;
    }
    if (screen === "playing" && sound)
      audio
        .play()
        .then(() => setMusicPlaying(true))
        .catch(() => setMusicPlaying(false));
    else {
      audio.pause();
      setMusicPlaying(false);
    }
  }, [mode, screen, skinDay, sound]);

  const logTrackEvent = (event: "play" | "download", day: number) => {
    const key = "nfg-soundtrack-events",
      events = JSON.parse(localStorage.getItem(key) || "[]") as object[];
    events.push({
      event,
      day,
      title: TRACK_TITLES[day],
      at: new Date().toISOString(),
    });
    localStorage.setItem(key, JSON.stringify(events.slice(-500)));
  };
  const playSoundtrack = async () => {
    const audio = musicRef.current || new Audio(),
      src = TRACKS[1];
    musicRef.current = audio;
    if (!src) return;
    if (audio.src !== new URL(src, document.baseURI).href) audio.src = src;
    audio.loop = true;
    audio.volume = 0.48;
    setSound(true);
    if (audio.paused) {
      await audio
        .play()
        .then(() => {
          setMusicPlaying(true);
          logTrackEvent("play", 1);
        })
        .catch(() => setMusicPlaying(false));
    } else {
      audio.pause();
      setMusicPlaying(false);
    }
  };
  const recordDownload = () => logTrackEvent("download", 1);

  const startGame = useCallback(() => {
    const pellets = makePellets(mode),
      powers = new Map([
        [keyOf(1, 1), 0],
        [keyOf(23, 1), 1],
        [keyOf(1, 23), 2],
        [keyOf(23, 23), 3],
      ]),
      players: Player[] = [
        { x: 12, y: 19, dir: { x: 0, y: 1 }, next: { x: 0, y: 1 } },
      ];
    if (playStyle === "1V1")
      players.push({
        x: 11,
        y: 19,
        dir: { x: -1, y: 0 },
        next: { x: -1, y: 0 },
      });
    gameRef.current = {
      mode,
      difficulty,
      playStyle,
      players,
      ghosts: GATEKEEPERS.map((gatekeeper, i) => ({
        ...gatekeeper.start,
        dir: { x: i % 2 ? 1 : -1, y: 0 },
        home: gatekeeper.start,
        release: (mode === "Gamer" ? 22 : 10) + i * 12,
      })),
      pellets,
      powers,
      poweredUntil: 0,
      tick: 0,
      score: 0,
      lives: 3,
      learned: 0,
      collection: Array(9).fill(0),
      versus: [0, 0],
    };
    setScore(0);
    setLives(3);
    setLearned(0);
    setCollection(Array(9).fill(0));
    setVersus([0, 0]);
    setPowerTicks(0);
    setGuide("");
    setUnlockMessage("");
    setSkinDay(mode === "Gamer" ? 0 : 2);
    setLesson(
      mode === "Gamer"
        ? `GAMER · INDIE · ${difficulty.toUpperCase()} · 1/64 · START FROM ZERO`
        : "GAMED · LABELS · 64 ROOMS RANDOMIZED",
    );
    setScreen("playing");
    canvasRef.current?.focus({ preventScroll: true });
    tone(440, 0.12);
  }, [mode, difficulty, playStyle, tone]);

  const turnPlayer = useCallback(
    (index: number, x: number, y: number) => {
      if (screen === "menu" || screen === "won" || screen === "lost") {
        startGame();
        return;
      }
      if (screen === "paused") {
        setScreen("playing");
        return;
      }
      const player = gameRef.current?.players?.[index];
      if (player) player.next = { x, y };
    },
    [screen, startGame],
  );
  const togglePause = useCallback(
    () =>
      setScreen((value) =>
        value === "playing" ? "paused" : value === "paused" ? "playing" : value,
      ),
    [],
  );

  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      const target = event.target;
      if (
        event.defaultPrevented ||
        (target instanceof HTMLElement &&
          (target.isContentEditable ||
            target.matches("input, textarea, select")))
      )
        return;
      if (skinsOpen || soundtrackOpen || galleryRef.current?.open) return;
      const arrows: Record<string, Direction> = {
          ArrowUp: { x: 0, y: -1 },
          ArrowDown: { x: 0, y: 1 },
          ArrowLeft: { x: -1, y: 0 },
          ArrowRight: { x: 1, y: 0 },
        },
        wasd: Record<string, Direction> = {
          w: { x: 0, y: -1 },
          s: { x: 0, y: 1 },
          a: { x: -1, y: 0 },
          d: { x: 1, y: 0 },
        },
        key = event.key.toLowerCase();
      if (arrows[event.key]) {
        event.preventDefault();
        turnPlayer(0, arrows[event.key].x, arrows[event.key].y);
      } else if (wasd[key]) {
        event.preventDefault();
        const index = playStyle === "1V1" ? 1 : 0;
        turnPlayer(index, wasd[key].x, wasd[key].y);
      }
      if (event.key === " " || key === "p") {
        event.preventDefault();
        togglePause();
      }
    };
    window.addEventListener("keydown", down);
    return () => window.removeEventListener("keydown", down);
  }, [playStyle, skinsOpen, soundtrackOpen, togglePause, turnPlayer]);

  useEffect(() => {
    const delay = mode === "Gamer" && skinDay === 0 ? 440 : 340;
    const timer = setInterval(() => {
      const game = gameRef.current;
      if (!game || screen !== "playing") return;
      game.tick++;
      const move = (player: Player) => {
        const can = (direction: Direction) => {
          if (player.y === 12 && player.x === 0 && direction.x === -1)
            return true;
          if (player.y === 12 && player.x === W - 1 && direction.x === 1)
            return true;
          return !isWall(player.x + direction.x, player.y + direction.y);
        };
        if (can(player.next)) player.dir = player.next;
        if (player.y === 12 && player.x === 0 && player.dir.x === -1)
          player.x = W - 1;
        else if (player.y === 12 && player.x === W - 1 && player.dir.x === 1)
          player.x = 0;
        else if (can(player.dir)) {
          player.x += player.dir.x;
          player.y += player.dir.y;
        }
      };
      const stepStarted = performance.now();
      game.players.forEach((player: Player) => {
        const previous = { x: player.x, y: player.y };
        move(player);
        player.motion = movementAfterStep(
          previous,
          player,
          player.dir.x,
          stepStarted,
          delay,
          W,
        );
        if (player.dir.x) player.facing = player.dir.x;
      });
      game.players.forEach((player: Player, playerIndex: number) => {
        const here = keyOf(player.x, player.y);
        if (game.pellets.has(here)) {
          const lessonIndex = game.pellets.get(here) as number,
            item = SYLLABUS[lessonIndex];
          game.pellets.delete(here);
          game.score += 100;
          game.learned++;
          game.collection[item.day]++;
          unlockPose(item.day, game.collection[item.day]);
          game.versus[playerIndex]++;
          setScore(game.score);
          setLearned(game.learned);
          setCollection([...game.collection]);
          setVersus([...game.versus] as [number, number]);
          if (game.mode === "Gamer" && lessonIndex + 1 < SYLLABUS.length) {
            const nextIndex = lessonIndex + 1,
              next = knowledgeCells()[nextIndex],
              nextDay = SYLLABUS[nextIndex].day;
            game.pellets.set(keyOf(next.x, next.y), nextIndex);
            setSkinDay(nextDay);
            setLesson(
              `#${lessonIndex + 1} ${item.title} · NEXT: #${nextIndex + 1} ${SYLLABUS[nextIndex].title}`,
            );
          } else
            setLesson(`${DAYS[item.day]} · ${item.title} · ${game.learned}/64`);
          if (game.learned % 8 === 0 && game.learned < 64) {
            game.poweredUntil = Math.max(game.poweredUntil, game.tick + 52);
            setLesson(
              `NFG HAMMER SURGE · KNOWLEDGE CHANGES THE CLIMATE · ${game.learned}/64`,
            );
            tone(1040, 0.3, "sawtooth");
          } else tone(660 + item.day * 35, 0.13);
        }
        if (game.powers.has(here)) {
          const coin = game.powers.get(here) as number;
          game.powers.delete(here);
          game.poweredUntil = game.tick + 76;
          game.score += 100;
          setScore(game.score);
          setLesson(`${COIN_LABELS[coin]} POWER EVENT · THE PLAN IS ACTIVE`);
          tone(880, 0.32, "sawtooth");
        }
      });
      const powered = game.tick < game.poweredUntil,
        directions = [
          { x: 1, y: 0 },
          { x: -1, y: 0 },
          { x: 0, y: 1 },
          { x: 0, y: -1 },
        ];
      setPowerTicks(Math.max(0, game.poweredUntil - game.tick));
      if (
        game.mode === "Gamer" &&
        game.difficulty === "Easy" &&
        game.pellets.size
      ) {
        const first = [...game.pellets.keys()][0].split(",").map(Number),
          player = game.players[0],
          dx = first[0] - player.x,
          dy = first[1] - player.y;
        setGuide(
          Math.abs(dx) > Math.abs(dy)
            ? dx < 0
              ? "← LEFT"
              : "RIGHT →"
            : dy < 0
              ? "↑ UP"
              : "DOWN ↓",
        );
      } else setGuide("");
      game.ghosts.forEach((ghost: any) => {
        if (ghost.retreatUntil && game.tick < ghost.retreatUntil) return;
        if (ghost.retreatUntil && game.tick >= ghost.retreatUntil) {
          ghost.retreatUntil = 0;
          ghost.x = ghost.home.x;
          ghost.y = ghost.home.y;
          ghost.release = game.tick + 18;
        }
        const ghostStep = skinDay === 0 ? 3 : 2;
        if (game.tick < ghost.release || game.tick % ghostStep !== 0) return;
        const target = [...game.players].sort(
            (a: Player, b: Player) =>
              Math.abs(ghost.x - a.x) +
              Math.abs(ghost.y - a.y) -
              Math.abs(ghost.x - b.x) -
              Math.abs(ghost.y - b.y),
          )[0],
          valid = directions.filter(
            (direction) =>
              !isWall(ghost.x + direction.x, ghost.y + direction.y),
          ),
          choices = valid.filter(
            (direction) =>
              !(direction.x === -ghost.dir.x && direction.y === -ghost.dir.y),
          ),
          ranked = (choices.length ? choices : valid).sort((a, b) => {
            const da =
                Math.abs(ghost.x + a.x - target.x) +
                Math.abs(ghost.y + a.y - target.y),
              db =
                Math.abs(ghost.x + b.x - target.x) +
                Math.abs(ghost.y + b.y - target.y);
            return powered ? db - da : da - db;
          });
        ghost.dir =
          Math.random() < 0.18
            ? ranked[Math.floor(Math.random() * ranked.length)]
            : ranked[0];
        if (ghost.dir) {
          ghost.x += ghost.dir.x;
          ghost.y += ghost.dir.y;
        }
        game.players.forEach((player: Player) => {
          if (ghost.x !== player.x || ghost.y !== player.y) return;
          if (powered) {
            game.score += 300;
            setScore(game.score);
            ghost.retreatUntil = game.tick + 26;
            tone(1080, 0.2);
            setLesson(`${ghost.name} RETREATS · YOUR STRUCTURED PLAN HOLDS`);
          } else {
            game.lives--;
            setLives(game.lives);
            tone(110, 0.35, "sawtooth");
            if (game.lives <= 0) {
              setScreen("lost");
              setLesson(
                "Opposition disrupted the path. Return with a stronger plan.",
              );
            } else {
              player.x = 12;
              player.y = 19;
              player.motion = undefined;
              ghost.x = ghost.home.x;
              ghost.y = ghost.home.y;
            }
          }
        });
      });
      if (game.pellets.size === 0) {
        setScreen("won");
        const winner =
          game.playStyle === "1V1"
            ? game.versus[0] === game.versus[1]
              ? "1V1 TIE"
              : game.versus[0] > game.versus[1]
                ? "PLAYER 1 WINS"
                : "PLAYER 2 WINS"
            : "YOU EARNED THE HOUSE";
        setLesson(`64/64 · ${winner} · TROPHY ROOM UNLOCKED`);
        tone(1320, 0.8, "sine");
      }
      if (
        game.score > Number(localStorage.getItem("nfg-gatekeepers-high") || 0)
      ) {
        localStorage.setItem("nfg-gatekeepers-high", String(game.score));
        setHigh(game.score);
      }
    }, delay);
    return () => clearInterval(timer);
  }, [mode, screen, skinDay, tone, unlockPose]);

  useEffect(() => {
    let frame = 0;
    const draw = (time: number) => {
      const canvas = canvasRef.current,
        game = gameRef.current;
      if (!canvas) {
        frame = requestAnimationFrame(draw);
        return;
      }
      const ctx = canvas.getContext("2d")!,
        dpr = Math.min(devicePixelRatio, 2);
      if (canvas.width !== W * TILE * dpr) {
        canvas.width = W * TILE * dpr;
        canvas.height = H * TILE * dpr;
        ctx.scale(dpr, dpr);
      }
      const board = "#020307",
        wallColor = "#2737ff";
      ctx.clearRect(0, 0, W * TILE, H * TILE);
      ctx.fillStyle = board;
      ctx.fillRect(0, 0, W * TILE, H * TILE);
      for (let y = 0; y < H; y++)
        for (let x = 0; x < W; x++)
          if (isWall(x, y)) {
            ctx.fillStyle = "#050817";
            ctx.strokeStyle = wallColor;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.roundRect(x * TILE + 3, y * TILE + 3, TILE - 6, TILE - 6, 5);
            ctx.fill();
            ctx.stroke();
          }
      [0, W - 1].forEach((x) => {
        const cx = x * TILE + TILE / 2,
          cy = 12 * TILE + TILE / 2;
        ctx.strokeStyle = wallColor;
        ctx.lineWidth = 5;
        ctx.shadowColor = wallColor;
        ctx.shadowBlur = 14;
        ctx.beginPath();
        ctx.arc(cx, cy, 14, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      });
      ctx.fillStyle = wallColor;
      ctx.font = "900 8px Arial";
      ctx.textAlign = "center";
      ctx.fillText("LOOPHOLE", 12.5 * TILE, 9.7 * TILE);
      if (game) {
        const powered = game.tick < game.poweredUntil;
        if (powered) {
          ctx.fillStyle = `rgba(255,180,40,${0.05 + 0.04 * Math.sin(Date.now() / 110)})`;
          ctx.fillRect(0, 0, W * TILE, H * TILE);
          ctx.strokeStyle = "#ffd65c";
          ctx.lineWidth = 6;
          ctx.strokeRect(5, 5, W * TILE - 10, H * TILE - 10);
        }
        game.pellets.forEach((lessonIndex: number, key: string) => {
          const [x, y] = key.split(",").map(Number),
            day = SYLLABUS[lessonIndex].day,
            pulse =
              game.mode === "Gamer" && game.difficulty === "Easy"
                ? (1 + Math.sin(Date.now() / 170)) / 2
                : 0;
          drawRoom(
            ctx,
            x * TILE + TILE / 2,
            y * TILE + TILE / 2,
            day,
            roomImagesRef.current[day],
            pulse,
          );
        });
        game.powers.forEach((coinIndex: number, key: string) => {
          const [x, y] = key.split(",").map(Number);
          drawCoin(
            ctx,
            x * TILE + TILE / 2,
            y * TILE + TILE / 2,
            coinIndex,
            coinImageRef.current,
          );
        });
        game.ghosts.forEach((ghost: any, i: number) => {
          if (!ghost.retreatUntil || game.tick >= ghost.retreatUntil)
            drawOpponent(
              ctx,
              ghost.x,
              ghost.y,
              GATEKEEPERS[i].color,
              powered,
              GATEKEEPERS[i].name,
              opponentImageRef.current,
              i,
            );
        });
        game.players.forEach((player: Player, i: number) =>
          drawPlayer(
            ctx,
            player,
            runnerImageRef.current,
            time,
            screen === "playing",
            i === 1,
          ),
        );
      } else {
        drawPlayer(
          ctx,
          { x: 12, y: 19, dir: { x: 1, y: 0 }, next: { x: 1, y: 0 } },
          runnerImageRef.current,
          time,
          false,
        );
        GATEKEEPERS.forEach((ghost, i) =>
          drawOpponent(
            ctx,
            ghost.start.x,
            ghost.start.y,
            ghost.color,
            false,
            ghost.name,
            opponentImageRef.current,
            i,
          ),
        );
      }
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, [skin, mode, screen]);

  const shareGame = async () => {
    const data = {
      title: "NFG Gatekeepers",
      text: "Play NFG Gatekeepers: learn the board and outlearn the gatekeepers.",
      url: window.location.href,
    };
    if (navigator.share) await navigator.share(data).catch(() => undefined);
    else
      await navigator.clipboard
        .writeText(window.location.href)
        .catch(() => undefined);
  };
  const toggleLike = () => {
    const next = !liked;
    setLiked(next);
    localStorage.setItem("nfg-gatekeepers-liked", next ? "1" : "0");
  };
  const resetToGameCenter = () => {
    gameRef.current = null;
    setScreen("menu");
    setScore(0);
    setLives(3);
    setLearned(0);
    setCollection(Array(9).fill(0));
    setVersus([0, 0]);
    setPowerTicks(0);
    setGuide("");
    setUnlockMessage("");
    setSkinDay(2);
    setLesson("Choose a game in NFG Game Center.");
  };

  return (
    <main className="game-shell" style={{ "--skin": skin } as CSSProperties}>
      <header className="topbar">
        <div>
          <span className="eyebrow">NOTES FOR GOATS · THE CLASSIC REBORN</span>
          <h1>
            NFG <em>GATEKEEPERS</em>
          </h1>
        </div>
        <div className="top-actions">
          <button className="menu-main" onClick={resetToGameCenter}>
            ⌂ MAIN MENU
          </button>
          <button className="pause-main" onClick={togglePause}>
            {screen === "paused" ? "▶ RESUME" : "Ⅱ PAUSE"}
          </button>
          <button className="sound" onClick={() => setSoundtrackOpen(true)}>
            ♫ SOUNDTRACK
          </button>
          <button
            className="pose-gallery-toggle"
            aria-haspopup="dialog"
            onClick={openPoseGallery}
          >
            Pose collection{" "}
            <span>
              {unlockedPoses.length}/{poseRewards.length}
            </span>
          </button>
        </div>
      </header>
      <nav className="commerce-dock" aria-label="NFG actions">
        <a
          className="buy-class"
          href="mailto:mrdeyomusic@gmail.com?subject=Purchase%20Full%20Notes%20For%20GOATS%20Course"
        >
          BUY FULL NFG COURSE
        </a>
        <button
          className="buy-soundtrack"
          onClick={() => setSoundtrackOpen(true)}
        >
          GET THE SOUNDTRACK
        </button>
        <button onClick={() => setSkinsOpen(true)}>🎨 SKINS STORE</button>
        <button onClick={toggleLike}>{liked ? "♥ LIKED" : "♡ LIKE"}</button>
        <button onClick={shareGame}>↗ SHARE</button>
        <a href="mailto:mrdeyomusic@gmail.com?subject=Subscribe%20to%20NFG">
          ＋ SUBSCRIBE
        </a>
      </nav>
      <section className="scoreboard" aria-live="polite">
        <div>
          <small>GAME</small>
          <strong>{playStyle}</strong>
        </div>
        <div>
          <small>KNOWLEDGE</small>
          <strong>{String(score).padStart(5, "0")}</strong>
        </div>
        <div>
          <small>HIGH SCORE</small>
          <strong>{String(high).padStart(5, "0")}</strong>
        </div>
        <div>
          <small>ROOMS LEARNED</small>
          <strong>{learned}/64</strong>
        </div>
        <div className={`hammer-meter ${powerTicks > 0 ? "active" : ""}`}>
          <small>NFG HAMMER</small>
          <strong>
            {powerTicks > 0 ? `⚡ ACTIVE ${powerTicks}` : `🔨 ${learned}/64`}
          </strong>
        </div>
        <div>
          <small>LIVES</small>
          <strong className="lives">{"●".repeat(lives)}</strong>
        </div>
      </section>
      {playStyle === "1V1" && (
        <section className="versus-strip">
          <b>PLAYER 1 · ARROWS</b>
          <strong>
            {versus[0]} — {versus[1]}
          </strong>
          <b>WASD · PLAYER 2</b>
        </section>
      )}
      <section className="collection-tray" aria-label="Rooms collected">
        <div className="collection-title">
          <small>YOU ARE WHAT YOU EAT</small>
          <strong>ROOM COLLECTION</strong>
        </div>
        {DAYS.map((day, i) => (
          <div
            className={`collection-item ${collection[i] > 0 ? "collected" : ""}`}
            key={day}
          >
            <span className="room-swatch">
              <img src={ROOM_FILES[i]} alt={`${DAY_NAMES[i]} room`} />
              {collection[i] > 0 && <i>✓</i>}
            </span>
            <b>{DAY_NAMES[i]}</b>
            <strong>{collection[i]}</strong>
          </div>
        ))}
      </section>
      <p className="pose-unlock-status" role="status">
        {unlockMessage}
      </p>
      <section className={`stage ${mode === "Gamed" ? "gamed" : "gamer"}`}>
        <div className="lesson">
          <div>
            <span>NOW LEARNING</span>
            <b>{lesson}</b>
          </div>
          <div className="lesson-tools">
            {mode === "Gamer" && (
              <div className="difficulty-switch" aria-label="Difficulty">
                <button
                  className={difficulty === "Easy" ? "selected" : ""}
                  onClick={() => setDifficulty("Easy")}
                >
                  EASY
                </button>
                <button
                  className={difficulty === "Hard" ? "selected" : ""}
                  onClick={() => setDifficulty("Hard")}
                >
                  HARD
                </button>
              </div>
            )}
            {guide && (
              <strong className="guide-arrow">NEXT ROOM {guide}</strong>
            )}
          </div>
        </div>
        {powerTicks > 0 && (
          <div className="power-alert">
            ⚡ NFG HAMMER POWER EVENT · THE STRUCTURED PLAN IS ACTIVE
          </div>
        )}
        <div className="canvas-wrap">
          <canvas
            ref={canvasRef}
            tabIndex={0}
            aria-label="NFG Gatekeepers maze. Use arrow keys or W A S D to move."
          />
        </div>
        {screen !== "playing" && (
          <div className="overlay">
            <span className="day-chip">THE CLASSIC REBORN · ORANGE DAY</span>
            <h2>
              {screen === "won"
                ? "YOU EARNED THE HOUSE"
                : screen === "lost"
                  ? "THE PATH WAS DISRUPTED"
                  : screen === "paused"
                    ? "PAUSED"
                    : "GAMED OR GAMER?"}
            </h2>
            {screen === "menu" ? (
              <div className="game-center">
                <div className="game-options">
                  <button
                    className={mode === "Gamed" ? "selected" : ""}
                    onClick={() => setMode("Gamed")}
                  >
                    <b>GAMED</b>
                    <small>LABELS</small>
                    <span>
                      Opposition reinforces an unstructured climate while the 64
                      rooms arrive in randomized order.
                    </span>
                  </button>
                  <button
                    className={mode === "Gamer" ? "selected" : ""}
                    onClick={() => setMode("Gamer")}
                  >
                    <b>GAMER</b>
                    <small>INDIE</small>
                    <span>
                      You bring the plan: all 64 rooms follow the complete NFG
                      course structure.
                    </span>
                  </button>
                </div>
                {mode === "Gamer" && (
                  <div
                    className="difficulty-options"
                    aria-label="Gamer difficulty"
                  >
                    <button
                      className={difficulty === "Easy" ? "selected" : ""}
                      onClick={() => setDifficulty("Easy")}
                    >
                      <b>EASY</b>
                      <span>Room pulse plus a direction arrow.</span>
                    </button>
                    <button
                      className={difficulty === "Hard" ? "selected" : ""}
                      onClick={() => setDifficulty("Hard")}
                    >
                      <b>HARD</b>
                      <span>No pulse or arrow. Know the path.</span>
                    </button>
                  </div>
                )}
                <div className="play-options">
                  <button
                    className={playStyle === "Solo" ? "selected" : ""}
                    onClick={() => setPlayStyle("Solo")}
                  >
                    1 PLAYER
                  </button>
                  <button
                    className={playStyle === "1V1" ? "selected" : ""}
                    onClick={() => setPlayStyle("1V1")}
                  >
                    LOCAL 1V1
                  </button>
                </div>
                <p>
                  Notes runs through the maze to collect lesson rooms. The
                  suited runners benefit from and reinforce the climate; they
                  did not create it.
                </p>
              </div>
            ) : (
              <p>
                {screen === "won"
                  ? "All 64 rooms are learned. The Trophy Room and house are yours."
                  : screen === "lost"
                    ? "Return with a stronger structured plan."
                    : "Your progress is safe."}
              </p>
            )}
            <div className="overlay-actions">
              <button
                className="start"
                onClick={
                  screen === "paused" ? () => setScreen("playing") : startGame
                }
              >
                {screen === "paused"
                  ? "RESUME"
                  : screen === "menu"
                    ? "START GAME"
                    : "PLAY AGAIN"}
              </button>
              {screen !== "menu" && (
                <button className="return-menu" onClick={resetToGameCenter}>
                  ⌂ MAIN MENU
                </button>
              )}
            </div>
          </div>
        )}
      </section>
      <section className="controls">
        <div className="instructions">
          <b>MOVE</b>
          <span>
            {playStyle === "1V1"
              ? "Player 1: Arrows · Player 2: W A S D"
              : "Arrow keys · W A S D · Touch controls"}
          </span>
          <button onClick={togglePause}>
            {screen === "paused" ? "RESUME" : "PAUSE"}
          </button>
        </div>
        <div className="dpad">
          <button
            type="button"
            aria-label="Move up"
            onClick={() => turnPlayer(0, 0, -1)}
          >
            ▲
          </button>
          <button
            type="button"
            aria-label="Move left"
            onClick={() => turnPlayer(0, -1, 0)}
          >
            ◀
          </button>
          <button
            type="button"
            aria-label="Move down"
            onClick={() => turnPlayer(0, 0, 1)}
          >
            ▼
          </button>
          <button
            type="button"
            aria-label="Move right"
            onClick={() => turnPlayer(0, 1, 0)}
          >
            ▶
          </button>
        </div>
      </section>
      {soundtrackOpen && (
        <div
          className="skin-modal"
          role="dialog"
          aria-modal="true"
          aria-label="NFG Soundtrack"
        >
          <div className="skin-panel soundtrack-panel">
            <button
              className="close-skins"
              onClick={() => setSoundtrackOpen(false)}
            >
              ×
            </button>
            <span className="eyebrow">NFG SOUNDTRACK · 9-DAY JOURNEY</span>
            <h2>STREAM IT. OWN IT.</h2>
            <p>
              The soundtrack travels with the course. The first mastered file
              currently available here is <b>Perfectly Happy</b>; the remaining
              day masters are queued for import.
            </p>
            <div className="soundtrack-feature">
              <div>
                <small>DAY 1 · RED</small>
                <strong>PERFECTLY HAPPY</strong>
                <span>DEYO · NFG SOUNDTRACK</span>
              </div>
              <button onClick={playSoundtrack}>
                {musicPlaying ? "Ⅱ PAUSE" : "▶ PLAY"}
              </button>
              <a
                href={SOUNDTRACK_PATH}
                download="DEYO - Perfectly Happy.m4a"
                onClick={recordDownload}
              >
                ⇩ DOWNLOAD
              </a>
              <button disabled title="Spotify release link will be added here">
                SPOTIFY · COMING
              </button>
            </div>
            <div className="track-list">
              {TRACK_TITLES.map((title, i) => (
                <div
                  key={title}
                  className={TRACKS[i] ? "available" : "pending"}
                >
                  <span>{i}</span>
                  <b>
                    {DAY_NAMES[i]} · {title}
                  </b>
                  <small>
                    {TRACKS[i] ? "DOWNLOAD READY" : "MASTER TO IMPORT"}
                  </small>
                </div>
              ))}
            </div>
            <section className="purple-release">
              <span>PURPLE DAY · RELEASE TRACKER</span>
              <h3>EVERY SONG FOLLOWS THE COURSE</h3>
              <div>
                <b>01</b> Final master + ownership record
              </div>
              <div>
                <b>02</b> ISRC, UPC, credits and split sheet
              </div>
              <div>
                <b>03</b> Distributor delivery + Spotify link
              </div>
              <div>
                <b>04</b> Luminate registration for RIAA eligibility
              </div>
              <div>
                <b>05</b> Blog list, pitch log and coverage links
              </div>
              <p>
                Game plays and downloads are logged on this device for
                discovery. Official chart and certification reporting must flow
                through registered release partners and identifiers.
              </p>
            </section>
            <a
              className="soundtrack-buy"
              href="mailto:mrdeyomusic@gmail.com?subject=Purchase%20NFG%20Soundtrack"
            >
              BUY / GIFT THE FULL SOUNDTRACK
            </a>
          </div>
        </div>
      )}
      {skinsOpen && (
        <div
          className="skin-modal"
          role="dialog"
          aria-modal="true"
          aria-label="NFG Skins Store"
        >
          <div className="skin-panel">
            <button className="close-skins" onClick={() => setSkinsOpen(false)}>
              ×
            </button>
            <span className="eyebrow">NFG GAME CENTER</span>
            <h2>SKINS STORE</h2>
            <p>
              Choose a color skin for NFG games. GAMER still changes naturally
              with each syllabus day.
            </p>
            <div className="skin-grid">
              {DAY_NAMES.map((name, i) => (
                <a
                  key={name}
                  href={`mailto:mrdeyomusic@gmail.com?subject=Purchase%20NFG%20${name}%20Game%20Skin`}
                  style={{ "--card": COLORS[i] } as CSSProperties}
                >
                  <span />
                  <b>{name}</b>
                  <small>$1.99</small>
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
      <dialog
        ref={galleryRef}
        className="pose-gallery"
        aria-labelledby="pose-gallery-title"
      >
        <header className="pose-gallery-header">
          <div>
            <h2 id="pose-gallery-title">Pose collection</h2>
            <p>Collect every room from a day in one run to unlock its pose.</p>
          </div>
          <button type="button" onClick={() => galleryRef.current?.close()}>
            Close
          </button>
        </header>
        <div className="pose-gallery-grid">
          {poseRewards.map((reward, day) => {
            const unlocked = unlockedPoses.includes(day);
            return (
              <article
                className={unlocked ? "pose-reward unlocked" : "pose-reward"}
                key={reward.image}
                style={{ "--pose-day": COLORS[day] } as CSSProperties}
              >
                <div className="pose-reward-image">
                  {unlocked ? (
                    <img
                      src={`./poses/${reward.image}`}
                      alt={`Notes in the ${reward.title} pose`}
                      loading="lazy"
                    />
                  ) : (
                    <span>Locked</span>
                  )}
                </div>
                <div className="pose-reward-text">
                  <strong>
                    Day {day} · {reward.day}
                  </strong>
                  <span>
                    {unlocked
                      ? reward.title
                      : `${ROOMS_PER_DAY[day]} ${DAY_NAMES[day].toLowerCase()} rooms`}
                  </span>
                </div>
              </article>
            );
          })}
        </div>
      </dialog>
      <footer>
        <span>BLACK: SPACES</span>
        <b>ORANGE: THE CLASSIC REBORN · GAMED / GAMER</b>
        <span>WHITE: HELPING SANTA</span>
      </footer>
    </main>
  );
}
