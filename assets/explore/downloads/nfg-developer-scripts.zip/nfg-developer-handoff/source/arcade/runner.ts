type Point = { x: number; y: number };

export type PlayerMotion = {
  from: Point;
  to: Point;
  startedAt: number;
  duration: number;
  wrapOffset?: number;
};

const RUN_FRAMES = [0, 1, 2, 1];
const FRAME_MILLISECONDS = 95;

export function movementAfterStep(
  from: Point,
  destination: Point,
  horizontalDirection: number,
  startedAt: number,
  duration: number,
  mazeWidth: number,
): PlayerMotion | undefined {
  const to = { x: destination.x, y: destination.y };
  if (from.x === to.x && from.y === to.y) return;

  if (from.y === to.y && Math.abs(to.x - from.x) === mazeWidth - 1) {
    to.x = from.x + horizontalDirection;
    return {
      from,
      to,
      startedAt,
      duration,
      wrapOffset: -horizontalDirection * mazeWidth,
    };
  }
  return { from, to, startedAt, duration };
}

export function playerPosition(
  tile: Point,
  motion: PlayerMotion | undefined,
  time: number,
  mazeWidth: number,
): Point & { wrapX?: number } {
  if (!motion) return tile;
  const amount = Math.min(
    1,
    Math.max(0, (time - motion.startedAt) / motion.duration),
  );
  const x = motion.from.x + (motion.to.x - motion.from.x) * amount;
  const y = motion.from.y + (motion.to.y - motion.from.y) * amount;
  if (!motion.wrapOffset || x < -1 || x > mazeWidth) return { x, y };
  return { x, y, wrapX: x + motion.wrapOffset };
}

export function runFrame(
  motion: PlayerMotion | undefined,
  time: number,
): number {
  if (!motion || time >= motion.startedAt + motion.duration) return 0;
  return RUN_FRAMES[Math.floor(time / FRAME_MILLISECONDS) % RUN_FRAMES.length];
}
