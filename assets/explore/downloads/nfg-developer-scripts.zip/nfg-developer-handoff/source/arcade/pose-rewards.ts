const POSE_STORAGE = "nfg-gatekeepers-poses-v1";

export const poseRewards = [
  { title: "The Thinker", day: "The Mindset", image: "day-0.webp" },
  { title: "Flex", day: "Self Development", image: "day-1.webp" },
  { title: "Basketball", day: "Foundations", image: "day-2.webp" },
  { title: "Ready Stance", day: "Business Admin", image: "day-3.webp" },
  { title: "Boombox Lift", day: "Production", image: "day-4.webp" },
  { title: "On the Run", day: "Distribution", image: "day-5.webp" },
  { title: "Listen", day: "Marketing", image: "day-6.webp" },
  { title: "Victory", day: "Growth", image: "day-7.webp" },
  { title: "Look Ahead", day: "The Legacy", image: "day-8.webp" },
];

export function savedPoses(): number[] {
  try {
    const value = JSON.parse(localStorage.getItem(POSE_STORAGE) || "[]");
    return Array.isArray(value)
      ? [
          ...new Set(
            value.filter(
              (day) =>
                Number.isInteger(day) && day >= 0 && day < poseRewards.length,
            ),
          ),
        ]
      : [];
  } catch {
    return [];
  }
}

export function awardDayPose(
  current: number[],
  day: number,
  learned: number,
  needed: number,
): number[] | undefined {
  if (!poseRewards[day] || !needed || learned < needed) return;
  const saved = savedPoses();
  if (current.includes(day) || saved.includes(day)) return;
  const next = [...new Set([...saved, ...current, day])].sort((a, b) => a - b);
  try {
    localStorage.setItem(POSE_STORAGE, JSON.stringify(next));
  } catch {
    // Keep the collection usable for this session when storage is unavailable.
  }
  return next;
}
