import { createRoot } from "react-dom/client";
import Game from "./play";

const root = document.getElementById("arcade-root");
if (root) createRoot(root).render(<Game />);
