import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const source = new URL('../source/arcade/', import.meta.url);
const output = new URL('../web/arcade/', import.meta.url);
await mkdir(output, { recursive: true });

await build({
    entryPoints: [fileURLToPath(new URL('entry.tsx', source))],
    outfile: fileURLToPath(new URL('arcade.js', output)),
    bundle: true,
    minify: true,
    jsx: 'automatic',
    define: { 'process.env.NODE_ENV': JSON.stringify('production') },
    target: 'es2022',
    legalComments: 'eof',
});

const sections = await Promise.all([
    readFile(new URL('game.css', source), 'utf8'),
    readFile(new URL('room-sprites.css', source), 'utf8'),
]);
sections.push('.canvas-wrap canvas:focus-visible { outline: 2px solid #ffe39b; outline-offset: -3px; }');
await writeFile(new URL('arcade.css', output), sections.map(section => section.trim()).join('\n') + '\n');
console.log('Built the Gatekeepers arcade in web/arcade.');
