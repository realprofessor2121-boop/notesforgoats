import { access, copyFile, mkdir, readFile } from 'node:fs/promises';
import { dirname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const web = fileURLToPath(new URL('../web', import.meta.url));
const { files } = JSON.parse(await readFile(new URL('../asset-manifest.json', import.meta.url), 'utf8'));
const [action, option] = process.argv.slice(2);

function assetPath(root, name) {
    const file = resolve(root, name);
    if (!file.startsWith(resolve(root) + sep)) throw new Error(`Invalid asset path ${name}`);
    return file;
}

async function exists(path) {
    try {
        await access(path);
        return true;
    } catch {
        return false;
    }
}

if (action === 'sync' && option) {
    const source = resolve(option);
    const missing = [];
    for (const file of files.filter(file => file.availability === 'site-export')) {
        const input = assetPath(source, file.path);
        if (!(await exists(input))) {
            missing.push(file.path);
            continue;
        }

        const output = assetPath(web, file.path);
        await mkdir(dirname(output), { recursive: true });
        await copyFile(input, output);
    }
    if (missing.length) {
        console.error(`${missing.length} assets missing in the site export.\n${missing.join('\n')}`);
        process.exitCode = 1;
    } else {
        console.log('Site media is in web.');
    }
} else if (action === 'verify') {
    const full = option === '--full';
    const missing = [];
    let neededMedia = 0;
    for (const file of files) {
        if (await exists(assetPath(web, file.path))) continue;
        if (full || file.availability !== 'site-export') missing.push(file.path);
        else neededMedia++;
    }
    if (missing.length) {
        console.error(`${missing.length} required files missing.\n${missing.join('\n')}`);
        process.exitCode = 1;
    } else {
        console.log('Editable site and arcade files are ready.');
    }
    if (neededMedia) console.log(`Copy ${neededMedia} files from the full site export for media playback.`);
} else {
    console.error('Use npm run verify [-- --full] or npm run sync-media -- /path/to/site/dist.');
    process.exitCode = 1;
}
